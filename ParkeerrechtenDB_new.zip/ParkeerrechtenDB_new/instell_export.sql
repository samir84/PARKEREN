--------------------------------------------------------
--  File created - maandag-oktober-02-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table INSTELLINGEN
--------------------------------------------------------

  CREATE TABLE "PARKEREN"."INSTELLINGEN" 
   (	"RECHT_ID" NUMBER, 
	"KEY" VARCHAR2(100 BYTE), 
	"VALUE" VARCHAR2(1 BYTE), 
	"DATUMCHECK" DATE DEFAULT sysdate
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "PARKEREN_DATA" ;
REM INSERTING into PARKEREN.INSTELLINGEN
SET DEFINE OFF;
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('5952','Email_Notification','J',to_date('25-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('5953','Email_Notification','N',to_date('25-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('5954','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('5955','Email_Notification','N',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6002','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6003','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6004','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6005','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6006','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6007','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6008','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6009','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6010','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6011','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6012','Email_Notification','N',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6013','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6014','Email_Notification','N',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6015','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6016','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6017','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6018','Email_Notification','N',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6019','Email_Notification','J',to_date('27-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6952','Email_Notification','N',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6953','Email_Notification','N',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6954','Email_Notification','J',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6955','Email_Notification','J',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6956','Email_Notification','J',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6957','Email_Notification','J',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6958','Email_Notification','J',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6959','Email_Notification','J',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6960','Email_Notification','J',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6961','Email_Notification','J',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6962','Email_Notification','N',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6963','Email_Notification','N',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6964','Email_Notification','J',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6965','Email_Notification','J',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6966','Email_Notification','N',to_date('01-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6967','Email_Notification','J',to_date('03-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6968','Email_Notification','N',to_date('03-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6969','Email_Notification','J',to_date('03-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6970','Email_Notification','N',to_date('03-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6971','Email_Notification','N',to_date('03-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6972','Email_Notification','J',to_date('03-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6973','Email_Notification','N',to_date('03-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6974','Email_Notification','J',to_date('03-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('6975','Email_Notification','J',to_date('03-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('8952','Email_Notification','J',to_date('08-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('9952','Email_Notification','J',to_date('13-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12954','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12952','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12953','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12955','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12956','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12957','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12958','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12959','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12960','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12961','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12962','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12963','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12964','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12965','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12966','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12967','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12968','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12969','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12970','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12971','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('12972','Email_Notification','J',to_date('28-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('1952','Email_Notification','J',to_date('29-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7963','Email_Notification','J',to_date('17-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7965','Email_Notification','J',to_date('22-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7964','Email_Notification','N',to_date('17-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7966','Email_Notification','N',to_date('22-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7967','Email_Notification','J',to_date('22-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7968','Email_Notification','J',to_date('22-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7969','Email_Notification','J',to_date('24-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7970','Email_Notification','J',to_date('24-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7971','Email_Notification','J',to_date('24-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7972','Email_Notification','J',to_date('24-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7973','Email_Notification','J',to_date('24-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7974','Email_Notification','J',to_date('24-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7975','Email_Notification','N',to_date('24-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7976','Email_Notification','N',to_date('24-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7977','Email_Notification','N',to_date('24-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7978','Email_Notification','J',to_date('24-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('2067','Email_Notification','J',to_date('29-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('1003','Email_Notification','J',to_date('08-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('1004','Email_Notification','J',to_date('12-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('1005','Email_Notification','J',to_date('12-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('1006','Email_Notification','J',to_date('12-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('1007','Email_Notification','J',to_date('12-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('1008','Email_Notification','J',to_date('13-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('1009','Email_Notification','J',to_date('13-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('1000','Email_Notification','J',to_date('27-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('980','Email_Notification','J',to_date('27-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('980','Email_Notification','J',to_date('27-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4952','Email_Notification','J',to_date('18-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4953','Email_Notification','J',to_date('18-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4954','Email_Notification','J',to_date('18-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4955','Email_Notification','J',to_date('18-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('10955','Email_Notification','J',to_date('25-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('11952','Email_Notification','J',to_date('26-09-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('2952','Email_Notification','J',to_date('04-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('18011','Email_Notification','J',to_date('22-06-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3068','Email_Notification','J',to_date('04-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3069','Email_Notification','J',to_date('04-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3070','Email_Notification','J',to_date('04-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3071','Email_Notification','J',to_date('04-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3102','Email_Notification','J',to_date('04-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3103','Email_Notification','J',to_date('04-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3104','Email_Notification','J',to_date('04-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3105','Email_Notification','J',to_date('04-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3106','Email_Notification','J',to_date('06-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3107','Email_Notification','J',to_date('06-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3108','Email_Notification','J',to_date('06-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3109','Email_Notification','J',to_date('06-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3066','Email_Notification','J',to_date('04-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3067','Email_Notification','J',to_date('04-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3110','Email_Notification','J',to_date('06-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('3952','Email_Notification','J',to_date('10-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4002','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4003','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4004','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4005','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4006','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4007','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4008','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4009','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4010','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4011','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4012','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4013','Email_Notification','J',to_date('11-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4052','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4053','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4054','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4055','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4056','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4057','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4058','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4059','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4060','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4061','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4062','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4063','Email_Notification','N',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4064','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4065','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4066','Email_Notification','N',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4067','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4068','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4069','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4070','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4071','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4072','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4073','Email_Notification','N',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('4074','Email_Notification','J',to_date('13-07-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7952','Email_Notification','J',to_date('08-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7953','Email_Notification','J',to_date('08-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7954','Email_Notification','N',to_date('08-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7956','Email_Notification','J',to_date('08-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7957','Email_Notification','J',to_date('10-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7958','Email_Notification','N',to_date('10-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7959','Email_Notification','J',to_date('10-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7960','Email_Notification','J',to_date('15-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7961','Email_Notification','N',to_date('15-08-17','DD-MM-RR'));
Insert into PARKEREN.INSTELLINGEN (RECHT_ID,KEY,VALUE,DATUMCHECK) values ('7962','Email_Notification','J',to_date('15-08-17','DD-MM-RR'));
--------------------------------------------------------
--  Constraints for Table INSTELLINGEN
--------------------------------------------------------

  ALTER TABLE "PARKEREN"."INSTELLINGEN" MODIFY ("RECHT_ID" NOT NULL ENABLE);
