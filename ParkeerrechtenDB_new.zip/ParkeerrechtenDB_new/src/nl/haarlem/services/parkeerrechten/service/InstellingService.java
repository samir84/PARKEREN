package nl.haarlem.services.parkeerrechten.service;

import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.InstellingenEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;

@Local
public interface InstellingService {
   
    public List<InstellingenEntity> findInstellingenEntityByRecht(RechtEntity recht) throws BezoekersparkerenException;

    public void updateInstelling(String aanmeldcode, String key,String value)throws BezoekersparkerenException;
    public InstellingenEntity findNotificationMailByAanmeldcode(String aanmeldcode) throws BezoekersparkerenException;
    public void updateMailNotification(String aanmeldcode,String value)throws BezoekersparkerenException;
    public InstellingenEntity findInstellingByAanmeldcodeAndKey(String aanmeldcode, String key) throws BezoekersparkerenException;
}
