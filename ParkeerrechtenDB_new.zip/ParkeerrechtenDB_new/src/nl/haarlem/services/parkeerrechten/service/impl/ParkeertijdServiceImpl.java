package nl.haarlem.services.parkeerrechten.service.impl;

import java.util.Collections;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;


import nl.haarlem.services.parkeerrechten.dao.ParkeertijdDAO;
import nl.haarlem.services.parkeerrechten.dao.ParkeerzoneDAO;
import nl.haarlem.services.parkeerrechten.jpa.Parkeertijd;
import nl.haarlem.services.parkeerrechten.jpa.Parkeerzone;
import nl.haarlem.services.parkeerrechten.service.ParkeertijdService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class ParkeertijdServiceImpl implements ParkeertijdService{

    private Logger log = LoggerFactory.getLogger(ParkeertijdServiceImpl.class.getName());
    @EJB
    private ParkeertijdDAO parkeertijdDAO;
    @EJB
    private ParkeerzoneDAO parkeerzoneDAO;
    
    public List<Parkeertijd> findAll() {

        return parkeertijdDAO.findAll();
    }

    public List<Parkeertijd> findByParkeerzone(String zone) {
        
        List<Parkeerzone> parkeerzones = parkeerzoneDAO.findByName(zone);
        return parkeertijdDAO.findByParkeerzone(parkeerzones);
    }
}
