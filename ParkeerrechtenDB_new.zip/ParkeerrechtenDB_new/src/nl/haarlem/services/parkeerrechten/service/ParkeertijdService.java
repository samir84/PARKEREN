package nl.haarlem.services.parkeerrechten.service;

import java.sql.Timestamp;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.jpa.Parkeertijd;
import nl.haarlem.services.parkeerrechten.jpa.Parkeerzone;


@Local
public interface ParkeertijdService {
    
    public List<Parkeertijd> findAll();
    public List<Parkeertijd> findByParkeerzone(String zone);
    /*public List<Parkeertijd> findByParkeerzoneEnTijdsVenster(String parkeerzone,Timestamp begintijd, Timestamp eindtijd);
    public List<Parkeertijd> findByTijdsVenster(Timestamp begintijd, Timestamp eindtijd);
    public Parkeertijd findByDatum(Timestamp begintijd);

    public List<Parkeertijd> ophalenParkeertijdenByDate(Date date);
    public List<Parkeertijd> ophalenParkeertijdenByDateEnParkeerzone(Date date,String parkeerzone);
*/

}
