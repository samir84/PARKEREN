package nl.haarlem.services.parkeerrechten.jpa;

import java.io.Serializable;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;

@Entity
@Table(name = "PARKEERTIJD")
@NamedQueries( { @NamedQuery(name = "Parkeertijd.findAll", query = "select o from Parkeertijd o order by o.begintijd"),
                 @NamedQuery(name = "Parkeertijd.findByParkeerzone", 
                            query ="select o from Parkeertijd o where o.parkeerzones =:p_parkeerzones "),
                /* @NamedQuery(name = "Parkeertijd.findByTijdsVenster", 
                             query ="select o from Parkeertijd o where o.begintijd= :p_begintijd and o.eindtijd= :p_eindtijd"),
                 @NamedQuery(name = "Parkeertijd.findByParkeerzoneEnTijdsVenster", 
                             query ="select o from Parkeertijd o where UPPER(o.parkeerzones)= UPPER(:p_parkeerzone) and o.begintijd= :p_begintijd and o.eindtijd= :p_eindtijd"),
                 @NamedQuery(name = "Parkeertijd.findByDatum", 
                             query ="select o from Parkeertijd o where o.begintijd>= :p_begintijd and o.eindtijd<= :p_eindtijd")*/
})

public class Parkeertijd implements Serializable{
    
    private static final long serialVersionUID = -5814597527317150423L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    //@GeneratedValue(strategy = GenerationType.SEQUENCE,
                    //generator = "SeqParkeertijdId")
    //@SequenceGenerator(name = "SeqParkeertijdId", sequenceName = "SEQ_Parkeertijd_ID")
    private Long id;
    
    private String dag;
    private Timestamp begintijd;
    private Timestamp eindtijd;
    private double tarief;
    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID")
    private List<Parkeerzone> parkeerzones ;


    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setDag(String dag) {
        this.dag = dag;
    }

    public String getDag() {
        return dag;
    }

    public void setBegintijd(Timestamp begintijd) {
        this.begintijd = begintijd;
    }
    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getBegintijd() {
        return begintijd;
    }

    public void setEindtijd(Timestamp eindtijd) {
        this.eindtijd = eindtijd;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getEindtijd() {
        return eindtijd;
    }

    public void setTarief(double tarief) {
        this.tarief = tarief;
    }

    public double getTarief() {
        return tarief;
    }


    public void setParkeerzones(List<Parkeerzone> parkeerzones) {
        this.parkeerzones = parkeerzones;
    }

    public List<Parkeerzone> getParkeerzones() {
        return parkeerzones;
    }
}
