package nl.haarlem.services.parkeerrechten.jpa;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.model.Recht;
import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;

@Entity
@NamedQueries( { @NamedQuery(name = "AlgemeneVoorwaardenEntity.findAll",
                             query =
                             "select o from AlgemeneVoorwaardenEntity o") })
@Table(name = "ALGEMENE_VOORWAARDEN")
public class AlgemeneVoorwaardenEntity implements Serializable {

    private static final long serialVersionUID = 6195566964526295341L;

    @Column(nullable = false)
    private Timestamp datumcheck;

    @Id
    @OneToOne
    @JoinColumn(name = "RECHT_ID")
    private RechtEntity recht;

    public AlgemeneVoorwaardenEntity() {
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getDatumcheck() {
        return datumcheck;
    }

    public void setDatumcheck(Timestamp datumcheck) {
        this.datumcheck = datumcheck;
    }

    /*  public void setId(AlgemeneVoorwaardenPK id) {
        this.id = id;
    }

    public AlgemeneVoorwaardenPK getId() {
        return id;
    }*/


    public void setRecht(RechtEntity recht) {
        this.recht = recht;
    }

    public RechtEntity getRecht() {
        return recht;
    }


}
