package nl.haarlem.services.parkeerrechten.jpa;


import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;

@Entity
@Table(name = "PAKEERZONE")
@NamedQueries( { @NamedQuery(name = "Parkeerzone.findAll", query = "select o from Parkeerzone o"),
                 @NamedQuery(name = "Parkeerzone.findByName", query ="select o from Parkeerzone o where o.zone = :p_zone  ")

})

public class Parkeerzone implements Serializable {
   
   
    private static final long serialVersionUID = -5814597527317150423L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id ;
    private String zone;

    

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getZone() {
        return zone;
    }


    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}
