package nl.haarlem.services.parkeerrechten.dao;

import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.jpa.InstellingenEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;


@Local
public interface InstellingenEntityDAO {
    
    public List<InstellingenEntity> findInstellingenEntityByRecht(RechtEntity recht);
    public void createInstellingenEntity(InstellingenEntity instelling);
    public void updateInstellingEntity(InstellingenEntity instelling);
    public InstellingenEntity findInstellingEntityByRechtAndKey(RechtEntity rechtEntity , String key);
}
