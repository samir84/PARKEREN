package nl.haarlem.services.parkeerrechten.dao;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.jpa.AlgemeneVoorwaardenEntity;

@Local
public interface AlgemeneVoorwaardenDAO {
    void createAlgemeneVoorwaarden(AlgemeneVoorwaardenEntity alg);
}
