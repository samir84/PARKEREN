package nl.haarlem.services.parkeerrechten.dao.impl;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;

import javax.persistence.CacheStoreMode;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;

import nl.haarlem.services.parkeerrechten.dao.RechtEntityDAO;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;

import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;


import org.eclipse.persistence.config.QueryHints;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class RechtEntityDAOImpl implements RechtEntityDAO {

    private Logger log =
        LoggerFactory.getLogger(RechtTypeDAOImpl.class.getName());

    @PersistenceContext(unitName = "ParkeerrechtenDB")
    private EntityManager em;
    
    public void setEm(EntityManager em) {
        this.em = em;
    }
    public EntityManager getEm() {
        return em;
    }
    
    public boolean isAanmeldcode(String aanmeldcode) {
        boolean exist = false;

        log.debug("Recht.findByAanmeldcode: " + aanmeldcode);
        List<RechtEntity> rechtEntities = new ArrayList<RechtEntity>();
        try {
            Date now = new Date();
            rechtEntities =
                    em.createNamedQuery("Recht.findByAanmeldcode").setParameter("p_aanmeldcode",
                                                                                    aanmeldcode).setParameter("p_huidigeTijd", now).getResultList();

            if (rechtEntities == null) {
                exist = false;
            }
            if (rechtEntities.size() > 0) {
                exist = true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return exist;
    }


    public RechtEntity findByAanmeldcode(String aanmeldcode){

        RechtEntity rechtEntity = null;
        try {
            Query query = em.createNamedQuery("Recht.findByAanmeldcode");
            query.setParameter("p_aanmeldcode",aanmeldcode);
            Date now = new Date();
            query.setParameter("p_huidigeTijd",now);
            
            List<RechtEntity> rechtEntityList = (List<RechtEntity>) query.getResultList();
            
            if(rechtEntityList != null && rechtEntityList.size() > 0){
                rechtEntity = rechtEntityList.get(0);
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return rechtEntity;
    }

    /**
     *
     * @param email and bank number
     * @return
     */
    public String updateRecht(RechtEntity oldRechtEntity) {
        String succes = "error";
        log.debug("updateRecht..");

        try {
            em.merge(oldRechtEntity);
            RechtEntity newRechtEntity =
                findByAanmeldcode(oldRechtEntity.getAanmeldcode());

            if (newRechtEntity.getEmail().equals(oldRechtEntity.getEmail()) &&
                newRechtEntity.getIban().equals(oldRechtEntity.getIban())) {
                succes = "succes";
            } else {
                succes =
                        "Bezoekers recht is niet gewijzigd door enn internal error!";
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }


        return succes;
    }


    public String opzeggenRecht(String aanmeldcode) throws BezoekersparkerenException{
        String succes = null;
           //opzeggen query
           RechtEntity oldRechtEntity = findByAanmeldcode(aanmeldcode);
            if(oldRechtEntity == null){
                throw new BezoekersparkerenException("error","Geen Bezoekers recht gevonden met aanmeldcode: "+aanmeldcode);
            }
            Timestamp now = new Timestamp(new Date().getTime());
            oldRechtEntity.setEinddatum(now);
            em.merge(oldRechtEntity);
            RechtEntity newRechtEntity = findByAanmeldcode(aanmeldcode);

            if (newRechtEntity.getEinddatum().equals(now)) {
                succes = "succes";
            } else {
                throw new BezoekersparkerenException( "error", "Bezoekers recht is niet gewijzigd door enn internal error!");
            }
    
        return succes;
    }

    public RechtEntity ophalenBezoekersrechtByBSN(String bsn) {
       
        RechtEntity rechtEntity = null;
        
        Query query = em.createNamedQuery("Recht.findByBSN");
        query.setParameter("p_bsn",bsn);
        Date now = new Date();
        query.setParameter("p_huidigeTijd",now);
        query.setHint(QueryHints.REFRESH, true);
        List<RechtEntity> rechtEntityList = (List<RechtEntity>) query.getResultList();
        log.info("findByBSN: "+query.getResultList().size());
        if(rechtEntityList != null && rechtEntityList.size() > 0){
            rechtEntity = rechtEntityList.get(0);
        }
            return rechtEntity;
    }

    public RechtEntity ophalenBezoekersrechtByAanmeldcode(String aanmeldcode)  {
        
        RechtEntity rechtEntity = null;
        Query query = em.createNamedQuery("Recht.findByAanmeldcode");
        query.setParameter("p_aanmeldcode",aanmeldcode);
        Date now = new Date();
        query.setParameter("p_huidigeTijd",now);


        List<RechtEntity> rechtEntityList = (List<RechtEntity>) query.getResultList();
        if(rechtEntityList != null && rechtEntityList.size() > 0){
            rechtEntity =  rechtEntityList.get(0);
        }
        
        return rechtEntity;
    }
    /*
     * checke if recht already exist 
     */
    public boolean checkBezoekersrechtByBSN(String bsn) throws BezoekersparkerenException{
        
        boolean exist = false;
        
        Query query = em.createNamedQuery("Recht.findByBSN");
        query.setParameter("p_bsn",bsn);
        List<RechtEntity> rechtEntityList = (List<RechtEntity>) query.getResultList();
        if(rechtEntityList!= null & rechtEntityList.size() > 1){
            exist = true;
            throw new BezoekersparkerenException("error","Er mag maar 1 recht per bezoeker!");
        }else if(rechtEntityList!= null && rechtEntityList.size() == 1){
            exist = true;
        }
        return exist;
    }
    
    public void createRecht(RechtEntity rechtEntity) {
        em.persist(rechtEntity);
    }

    public RechtEntity findById(Long id) {
        return em.find(RechtEntity.class, id);
    }


    public void merge(RechtEntity rechtEntity) {
        em.merge(rechtEntity);
    }

    public RechtEntity ophalenRechtByNummerAanduiding(String nummerAanduiding) throws BezoekersparkerenException {
        
        RechtEntity rechtEntity = null;
        Query query = em.createNamedQuery("Recht.findRechtByNummerAanduiding");
        query.setParameter("p_nummerAanduiding",nummerAanduiding);
        Date now = new Date();
        query.setParameter("p_huidigeTijd",now);
        List<RechtEntity> rechtEntityList = (List<RechtEntity>) query.getResultList();
        
        
        if(rechtEntityList != null && rechtEntityList.size() > 0){
            rechtEntity = rechtEntityList.get(0);
        }
            return rechtEntity;
        
    }


    public boolean verwijderRecht(String bsn) {
        
        RechtEntity rechtEntity =  ophalenBezoekersrechtByBSN(bsn);
        em.remove(rechtEntity);
        RechtEntity oldrechtEntity =  ophalenBezoekersrechtByBSN(bsn);
        return oldrechtEntity == null ? true :  false;
    }
}
