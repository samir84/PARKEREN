package nl.haarlem.services.parkeerrechten.dao;

import java.sql.Timestamp;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.jpa.Parkeertijd;
import nl.haarlem.services.parkeerrechten.jpa.Parkeerzone;

@Local
public interface ParkeertijdDAO {
    
    List<Parkeertijd> findAll();
    List<Parkeertijd> findByParkeerzone(List<Parkeerzone> parkeerzones);
   // List<Parkeertijd> findByParkeerzoneEnTijdsVenster(String parkeerzone,Timestamp begintijd, Timestamp eindtijd);
    //List<Parkeertijd> findByTijdsVenster(Timestamp begintijd, Timestamp eindtijd);
   // Parkeertijd findByDatum(Timestamp begintijd);

   // public List<Parkeertijd> findByDay(Date date);
    
   // public List<Parkeertijd> findByDayAndParkeerzone(Date date,String parkeerzone);
}
