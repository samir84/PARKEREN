package nl.haarlem.services.parkeerrechten.dao.impl;

import java.lang.reflect.Field;

import java.lang.reflect.Method;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import javax.persistence.criteria.Root;

import nl.haarlem.services.parkeerrechten.dao.ParkeertijdDAO;
import nl.haarlem.services.parkeerrechten.jpa.Parkeertijd;


import nl.haarlem.services.parkeerrechten.jpa.Parkeerzone;

import org.python.parser.ast.Break;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class ParkeertijdDAOImpl implements ParkeertijdDAO{
   
    private Logger log = LoggerFactory.getLogger(ParkeertijdDAOImpl.class.getName());

    @PersistenceContext(unitName = "ParkeerrechtenDB")
    private EntityManager em;

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public EntityManager getEm() {
        return em;
    }


    public List<Parkeertijd> findAll() {
        List<Parkeertijd> parkeertijden = null;
        Query query = em.createNamedQuery("Parkeertijd.findAll");
        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            parkeertijden = (List<Parkeertijd>)query.getResultList();
        }
        return parkeertijden;
    }

   public List<Parkeertijd> findByParkeerzone(List<Parkeerzone> parkeerzones) {
        
        log.info("Parkeertijd.findByParkeerzone..");
        log.info("total parkeerzones:"+parkeerzones.size()+"*");
        List<Parkeertijd> parkeertijden = null;
        Query query = em.createNamedQuery("Parkeertijd.findByParkeerzone");
       // query.setParameter("p_parkeerzones", parkeerzones);
        query.setParameter("p_parkeerzones",Arrays.asList(new Long(1), new Long(2)));
        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            parkeertijden = (List<Parkeertijd>)query.getResultList();
        }
        log.info("total parkeertijden:"+parkeertijden.size()+"*");
        return parkeertijden;
    }
/*
    public List<Parkeertijd> findByParkeerzoneEnTijdsVenster(String parkeerzone,
                                                               Timestamp begintijd,
                                                               Timestamp eindtijd) {
        log.info("Parkeertijd.findByParkeerzoneEnTijdsVenster..");
        List<Parkeertijd> parkeertijden = null;
        Query query = em.createNamedQuery("Parkeertijd.findByParkeerzoneEnTijdsVenster");
        query.setParameter("p_parkeerzone", parkeerzone);
        query.setParameter("p_begintijd", begintijd);
        query.setParameter("p_eindtijd", eindtijd);
        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            parkeertijden = (List<Parkeertijd>)query.getResultList();
        }
        return parkeertijden;
    }

    public List<Parkeertijd> findByTijdsVenster(Timestamp begintijd,
                                                  Timestamp eindtijd) {
        log.info("Parkeertijd.findByTijdsVenster..");
        List<Parkeertijd> parkeertijden = null;
        Query query = em.createNamedQuery("Parkeertijd.findByTijdsVenster");
        query.setParameter("p_begintijd", begintijd);
        query.setParameter("p_eindtijd", eindtijd);
        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            parkeertijden = (List<Parkeertijd>)query.getResultList();
        }
        return parkeertijden;
    }

    public Parkeertijd findByDatum(Timestamp datum) {
        log.info("Parkeertijd.findByTijdsVenster..");
        Parkeertijd parkeertijden = null;
        Query query = em.createNamedQuery("Parkeertijd.findByTijdsVenster");
        
        Calendar beginCal = Calendar.getInstance();
        beginCal.set(beginCal.get(Calendar.YEAR), 0, 1, 0, 0, 0);
        
        Calendar eindCal = Calendar.getInstance();
        eindCal.set(eindCal.get(Calendar.YEAR), 0, 1, 23, 59, 0);
        
        query.setParameter("p_begintijd", new Timestamp(beginCal.getTimeInMillis()));
        query.setParameter("p_eindtijd", new Timestamp(eindCal.getTimeInMillis()));
        
        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            parkeertijden = (Parkeertijd)query.getResultList().get(0);
        }
        return parkeertijden;
    }

    

    public List<Parkeertijd> findByDayAndParkeerzone(Date date,String parkeerzone) {
        log.info("Parkeertijd.findByDayAndParkeerzone..");
    
        
        List<Parkeertijd> parkeertijdenList = null;
        String dagnaam = null;
        String[] dagen = {"zondag", "maandag","dinsdag","woensdag","donderdag","vrijdag","zaterdag"};
        try{
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH);
            int day = cal.get(Calendar.DAY_OF_WEEK);
            dagnaam = dagen[day-1];
           
           
            String strquery = "select o from Parkeertijden o ";
            log.info(strquery);
            Query query = em.createQuery(strquery);
            
            query.setParameter("p_parkeerzone", parkeerzone);
            
           
            if (query.getResultList() != null &&
                query.getResultList().size() > 0) {
                parkeertijdenList = (List<Parkeertijd>)query.getResultList();
                log.info("total parkeertijden: "+parkeertijdenList.size());
                for(int i =0 ; i < parkeertijdenList.size(); i++){

                    Parkeertijd parkeertijd = (Parkeertijd) parkeertijdenList.get(i);
                    //setDayNull(dagnaam,parkeertijd);
                    em.clear();
                        
                    
                }
                
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        

        return parkeertijdenList;
    }

   

    public List<Parkeertijd> findByDay(Date date) {
        log.info("Parkeertijd.findByDay..");
        List<Parkeertijd> parkeertijdenList = null;
        String dagnaam = null;
        String[] dagen = {"zondag", "maandag","dinsdag","woensdag","donderdag","vrijdag","zaterdag"};
        try{
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH);
            int day = cal.get(Calendar.DAY_OF_WEEK);
            dagnaam = dagen[day-1];
           
           
            String strquery = "select o from Parkeertijd ";
            log.info(strquery);
            Query query = em.createQuery(strquery);
           
            if (query.getResultList() != null &&
                query.getResultList().size() > 0) {
                parkeertijdenList = (List<Parkeertijd>)query.getResultList();
                log.info("total parkeertijden: "+parkeertijdenList.size());
                for(int i =0 ; i < parkeertijdenList.size(); i++){

                    Parkeertijd parkeertijd = (Parkeertijd) parkeertijdenList.get(i);
                    //setDayNull(dagnaam,parkeertijd);
                    em.clear();
                        
                    
                }
                
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        

        return parkeertijdenList;
    }*/

    
}
