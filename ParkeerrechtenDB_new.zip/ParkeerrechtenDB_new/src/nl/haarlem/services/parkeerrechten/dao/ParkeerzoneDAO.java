package nl.haarlem.services.parkeerrechten.dao;

import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.jpa.Parkeerzone;

@Local
public interface ParkeerzoneDAO {
    
    public List<Parkeerzone> findByName(String name);
}
