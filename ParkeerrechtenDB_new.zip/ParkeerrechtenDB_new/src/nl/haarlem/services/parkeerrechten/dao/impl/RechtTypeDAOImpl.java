package nl.haarlem.services.parkeerrechten.dao.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import nl.haarlem.services.parkeerrechten.dao.RechtTypeDAO;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtTypeEntity;

@Stateless
public class RechtTypeDAOImpl implements RechtTypeDAO {

    private Logger log =
        LoggerFactory.getLogger(RechtTypeDAOImpl.class.getName());

    @PersistenceContext(unitName = "ParkeerrechtenDB")
    private EntityManager em;

    public RechtTypeDAOImpl() {
        super();
    }

    public void createRechtType(RechtTypeEntity rechtType) {

        log.info("Create RechtType for the BSN " +
                 rechtType.getRecht().getBsn());
        em.persist(rechtType);
    }

    public List<RechtTypeEntity> findByRechtID(RechtEntity recht) {
       
        List<RechtTypeEntity> rechtTypeEntities =
            new ArrayList<RechtTypeEntity>();
        try {
            rechtTypeEntities =
                    em.createNamedQuery("Rechtype.findByRechtID").setParameter("p_recht",
                                                                               recht).getResultList();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return rechtTypeEntities;
    }

    public List<RechtTypeEntity> findAll() {
        return     (List<RechtTypeEntity>)em.createNamedQuery("Rechtype.findAll").getResultList();
    }
}
