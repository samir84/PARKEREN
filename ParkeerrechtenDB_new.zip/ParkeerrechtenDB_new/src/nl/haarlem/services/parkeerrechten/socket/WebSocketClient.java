/*package nl.haarlem.services.parkeerrechten.socket;

//import com.google.gson.Gson;

import java.io.IOException;

import java.net.URI;
import java.net.URISyntaxException;

import javax.websocket.ClientEndpoint;
import javax.websocket.ContainerProvider;
import javax.websocket.DeploymentException;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.WebSocketContainer;

import nl.haarlem.services.parkeerrechten.model.Message;

@ClientEndpoint
public class WebSocketClient {
    
    public WebSocketClient() {
        super();
    }
    
    public static void main(String[] args) {
        System.out.println("Opening new websocket");
        WebSocketClient connect = null;
        try {
            String url= "ws://slrp024.ssc.lan:8080/bezoekersparkeren/websocket";

            Gson g = new Gson();
            Message message = new Message();
            connect = new WebSocketClient(new URI(url));
            connect.sendMessage(g.toJson(message));


        } catch (DeploymentException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    private static Session _session;

    public WebSocketClient(URI endpointURI) throws DeploymentException, IOException
    {
        WebSocketContainer container = ContainerProvider.getWebSocketContainer();
        container.connectToServer(this, endpointURI);
    }

    @OnMessage
    public void onMessage(String message, Session session){
        System.out.println("WebsocketUser: Message received for session: "+session.getId());
    }

    @OnOpen
    public void onOpen(Session session) throws IOException
    {
        _session = session;
        System.out.println("New websocket session opened, sessionid: "+session.getId());
    }

    public void sendMessage(String message) throws IOException
    {
        _session.getBasicRemote().sendText(message);

    }

    @OnClose
    public void onClose(Session session){
        System.out.println("Websocket session closed, sessionid: "+session.getId());
        try {
            session.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @OnError
    public void onError(Throwable t, Session session){

    }
}
*/