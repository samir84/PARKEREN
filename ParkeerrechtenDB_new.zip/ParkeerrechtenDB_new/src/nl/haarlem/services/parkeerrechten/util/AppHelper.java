package nl.haarlem.services.parkeerrechten.util;

import java.io.PrintStream;

import java.sql.Timestamp;

import java.text.DecimalFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class AppHelper {


    private static AppHelper instance = null;

    protected AppHelper() {
        // Exists only to defeat instantiation.
    }

    public static AppHelper getInstance() {
        if (instance == null) {
            instance = new AppHelper();
        }
        return instance;
    }

    /**
     *Generate a unique random id for Aanmeldcode
     * @param string length
     * @return
     */
    public static String generateAanmeldcode(int length) {
        UUID uuid = UUID.randomUUID();
        return uuid.toString().substring(0, length);

    }

    public static String generateNewAanmeldcode(String oldcode) {

        UUID uuid = UUID.randomUUID();
        String newCode = uuid.toString().substring(0, oldcode.length());
        while (oldcode.equals(newCode)) {
            newCode = generateAanmeldcode(newCode.length());
        }
        return newCode;
    }
    public Double roundTwoDecimal(double bedrag) {
        
        int r = (int) Math.round(bedrag*100);
        double round = r / 100.0;
        
        return round;
        
    }

    private  Float ophalenBestedingsLimit(String rechtType) {
        if (rechtType.equalsIgnoreCase("BEZOEKER")) {
            return new Float(125);
        } else if (rechtType.equalsIgnoreCase("MANTELZORG")) {
            return new Float(25);
        } else {
            return new Float(0);
        }
    }
    
    /**
     *
     * @return bestedingslimiet anaf de begindatum(lopende maand) van de rechistratie
     */
    public  Float CalculateBestedingsLimit(String rechtType , Timestamp date) {
        double bestedingsLimit = ophalenBestedingsLimit(rechtType);
        Float result = new Float(0.00);
        Calendar cal = Calendar.getInstance();
        if(isSameYear(date, new Date())){
            cal.setTimeInMillis(date.getTime());
            int restMonthsOfYear = 12 - cal.get(Calendar.MONTH);
            result = new Float((restMonthsOfYear * bestedingsLimit) / 12);
        }else{  
            result = new Float(bestedingsLimit);
        }
        
        return result;
    }
   
    private boolean isSameYear(Date date1, Date date2) {
        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(date1);
        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTime(date2);
        boolean sameYear = calendar1.get(Calendar.YEAR) == calendar2.get(Calendar.YEAR);
        return sameYear;
    }
    
    
}
