package nl.haarlem.services.parkeerrechten.exception;

import javax.jws.WebParam;

import javax.xml.ws.WebFault;

@WebFault(name = "BezoekersparkerenException",
          targetNamespace = "http://www.haarlem.nl/services/parkeerrechten/exception/BezoekersparkerenException")
public class BezoekersparkerenException extends Exception {


    private static final long serialVersionUID = -6647544772732631047L;
    private BezoekersparkerenFault fault;

    public BezoekersparkerenException() {
    }

    public BezoekersparkerenException(BezoekersparkerenFault fault) {
        super(fault.getFaultString());
        this.fault = fault;
    }

    /**
     *
     * @param message
     * @param faultInfo
     */
    public BezoekersparkerenException(String message, BezoekersparkerenFault faultInfo) {
        super(message);
        this.fault = faultInfo;
    }

    /**
     *
     * @param message
     * @param faultInfo
     * @param cause
     */
    public BezoekersparkerenException(String message, BezoekersparkerenFault faultInfo,
                              Throwable cause) {
        super(message, cause);
        this.fault = faultInfo;
    }

    /**
     *
     * @return
     */
    public BezoekersparkerenFault getFaultInfo() {
        return fault;
    }

    /**
     * @param message
     */
   /* public BezoekersparkerenException(String message) {
        super(message);
    }*/

    /**
     * @param message
     */
    public BezoekersparkerenException(String code, String message) {
        super(message);
        this.fault = new BezoekersparkerenFault();
        this.fault.setFaultString(message);
        this.fault.setFaultCode(code);
    }

    /**
     * @param cause
     */
    public BezoekersparkerenException(Throwable cause) {
        super(cause);
    }

    /**
     * @param message
     * @param cause
     */
    public BezoekersparkerenException(String message, Throwable cause) {
        super(message, cause);
    }


}
