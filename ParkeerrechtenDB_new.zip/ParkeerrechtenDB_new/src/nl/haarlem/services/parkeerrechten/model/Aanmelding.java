package nl.haarlem.services.parkeerrechten.model;

public class Aanmelding {

    private String aanmeldcode;
    private String kenteken;

    

    public void setKenteken(String kenteken) {
        this.kenteken = kenteken;
    }

    public String getKenteken() {
        return kenteken;
    }

    public void setAanmeldcode(String aanmeldcode) {
        this.aanmeldcode = aanmeldcode;
    }

    public String getAanmeldcode() {
        return aanmeldcode;
    }
}
