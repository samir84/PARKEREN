package nl.haarlem.services.parkeerrechten.model;

import java.util.List;

import nl.haarlem.services.parkeerrechten.jpa.Parkeertijd;

public class Bestedingsruimte {

    private double limiet;
    private double ruimte;
    private double verbruik;
    private List<Parkeertijd> parkeertijden;

    public void setLimiet(double limiet) {
        this.limiet = limiet;
    }

    public double getLimiet() {
        return limiet;
    }

    public void setRuimte(double ruimte) {
        this.ruimte = ruimte;
    }

    public double getRuimte() {
        return ruimte;
    }

    public void setVerbruik(double verbruik) {
        this.verbruik = verbruik;
    }

    public double getVerbruik() {
        return verbruik;
    }

    public void setParkeertijden(List<Parkeertijd> parkeertijden) {
        this.parkeertijden = parkeertijden;
    }

    public List<Parkeertijd> getParkeertijden() {
        return parkeertijden;
    }
}
