package nl.haarlem.services.parkeerrechten.model;

import java.sql.Timestamp;

import java.util.Calendar;

public class Weekdagen {
    
    private String naam;
    private Timestamp begintijd;
    private Timestamp eindtijd;


    public void setNaam(String naam) {
        this.naam = naam;
    }

    public String getNaam() {
        return naam;
    }

    public void setBegintijd(Timestamp begintijd) {
        this.begintijd = begintijd;
    }

    public Timestamp getBegintijd() {
        return begintijd;
    }

    public void setEindtijd(Timestamp eindtijd) {
        this.eindtijd = eindtijd;
    }

    public Timestamp getEindtijd() {
        return eindtijd;
    }
}
