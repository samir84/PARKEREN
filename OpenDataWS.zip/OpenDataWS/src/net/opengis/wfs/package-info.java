@javax.xml.bind.annotation.XmlSchema(namespace =
                                     "http://www.opengis.net/wfs/2.0",
                                      xmlns={
                @XmlNs(prefix="gemeentehaarlem", namespaceURI="http://www.haarlem.nl"),
                @XmlNs(prefix="gml", namespaceURI="http://www.opengis.net/gml/3.2")
        },
                                     elementFormDefault =
                                     javax.xml.bind.annotation.XmlNsForm.QUALIFIED
                                     )
package net.opengis.wfs;

import javax.xml.bind.annotation.XmlNs;
