
package net.opengis.wfs;

import java.math.BigInteger;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.eclipse.persistence.oxm.annotations.XmlPath;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="member" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="bag_adres">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="bag_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *                             &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="gebruiksdoel" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="soort" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="oppervlakte" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *                             &lt;element name="bouwjaar_verblijfobject" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *                             &lt;element name="hoogste_bouwlaag" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *                             &lt;element name="laagste_bouwlaag" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *                             &lt;element name="nummeraanduiding_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *                             &lt;element name="hoofdadres" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="straatnaam" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="nen_straatnaam" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="huisnummer" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *                             &lt;element name="postcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="plaatsnaam" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="woonplaats_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *                             &lt;element name="openbareruimte_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *                             &lt;element name="postcode_num" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *                             &lt;element name="postcode_alf" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="buurt" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="parkeerzone" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="wijk" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="stadsdeel" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="pczoek" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="adreszoek" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="geom">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="Point">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="pos" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                               &lt;/sequence>
 *                                               &lt;attribute name="srsDimension" type="{http://www.w3.org/2001/XMLSchema}integer" />
 *                                               &lt;attribute name="srsName" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                           &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="xs" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="xsi" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="numberMatched" type="{http://www.w3.org/2001/XMLSchema}integer" />
 *       &lt;attribute name="numberReturned" type="{http://www.w3.org/2001/XMLSchema}integer" />
 *       &lt;attribute name="timeStamp" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="schemaLocation" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "member" })
@XmlRootElement(name = "FeatureCollection")
public class FeatureCollection {

    @XmlElement(required = true)
    protected List<FeatureCollection.Member> member;
    @XmlAttribute
    protected String xs;
    @XmlAttribute
    protected String xsi;
    @XmlAttribute
    protected BigInteger numberMatched;
    @XmlAttribute
    protected BigInteger numberReturned;
    @XmlAttribute
    protected String timeStamp;
    @XmlAttribute
    protected String schemaLocation;

    /**
     * Gets the value of the member property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the member property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMember().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeatureCollection.Member }
     *
     *
     */
    public List<FeatureCollection.Member> getMember() {
        if (member == null) {
            member = new ArrayList<FeatureCollection.Member>();
        }
        return this.member;
    }

    /**
     * Gets the value of the xs property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getXs() {
        return xs;
    }

    /**
     * Sets the value of the xs property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setXs(String value) {
        this.xs = value;
    }

    /**
     * Gets the value of the xsi property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getXsi() {
        return xsi;
    }

    /**
     * Sets the value of the xsi property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setXsi(String value) {
        this.xsi = value;
    }

    /**
     * Gets the value of the numberMatched property.
     *
     * @return
     *     possible object is
     *     {@link BigInteger }
     *
     */
    public BigInteger getNumberMatched() {
        return numberMatched;
    }

    /**
     * Sets the value of the numberMatched property.
     *
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *
     */
    public void setNumberMatched(BigInteger value) {
        this.numberMatched = value;
    }

    /**
     * Gets the value of the numberReturned property.
     *
     * @return
     *     possible object is
     *     {@link BigInteger }
     *
     */
    public BigInteger getNumberReturned() {
        return numberReturned;
    }

    /**
     * Sets the value of the numberReturned property.
     *
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *
     */
    public void setNumberReturned(BigInteger value) {
        this.numberReturned = value;
    }

    /**
     * Gets the value of the timeStamp property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTimeStamp() {
        return timeStamp;
    }

    /**
     * Sets the value of the timeStamp property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTimeStamp(String value) {
        this.timeStamp = value;
    }

    /**
     * Gets the value of the schemaLocation property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getSchemaLocation() {
        return schemaLocation;
    }

    /**
     * Sets the value of the schemaLocation property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setSchemaLocation(String value) {
        this.schemaLocation = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="bag_adres">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="bag_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
     *                   &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="gebruiksdoel" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="soort" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="oppervlakte" type="{http://www.w3.org/2001/XMLSchema}integer"/>
     *                   &lt;element name="bouwjaar_verblijfobject" type="{http://www.w3.org/2001/XMLSchema}integer"/>
     *                   &lt;element name="hoogste_bouwlaag" type="{http://www.w3.org/2001/XMLSchema}integer"/>
     *                   &lt;element name="laagste_bouwlaag" type="{http://www.w3.org/2001/XMLSchema}integer"/>
     *                   &lt;element name="nummeraanduiding_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
     *                   &lt;element name="hoofdadres" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="straatnaam" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="nen_straatnaam" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="huisnummer" type="{http://www.w3.org/2001/XMLSchema}integer"/>
     *                   &lt;element name="postcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="plaatsnaam" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="woonplaats_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
     *                   &lt;element name="openbareruimte_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
     *                   &lt;element name="postcode_num" type="{http://www.w3.org/2001/XMLSchema}integer"/>
     *                   &lt;element name="postcode_alf" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="buurt" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="parkeerzone" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="wijk" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="stadsdeel" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="pczoek" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="adreszoek" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="geom">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="Point">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="pos" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                     &lt;/sequence>
     *                                     &lt;attribute name="srsDimension" type="{http://www.w3.org/2001/XMLSchema}integer" />
     *                                     &lt;attribute name="srsName" type="{http://www.w3.org/2001/XMLSchema}string" />
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *                 &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}string" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     *
     *
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = { "bagAdres" })
    public static class Member {

        @XmlElement(name = "gemeentehaarlem:bag_adres", required = true)
       // @XmlPath("wfs:FeatureCollection/wfs:member/gemeentehaarlem:bag_adres")
        protected FeatureCollection.Member.BagAdres bagAdres;

        /**
         * Gets the value of the bagAdres property.
         *
         * @return
         *     possible object is
         *     {@link FeatureCollection.Member.BagAdres }
         *
         */
        @XmlPath("wfs:FeatureCollection/wfs:member/gemeentehaarlem:bag_adres")
        public FeatureCollection.Member.BagAdres getBagAdres() {
            return bagAdres;
        }

        /**
         * Sets the value of the bagAdres property.
         *
         * @param value
         *     allowed object is
         *     {@link FeatureCollection.Member.BagAdres }
         *
         */
        public void setBagAdres(FeatureCollection.Member.BagAdres value) {
            this.bagAdres = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         *
         * <p>The following schema fragment specifies the expected content contained within this class.
         *
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="bag_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
         *         &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="gebruiksdoel" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="soort" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="oppervlakte" type="{http://www.w3.org/2001/XMLSchema}integer"/>
         *         &lt;element name="bouwjaar_verblijfobject" type="{http://www.w3.org/2001/XMLSchema}integer"/>
         *         &lt;element name="hoogste_bouwlaag" type="{http://www.w3.org/2001/XMLSchema}integer"/>
         *         &lt;element name="laagste_bouwlaag" type="{http://www.w3.org/2001/XMLSchema}integer"/>
         *         &lt;element name="nummeraanduiding_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
         *         &lt;element name="hoofdadres" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="straatnaam" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="nen_straatnaam" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="huisnummer" type="{http://www.w3.org/2001/XMLSchema}integer"/>
         *         &lt;element name="postcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="plaatsnaam" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="woonplaats_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
         *         &lt;element name="openbareruimte_id" type="{http://www.w3.org/2001/XMLSchema}integer"/>
         *         &lt;element name="postcode_num" type="{http://www.w3.org/2001/XMLSchema}integer"/>
         *         &lt;element name="postcode_alf" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="buurt" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="parkeerzone" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="wijk" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="stadsdeel" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="pczoek" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="adreszoek" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="geom">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="Point">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="pos" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                           &lt;/sequence>
         *                           &lt;attribute name="srsDimension" type="{http://www.w3.org/2001/XMLSchema}integer" />
         *                           &lt;attribute name="srsName" type="{http://www.w3.org/2001/XMLSchema}string" />
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}string" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         *
         *
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "",
                 propOrder = { "name", "bagId", "type", "status", "gebruiksdoel",
                               "soort", "oppervlakte",
                               "bouwjaarVerblijfobject", "hoogsteBouwlaag",
                               "laagsteBouwlaag", "nummeraanduidingId",
                               "hoofdadres", "straatnaam", "nenStraatnaam",
                               "huisnummer", "postcode", "plaatsnaam",
                               "woonplaatsId", "openbareruimteId",
                               "postcodeNum", "postcodeAlf", "buurt",
                               "parkeerzone", "wijk", "stadsdeel", "pczoek",
                               "adreszoek", "geom" })
        public static class BagAdres {

            @XmlElement(required = true)
            protected String name;
            @XmlElement(name = "bag_id", required = true)
            protected BigInteger bagId;
            @XmlElement(required = true)
            protected String type;
            @XmlElement(required = true)
            protected String status;
            @XmlElement(required = true)
            protected String gebruiksdoel;
            @XmlElement(required = true)
            protected String soort;
            @XmlElement(required = true)
            protected BigInteger oppervlakte;
            @XmlElement(name = "bouwjaar_verblijfobject", required = true)
            protected BigInteger bouwjaarVerblijfobject;
            @XmlElement(name = "hoogste_bouwlaag", required = true)
            protected BigInteger hoogsteBouwlaag;
            @XmlElement(name = "laagste_bouwlaag", required = true)
            protected BigInteger laagsteBouwlaag;
            @XmlElement(name = "nummeraanduiding_id", required = true)
            protected BigInteger nummeraanduidingId;
            @XmlElement(required = true)
            protected String hoofdadres;
            @XmlElement(required = true)
            protected String straatnaam;
            @XmlElement(name = "nen_straatnaam", required = true)
            protected String nenStraatnaam;
            @XmlElement(required = true)
            protected BigInteger huisnummer;
            @XmlElement(required = true)
            protected String postcode;
            @XmlElement(required = true)
            protected String plaatsnaam;
            @XmlElement(name = "woonplaats_id", required = true)
            protected BigInteger woonplaatsId;
            @XmlElement(name = "openbareruimte_id", required = true)
            protected BigInteger openbareruimteId;
            @XmlElement(name = "postcode_num", required = true)
            protected BigInteger postcodeNum;
            @XmlElement(name = "postcode_alf", required = true)
            protected String postcodeAlf;
            @XmlElement(required = true)
            protected String buurt;
            @XmlElement(name ="gemeentehaarlem:parkeerzone" , required = true)
            protected String parkeerzone;
            @XmlElement(required = true)
            protected String wijk;
            @XmlElement(required = true)
            protected String stadsdeel;
            @XmlElement(required = true)
            protected String pczoek;
            @XmlElement(required = true)
            protected String adreszoek;
            @XmlElement(required = true)
            protected FeatureCollection.Member.BagAdres.Geom geom;
            @XmlAttribute
            protected String id;

            /**
             * Gets the value of the name property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getName() {
                return name;
            }

            /**
             * Sets the value of the name property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setName(String value) {
                this.name = value;
            }

            /**
             * Gets the value of the bagId property.
             *
             * @return
             *     possible object is
             *     {@link BigInteger }
             *
             */
            public BigInteger getBagId() {
                return bagId;
            }

            /**
             * Sets the value of the bagId property.
             *
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *
             */
            public void setBagId(BigInteger value) {
                this.bagId = value;
            }

            /**
             * Gets the value of the type property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getType() {
                return type;
            }

            /**
             * Sets the value of the type property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setType(String value) {
                this.type = value;
            }

            /**
             * Gets the value of the status property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getStatus() {
                return status;
            }

            /**
             * Sets the value of the status property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setStatus(String value) {
                this.status = value;
            }

            /**
             * Gets the value of the gebruiksdoel property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getGebruiksdoel() {
                return gebruiksdoel;
            }

            /**
             * Sets the value of the gebruiksdoel property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setGebruiksdoel(String value) {
                this.gebruiksdoel = value;
            }

            /**
             * Gets the value of the soort property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getSoort() {
                return soort;
            }

            /**
             * Sets the value of the soort property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setSoort(String value) {
                this.soort = value;
            }

            /**
             * Gets the value of the oppervlakte property.
             *
             * @return
             *     possible object is
             *     {@link BigInteger }
             *
             */
            public BigInteger getOppervlakte() {
                return oppervlakte;
            }

            /**
             * Sets the value of the oppervlakte property.
             *
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *
             */
            public void setOppervlakte(BigInteger value) {
                this.oppervlakte = value;
            }

            /**
             * Gets the value of the bouwjaarVerblijfobject property.
             *
             * @return
             *     possible object is
             *     {@link BigInteger }
             *
             */
            public BigInteger getBouwjaarVerblijfobject() {
                return bouwjaarVerblijfobject;
            }

            /**
             * Sets the value of the bouwjaarVerblijfobject property.
             *
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *
             */
            public void setBouwjaarVerblijfobject(BigInteger value) {
                this.bouwjaarVerblijfobject = value;
            }

            /**
             * Gets the value of the hoogsteBouwlaag property.
             *
             * @return
             *     possible object is
             *     {@link BigInteger }
             *
             */
            public BigInteger getHoogsteBouwlaag() {
                return hoogsteBouwlaag;
            }

            /**
             * Sets the value of the hoogsteBouwlaag property.
             *
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *
             */
            public void setHoogsteBouwlaag(BigInteger value) {
                this.hoogsteBouwlaag = value;
            }

            /**
             * Gets the value of the laagsteBouwlaag property.
             *
             * @return
             *     possible object is
             *     {@link BigInteger }
             *
             */
            public BigInteger getLaagsteBouwlaag() {
                return laagsteBouwlaag;
            }

            /**
             * Sets the value of the laagsteBouwlaag property.
             *
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *
             */
            public void setLaagsteBouwlaag(BigInteger value) {
                this.laagsteBouwlaag = value;
            }

            /**
             * Gets the value of the nummeraanduidingId property.
             *
             * @return
             *     possible object is
             *     {@link BigInteger }
             *
             */
            public BigInteger getNummeraanduidingId() {
                return nummeraanduidingId;
            }

            /**
             * Sets the value of the nummeraanduidingId property.
             *
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *
             */
            public void setNummeraanduidingId(BigInteger value) {
                this.nummeraanduidingId = value;
            }

            /**
             * Gets the value of the hoofdadres property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getHoofdadres() {
                return hoofdadres;
            }

            /**
             * Sets the value of the hoofdadres property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setHoofdadres(String value) {
                this.hoofdadres = value;
            }

            /**
             * Gets the value of the straatnaam property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getStraatnaam() {
                return straatnaam;
            }

            /**
             * Sets the value of the straatnaam property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setStraatnaam(String value) {
                this.straatnaam = value;
            }

            /**
             * Gets the value of the nenStraatnaam property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getNenStraatnaam() {
                return nenStraatnaam;
            }

            /**
             * Sets the value of the nenStraatnaam property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setNenStraatnaam(String value) {
                this.nenStraatnaam = value;
            }

            /**
             * Gets the value of the huisnummer property.
             *
             * @return
             *     possible object is
             *     {@link BigInteger }
             *
             */
            public BigInteger getHuisnummer() {
                return huisnummer;
            }

            /**
             * Sets the value of the huisnummer property.
             *
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *
             */
            public void setHuisnummer(BigInteger value) {
                this.huisnummer = value;
            }

            /**
             * Gets the value of the postcode property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getPostcode() {
                return postcode;
            }

            /**
             * Sets the value of the postcode property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setPostcode(String value) {
                this.postcode = value;
            }

            /**
             * Gets the value of the plaatsnaam property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getPlaatsnaam() {
                return plaatsnaam;
            }

            /**
             * Sets the value of the plaatsnaam property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setPlaatsnaam(String value) {
                this.plaatsnaam = value;
            }

            /**
             * Gets the value of the woonplaatsId property.
             *
             * @return
             *     possible object is
             *     {@link BigInteger }
             *
             */
            public BigInteger getWoonplaatsId() {
                return woonplaatsId;
            }

            /**
             * Sets the value of the woonplaatsId property.
             *
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *
             */
            public void setWoonplaatsId(BigInteger value) {
                this.woonplaatsId = value;
            }

            /**
             * Gets the value of the openbareruimteId property.
             *
             * @return
             *     possible object is
             *     {@link BigInteger }
             *
             */
            public BigInteger getOpenbareruimteId() {
                return openbareruimteId;
            }

            /**
             * Sets the value of the openbareruimteId property.
             *
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *
             */
            public void setOpenbareruimteId(BigInteger value) {
                this.openbareruimteId = value;
            }

            /**
             * Gets the value of the postcodeNum property.
             *
             * @return
             *     possible object is
             *     {@link BigInteger }
             *
             */
            public BigInteger getPostcodeNum() {
                return postcodeNum;
            }

            /**
             * Sets the value of the postcodeNum property.
             *
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *
             */
            public void setPostcodeNum(BigInteger value) {
                this.postcodeNum = value;
            }

            /**
             * Gets the value of the postcodeAlf property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getPostcodeAlf() {
                return postcodeAlf;
            }

            /**
             * Sets the value of the postcodeAlf property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setPostcodeAlf(String value) {
                this.postcodeAlf = value;
            }

            /**
             * Gets the value of the buurt property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getBuurt() {
                return buurt;
            }

            /**
             * Sets the value of the buurt property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setBuurt(String value) {
                this.buurt = value;
            }

            /**
             * Gets the value of the parkeerzone property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getParkeerzone() {
                return parkeerzone;
            }

            /**
             * Sets the value of the parkeerzone property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setParkeerzone(String value) {
                this.parkeerzone = value;
            }

            /**
             * Gets the value of the wijk property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getWijk() {
                return wijk;
            }

            /**
             * Sets the value of the wijk property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setWijk(String value) {
                this.wijk = value;
            }

            /**
             * Gets the value of the stadsdeel property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getStadsdeel() {
                return stadsdeel;
            }

            /**
             * Sets the value of the stadsdeel property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setStadsdeel(String value) {
                this.stadsdeel = value;
            }

            /**
             * Gets the value of the pczoek property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getPczoek() {
                return pczoek;
            }

            /**
             * Sets the value of the pczoek property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setPczoek(String value) {
                this.pczoek = value;
            }

            /**
             * Gets the value of the adreszoek property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getAdreszoek() {
                return adreszoek;
            }

            /**
             * Sets the value of the adreszoek property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setAdreszoek(String value) {
                this.adreszoek = value;
            }

            /**
             * Gets the value of the geom property.
             *
             * @return
             *     possible object is
             *     {@link FeatureCollection.Member.BagAdres.Geom }
             *
             */
            public FeatureCollection.Member.BagAdres.Geom getGeom() {
                return geom;
            }

            /**
             * Sets the value of the geom property.
             *
             * @param value
             *     allowed object is
             *     {@link FeatureCollection.Member.BagAdres.Geom }
             *
             */
            public void setGeom(FeatureCollection.Member.BagAdres.Geom value) {
                this.geom = value;
            }

            /**
             * Gets the value of the id property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getId() {
                return id;
            }

            /**
             * Sets the value of the id property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setId(String value) {
                this.id = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             *
             * <p>The following schema fragment specifies the expected content contained within this class.
             *
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="Point">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="pos" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                 &lt;/sequence>
             *                 &lt;attribute name="srsDimension" type="{http://www.w3.org/2001/XMLSchema}integer" />
             *                 &lt;attribute name="srsName" type="{http://www.w3.org/2001/XMLSchema}string" />
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             *
             *
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = { "point" })
            public static class Geom {

                @XmlElement(name = "Point", required = true)
                protected FeatureCollection.Member.BagAdres.Geom.Point point;

                /**
                 * Gets the value of the point property.
                 *
                 * @return
                 *     possible object is
                 *     {@link FeatureCollection.Member.BagAdres.Geom.Point }
                 *
                 */
                public FeatureCollection.Member.BagAdres.Geom.Point getPoint() {
                    return point;
                }

                /**
                 * Sets the value of the point property.
                 *
                 * @param value
                 *     allowed object is
                 *     {@link FeatureCollection.Member.BagAdres.Geom.Point }
                 *
                 */
                public void setPoint(FeatureCollection.Member.BagAdres.Geom.Point value) {
                    this.point = value;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 *
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 *
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="pos" type="{http://www.w3.org/2001/XMLSchema}string"/>
                 *       &lt;/sequence>
                 *       &lt;attribute name="srsDimension" type="{http://www.w3.org/2001/XMLSchema}integer" />
                 *       &lt;attribute name="srsName" type="{http://www.w3.org/2001/XMLSchema}string" />
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 *
                 *
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = { "pos" })
                public static class Point {

                    @XmlElement(required = true)
                    protected String pos;
                    @XmlAttribute
                    protected BigInteger srsDimension;
                    @XmlAttribute
                    protected String srsName;

                    /**
                     * Gets the value of the pos property.
                     *
                     * @return
                     *     possible object is
                     *     {@link String }
                     *
                     */
                    public String getPos() {
                        return pos;
                    }

                    /**
                     * Sets the value of the pos property.
                     *
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *
                     */
                    public void setPos(String value) {
                        this.pos = value;
                    }

                    /**
                     * Gets the value of the srsDimension property.
                     *
                     * @return
                     *     possible object is
                     *     {@link BigInteger }
                     *
                     */
                    public BigInteger getSrsDimension() {
                        return srsDimension;
                    }

                    /**
                     * Sets the value of the srsDimension property.
                     *
                     * @param value
                     *     allowed object is
                     *     {@link BigInteger }
                     *
                     */
                    public void setSrsDimension(BigInteger value) {
                        this.srsDimension = value;
                    }

                    /**
                     * Gets the value of the srsName property.
                     *
                     * @return
                     *     possible object is
                     *     {@link String }
                     *
                     */
                    public String getSrsName() {
                        return srsName;
                    }

                    /**
                     * Sets the value of the srsName property.
                     *
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *
                     */
                    public void setSrsName(String value) {
                        this.srsName = value;
                    }

                }

            }

        }

    }

}
