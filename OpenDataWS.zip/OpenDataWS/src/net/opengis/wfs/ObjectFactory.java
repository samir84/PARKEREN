
package net.opengis.wfs;

import javax.xml.bind.annotation.XmlRegistry;

import net.opengis.wfs.FeatureCollection.Member;
import net.opengis.wfs.FeatureCollection.Member.BagAdres;
import net.opengis.wfs.FeatureCollection.Member.BagAdres.Geom;
import net.opengis.wfs.FeatureCollection.Member.BagAdres.Geom.Point;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the net.opengis.wfs package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: net.opengis.wfs
     *
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link FeatureCollection }
     *
     */
    public FeatureCollection createFeatureCollection() {
        return new FeatureCollection();
    }

    /**
     * Create an instance of {@link FeatureCollection.Member }
     *
     */
    public FeatureCollection.Member createFeatureCollectionMember() {
        return new FeatureCollection.Member();
    }

    /**
     * Create an instance of {@link FeatureCollection.Member.BagAdres }
     *
     */
    public FeatureCollection.Member.BagAdres createFeatureCollectionMemberBagAdres() {
        return new FeatureCollection.Member.BagAdres();
    }

    /**
     * Create an instance of {@link FeatureCollection.Member.BagAdres.Geom }
     *
     */
    public FeatureCollection.Member.BagAdres.Geom createFeatureCollectionMemberBagAdresGeom() {
        return new FeatureCollection.Member.BagAdres.Geom();
    }

    /**
     * Create an instance of {@link OphalenParkeerZoneRequest }
     *
     */
    public OphalenParkeerZoneRequest createOphalenParkeerZoneRequest() {
        return new OphalenParkeerZoneRequest();
    }

    /**
     * Create an instance of {@link FeatureCollection.Member.BagAdres.Geom.Point }
     *
     */
    public FeatureCollection.Member.BagAdres.Geom.Point createFeatureCollectionMemberBagAdresGeomPoint() {
        return new FeatureCollection.Member.BagAdres.Geom.Point();
    }

}
