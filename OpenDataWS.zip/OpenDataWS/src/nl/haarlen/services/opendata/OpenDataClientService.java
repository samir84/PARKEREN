package nl.haarlen.services.opendata;

import java.io.File;

import java.io.StringReader;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import javax.xml.bind.JAXBContext;

import javax.xml.bind.Unmarshaller;


import javax.xml.ws.BindingType;
import javax.xml.ws.soap.SOAPBinding;

import net.opengis.wfs.FeatureCollection;

import net.opengis.wfs.OphalenParkeerZoneRequest;

import nl.haarlen.services.opendata.helper.XmlHelper;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;


@WebService(serviceName = "OpenDataClientService", portName = "OpenDataClientServiceSoap12HttpPort")
@BindingType(SOAPBinding.SOAP12HTTP_BINDING)
public class OpenDataClientService {
   
    private ClientCustomSSL clientCustomSSL;
    @WebMethod
    public String getPath(){
        return this.getClass().getClassLoader().getResource("").getPath();
    }
    public String getParkeerZoneByPostcode(OphalenParkeerZoneRequest parkeerZoneRequest){
        
        
        String parkeerZone = null;
        clientCustomSSL = new ClientCustomSSL("src/KeyStore.jks","tarazana");
        try{
            //read content as string
            String url = parkeerZoneRequest.getUri();
            List<NameValuePair> nvPairList = new ArrayList<NameValuePair>(1);
            //
            
            NameValuePair service = new BasicNameValuePair("service", parkeerZoneRequest.getService());
            NameValuePair version = new BasicNameValuePair("version", parkeerZoneRequest.getVersion());
            NameValuePair request = new BasicNameValuePair("request", parkeerZoneRequest.getRequest());
            NameValuePair typeName = new BasicNameValuePair("typeName", parkeerZoneRequest.getTypeName());
            NameValuePair SrsName = new BasicNameValuePair("SrsName", parkeerZoneRequest.getSrsName());
            NameValuePair cql_filter = new BasicNameValuePair("cql_filter", parkeerZoneRequest.getCqlFilter());
            nvPairList.add(service);
            nvPairList.add(version);/*  */nvPairList.add(service);
            nvPairList.add(request);
            nvPairList.add(typeName);
            nvPairList.add(SrsName);
            nvPairList.add(cql_filter);
            
            String content = clientCustomSSL.getResponseAsString(url, nvPairList);
            //unmarshal string return objects
            JAXBContext jaxbContext = JAXBContext.newInstance("net.opengis.wfs");
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            FeatureCollection  parkeerZoneResponse = (FeatureCollection) jaxbUnmarshaller.unmarshal(new StringReader(content));
            System.out.println();
            if(parkeerZoneResponse.getMember().size() > 0 && parkeerZoneResponse.getMember().get(0).getBagAdres()!= null){
                parkeerZone = parkeerZoneResponse.getMember().get(0).getBagAdres().getParkeerzone();
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }
        return parkeerZone;
    }
}
