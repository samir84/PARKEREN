package nl.haarlen.services.opendata.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.net.URI;

import java.net.URISyntaxException;

import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import java.io.IOException;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.UnknownHostException;

import java.security.KeyManagementException;

import java.security.KeyStore;

import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.net.SocketFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;

import org.apache.http.ssl.SSLContexts;
import javax.net.ssl.TrustManager;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;

public class mainApp {

    private static final String CLIENT_KEYSTORE_PATH = "src/KeyStore.jks";
    private static final String CLIENT_KEYSTORE_PASS = "tarazana";


    public static void main(String[] args) throws IOException,
                                                  URISyntaxException,
                                                  NoSuchAlgorithmException,
                                                  KeyStoreException,
                                                  CertificateException,
                                                  KeyManagementException {

        new mainApp().testApp();
        
    }

    public String testApp() throws IOException, URISyntaxException,
                                   NoSuchAlgorithmException,
                                   KeyStoreException,
                                   CertificateException,
                                   KeyManagementException {
        String responseBody = null;

        String url =
            "https://wfs.haarlem.nl/ows?service=WFS&version=2.0&request=GetFeature&typeName=gemeentehaarlem:bag_adres&SrsName=EPSG%3A3857";
        List<NameValuePair> nvPairList = new ArrayList<NameValuePair>(1);
        NameValuePair nv1 =
            new BasicNameValuePair("cql_filter", "postcode='2011 JS' and huisnummer='11'");
        nvPairList.add(nv1);

        // Trust own CA and all self-signed certs
                SSLContext sslcontext = SSLContexts.custom()
                        .loadTrustMaterial(new File(CLIENT_KEYSTORE_PATH), CLIENT_KEYSTORE_PASS.toCharArray(),
                                new TrustSelfSignedStrategy())
                        .build();
                // Allow TLSv1 protocol only
                SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, SSLConnectionSocketFactory.getDefaultHostnameVerifier())
                {


                    protected void prepareSocket(SSLSocket socket) throws IOException {

                    // Workaround to use different order of CipherSuites used by Java6 in order
                        // to avoid the the problem of java7 "Could not generate DH keypair"
                        String[] enabledCipherSuites = socket.getEnabledCipherSuites();

                        // but to avoid hardcoding a new list, we just remove the entries
                        // which cause the exception (via TrialAndError)
                        List<String> asList = new ArrayList(Arrays.asList(enabledCipherSuites));

                        // we identified the following entries causeing the problems
                        // "Could not generate DH keypair"
                        // and "Caused by: java.security.InvalidAlgorithmParameterException: Prime size must be multiple of 64, and can only range from 512 to 1024 (inclusive)"
                        asList.remove("TLS_DHE_RSA_WITH_AES_128_CBC_SHA");
                        asList.remove("SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA");
                        asList.remove("TLS_DHE_RSA_WITH_AES_256_CBC_SHA");

                        String[] array = asList.toArray(new String[0]);
                        socket.setEnabledCipherSuites(array);

                    };
                };

                //
       
        CloseableHttpClient httpclient = HttpClients.custom()
                        .setSSLSocketFactory(sslsf)
                        .build();
        try {

            
            HttpGet request = new HttpGet(url);
            URI uri = new URIBuilder(request.getURI()).addParameters(nvPairList).build();
            request.setURI(uri);
            System.out.println("Executing request " + request.getRequestLine());

            CloseableHttpResponse response = httpclient.execute(request);
            try {
                            HttpEntity entity = response.getEntity();

                            System.out.println("----------------------------------------");
                            System.out.println(response.getStatusLine());
                
                            //System.out.println(response.getEntity().getContent().;
                            EntityUtils.consume(entity);
                        } finally {
                            response.close();
                        }
        } finally {
            httpclient.close();
        }

        return responseBody;
    }
   


}
