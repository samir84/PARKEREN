package nl.haarlen.services.opendata.helper;

public class XmlHelper {
   
    
    
    public static String removeXmlStringNamespaceAndPreamble(String xmlString) {
      return xmlString.replaceAll("(<\\?[^<]*\\?>)?", ""). /* remove preamble */
      replaceAll("xmlns.*?(\"|\').*?(\"|\')", "") /* remove xmlns declaration */
      .replaceAll("(<)(\\w+:)(.*?>)", "$1$3") /* remove opening tag prefix */
      .replaceAll("(</)(\\w+:)(.*?>)", "$1$3"); /* remove closing tags prefix */
    }
}
