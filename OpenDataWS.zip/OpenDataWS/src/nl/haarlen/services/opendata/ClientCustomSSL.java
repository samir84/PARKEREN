package nl.haarlen.services.opendata;

import java.io.File;
import java.io.IOException;

import java.net.URI;

import java.net.URISyntaxException;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.net.ssl.SSLContext;

import javax.net.ssl.SSLSocket;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;

public class ClientCustomSSL {

    private String clientKeyStorePath;
    private String clientKeyStorePassword;

    public ClientCustomSSL(String clientKeyStorePath,
                           String clientKeyStorePassword) {
        super();
        this.clientKeyStorePath = clientKeyStorePath;
        this.clientKeyStorePassword = clientKeyStorePassword;
    }


    private CloseableHttpClient getHttpClient(List<NameValuePair> nvPairList) throws NoSuchAlgorithmException,
                                                                                     KeyStoreException,
                                                                                     CertificateException,
                                                                                     IOException,
                                                                                     KeyManagementException {

        // Trust own CA and all self-signed certs
        SSLContext sslcontext =
            SSLContexts.custom().loadTrustMaterial(new File(this.clientKeyStorePath),
                                                   this.clientKeyStorePassword.toCharArray(),
                                                   new TrustSelfSignedStrategy()).build();
        // Allow TLSv1 protocol only
        SSLConnectionSocketFactory sslsf =
            new SSLConnectionSocketFactory(sslcontext,
                                           SSLConnectionSocketFactory.getDefaultHostnameVerifier()) {


            protected void prepareSocket(SSLSocket socket) throws IOException {

                // Workaround to use different order of CipherSuites used by Java6 in order
                // to avoid the the problem of java7 "Could not generate DH keypair"
                String[] enabledCipherSuites = socket.getEnabledCipherSuites();

                // but to avoid hardcoding a new list, we just remove the entries
                // which cause the exception (via TrialAndError)
                List<String> asList =
                    new ArrayList(Arrays.asList(enabledCipherSuites));

                // we identified the following entries causeing the problems
                // "Could not generate DH keypair"
                // and "Caused by: java.security.InvalidAlgorithmParameterException: Prime size must be multiple of 64, and can only range from 512 to 1024 (inclusive)"
                asList.remove("TLS_DHE_RSA_WITH_AES_128_CBC_SHA");
                asList.remove("SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA");
                asList.remove("TLS_DHE_RSA_WITH_AES_256_CBC_SHA");

                String[] array = asList.toArray(new String[0]);
                socket.setEnabledCipherSuites(array);

            }
        };
        CloseableHttpClient httpclient =
            HttpClients.custom().setSSLSocketFactory(sslsf).build();
        return httpclient;
    }

    public String getResponseAsString(String url,
                                      List<NameValuePair> nvPairList) throws IOException,
                                                                             ClientProtocolException,
                                                                             NoSuchAlgorithmException,
                                                                             KeyStoreException,
                                                                             CertificateException,
                                                                             KeyManagementException,
                                                                             URISyntaxException {
        String responseString = null;
        CloseableHttpResponse response = null;
        CloseableHttpClient httpClient = getHttpClient(nvPairList);
        try {
            HttpGet request = new HttpGet(url);
            URI uri = new URIBuilder(request.getURI()).addParameters(nvPairList).build();
            request.setURI(uri);
            System.out.println("Executing request " +
                               request.getRequestLine());
             response = httpClient.execute(request);

            HttpEntity entity = response.getEntity();
            System.out.println(response.getStatusLine());
            responseString = EntityUtils.toString(entity, "UTF-8");
            EntityUtils.consume(entity);
        } finally {
            response.close();
        }
        return responseString;
    }

    public void setClientKeyStorePath(String clientKeyStorePath) {
        this.clientKeyStorePath = clientKeyStorePath;
    }

    public String getClientKeyStorePath() {
        return clientKeyStorePath;
    }

    public void setClientKeyStorePassword(String clientKeyStorePassword) {
        this.clientKeyStorePassword = clientKeyStorePassword;
    }

    public String getClientKeyStorePassword() {
        return clientKeyStorePassword;
    }
}
