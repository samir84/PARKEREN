package nl.haarlem.services.validation;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import nl.haarlem.validations.EmailValidator;

import org.iban4j.IbanUtil;


@WebService(serviceName = "ValidationService")
public class ValidationService {
    
    private EmailValidator emailValidator = new EmailValidator();

    @WebMethod
    @WebResult(name = "EmailValidatie")
    public boolean validateEmail(@WebParam(name="email") String email){
       
       return emailValidator.validate(email);
    }

    @WebMethod
    @WebResult(name = "IbanValidatie")
    public IbanValidation validateIban(@WebParam(name="iban")String iban){
            IbanValidation ibanValid = new IbanValidation();
            try {
                IbanUtil.validate(iban);
                ibanValid.setStatus("success");
                ibanValid.setMessage("Iban: "+iban+" is valid.");
                ibanValid.setDate(new Date());
                // valid
            } catch (Exception  e) {
                e.printStackTrace();
                ibanValid.setStatus("error");
                ibanValid.setMessage(e.getMessage());
                ibanValid.setDate(new Date());
            }
            return ibanValid;
        }
}
