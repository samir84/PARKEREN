package parkeerrechtendb;

import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;

import javax.naming.NamingException;

import nl.haarlem.services.parkeerrechten.ParkeerrechtenSessionEJB;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity;


public class ParkeerrechtenSessionEJBClient {
    public static void main(String[] args) {
        try {
            final Context context = getInitialContext();
            ParkeerrechtenSessionEJB parkeerrechtenSessionEJB =
                (ParkeerrechtenSessionEJB)context.lookup("ParkeerrechtenDB#nl.haarlem.services.parkeerrechten.ParkeerrechtenSessionEJB");
            //           List<RegistratieEntity> list = (List<RegistratieEntity>)parkeerrechtenSessionEJB.getRegistratieFindAll();
            //            for (Registratie registratie : (List<Registratie>)parkeerrechtenSessionEJB.getRegistratieFindAll()) {
            //                printRegistratie(registratie);
            //            }
            //            for (Recht recht : (List<Recht>)parkeerrechtenSessionEJB.getRechtFindAll()) {
            //                printRecht(recht);
            //            }
            System.out.println("test");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static void printRegistratie(RegistratieEntity registratie) {
        System.out.println("bedrag = " + registratie.getBedrag());
        System.out.println("begintijd = " + registratie.getBegintijd());
        System.out.println("eindtijd = " + registratie.getEindtijd());
        System.out.println("id = " + registratie.getId());
        System.out.println("kenteken = " + registratie.getKenteken());
        System.out.println("recht = " + registratie.getRecht());
    }

    private static void printRecht(RechtEntity recht) {
        System.out.println("aanmeldcode = " + recht.getAanmeldcode());
        System.out.println("begindatum = " + recht.getBegindatum());
        System.out.println("bsn = " + recht.getBsn());
        System.out.println("einddatum = " + recht.getEinddatum());
        System.out.println("id = " + recht.getId());
        System.out.println("zone = " + recht.getZone());
        System.out.println("registratieList = " + recht.getRegistratieList());
    }

    private static Context getInitialContext() throws NamingException {
        Hashtable env = new Hashtable();
        // WebLogic Server 10.x connection details
        env.put(Context.INITIAL_CONTEXT_FACTORY,
                "weblogic.jndi.WLInitialContextFactory");
        env.put(Context.PROVIDER_URL, "t3://wohso.ssc.lan:8001");
        return new InitialContext(env);
    }
}
