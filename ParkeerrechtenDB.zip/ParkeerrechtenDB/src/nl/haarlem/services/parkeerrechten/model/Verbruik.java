package nl.haarlem.services.parkeerrechten.model;

public class Verbruik {

    private Double kosten;
    private Double verbruik;


    public void setKosten(Double kosten) {
        this.kosten = kosten;
    }

    public Double getKosten() {
        return kosten;
    }

    public void setVerbruik(Double verbruik) {
        this.verbruik = verbruik;
    }

    public Double getVerbruik() {
        return verbruik;
    }
}
