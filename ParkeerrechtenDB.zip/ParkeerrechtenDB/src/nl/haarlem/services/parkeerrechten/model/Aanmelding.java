package nl.haarlem.services.parkeerrechten.model;

public class Aanmelding {
    
    private String activeringscode;
    private String kenteken;

    public void setActiveringscode(String activeringscode) {
        this.activeringscode = activeringscode;
    }

    public String getActiveringscode() {
        return activeringscode;
    }

    public void setKenteken(String kenteken) {
        this.kenteken = kenteken;
    }

    public String getKenteken() {
        return kenteken;
    }
}
