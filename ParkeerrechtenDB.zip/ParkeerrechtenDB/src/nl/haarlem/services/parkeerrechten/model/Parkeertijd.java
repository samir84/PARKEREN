package nl.haarlem.services.parkeerrechten.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Id;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;

public class Parkeertijd {
   
    private String dag;
    private String parkeerzone;
    private double tarief;
    private Timestamp begintijd;
    private Timestamp eindtijd;
    private Timestamp begintijdbetaaldparkeren;
    private Timestamp eindtijdbetaaldparkeren;


    public void setDag(String dag) {
        this.dag = dag;
    }

    public String getDag() {
        return dag;
    }

    public void setParkeerzone(String parkeerzone) {
        this.parkeerzone = parkeerzone;
    }

    public String getParkeerzone() {
        return parkeerzone;
    }

    public void setTarief(double tarief) {
        this.tarief = tarief;
    }

    public double getTarief() {
        return tarief;
    }

    public void setBegintijd(Timestamp begintijd) {
        this.begintijd = begintijd;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getBegintijd() {
        return begintijd;
    }

    public void setEindtijd(Timestamp eindtijd) {
        this.eindtijd = eindtijd;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getEindtijd() {
        return eindtijd;
    }

    public void setBegintijdbetaaldparkeren(Timestamp begintijdbetaaldparkeren) {
        this.begintijdbetaaldparkeren = begintijdbetaaldparkeren;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getBegintijdbetaaldparkeren() {
        return begintijdbetaaldparkeren;
    }

    public void setEindtijdbetaaldparkeren(Timestamp eindtijdbetaaldparkeren) {
        this.eindtijdbetaaldparkeren = eindtijdbetaaldparkeren;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getEindtijdbetaaldparkeren() {
        return eindtijdbetaaldparkeren;
    }
}
