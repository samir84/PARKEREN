package nl.haarlem.services.parkeerrechten.model;

public class Storting {

    private Double bedrag;


    public void setBedrag(Double bedrag) {
        this.bedrag = bedrag;
    }

    public Double getBedrag() {
        return bedrag;
    }
}
