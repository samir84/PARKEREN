package nl.haarlem.services.parkeerrechten.model;

import java.util.Calendar;

public class Saldo {

    private Double bedrag;
    private String aanmeldcode;
    private String betaalmethode;
    private Calendar datum;

    public void setBedrag(Double bedrag) {
        this.bedrag = bedrag;
    }

    public Double getBedrag() {
        return bedrag;
    }

    

    public void setBetaalmethode(String betaalmethode) {
        this.betaalmethode = betaalmethode;
    }

    public String getBetaalmethode() {
        return betaalmethode;
    }

    public void setDatum(Calendar datum) {
        this.datum = datum;
    }

    public Calendar getDatum() {
        return datum;
    }

    public void setAanmeldcode(String aanmeldcode) {
        this.aanmeldcode = aanmeldcode;
    }

    public String getAanmeldcode() {
        return aanmeldcode;
    }
}
