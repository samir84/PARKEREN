package nl.haarlem.services.parkeerrechten.model;

import java.util.Calendar;

public class Saldo {
    
    private Double bedrag;
    private String activeringscode;
    private String betaalmethode;
    private Calendar datum;

    public void setBedrag(Double bedrag) {
        this.bedrag = bedrag;
    }

    public Double getBedrag() {
        return bedrag;
    }

    public void setActiveringscode(String activeringscode) {
        this.activeringscode = activeringscode;
    }

    public String getActiveringscode() {
        return activeringscode;
    }

    public void setBetaalmethode(String betaalmethode) {
        this.betaalmethode = betaalmethode;
    }

    public String getBetaalmethode() {
        return betaalmethode;
    }

    public void setDatum(Calendar datum) {
        this.datum = datum;
    }

    public Calendar getDatum() {
        return datum;
    }
}
