package nl.haarlem.services.parkeerrechten.model;

import java.io.Serializable;

import java.util.Calendar;

import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;

public class Registratie implements Serializable {
    
    private Double bedrag;
    private Calendar begintijd;
    private Calendar eindtijd;
    private Long id;
    private String Activeringscode;
    private String kenteken;
    private String zone;
    
    public Registratie() {
        super();
    }

    public void setBedrag(Double bedrag) {
        this.bedrag = bedrag;
    }

    public Double getBedrag() {
        return bedrag;
    }

    public void setBegintijd(Calendar begintijd) {
        this.begintijd = begintijd;
    }

    public Calendar getBegintijd() {
        return begintijd;
    }

    public void setEindtijd(Calendar eindtijd) {
        this.eindtijd = eindtijd;
    }

    public Calendar getEindtijd() {
        return eindtijd;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setKenteken(String kenteken) {
        this.kenteken = kenteken;
    }

    public String getKenteken() {
        return kenteken;
    }

    public void setActiveringscode(String Activeringscode) {
        this.Activeringscode = Activeringscode;
    }

    public String getActiveringscode() {
        return Activeringscode;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getZone() {
        return zone;
    }
}
