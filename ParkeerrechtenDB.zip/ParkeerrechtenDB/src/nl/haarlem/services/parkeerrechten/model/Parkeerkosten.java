package nl.haarlem.services.parkeerrechten.model;

import java.util.Calendar;

public class Parkeerkosten {
    private String zone;
    private Calendar begintijd;
    private Calendar eindtijd;

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getZone() {
        return zone;
    }

    public void setBegintijd(Calendar begintijd) {
        this.begintijd = begintijd;
    }

    public Calendar getBegintijd() {
        return begintijd;
    }

    public void setEindtijd(Calendar eindtijd) {
        this.eindtijd = eindtijd;
    }

    public Calendar getEindtijd() {
        return eindtijd;
    }
}
