package nl.haarlem.services.parkeerrechten.model;

import java.io.Serializable;

import java.util.Calendar;

import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;

public class RechtType implements Serializable{
    private static final long serialVersionUID = 6194198511103620836L;

    private Calendar begindatum;
    private Calendar einddatum;
    private Long id;
    private RechtEntity recht;
    private String naam;


    public static long getSerialVersionUID() {
        return serialVersionUID;
    }


    public void setBegindatum(Calendar begindatum) {
        this.begindatum = begindatum;
    }

    public Calendar getBegindatum() {
        return begindatum;
    }

    public void setEinddatum(Calendar einddatum) {
        this.einddatum = einddatum;
    }

    public Calendar getEinddatum() {
        return einddatum;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setRecht(RechtEntity recht) {
        this.recht = recht;
    }

    public RechtEntity getRecht() {
        return recht;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public String getNaam() {
        return naam;
    }
}
