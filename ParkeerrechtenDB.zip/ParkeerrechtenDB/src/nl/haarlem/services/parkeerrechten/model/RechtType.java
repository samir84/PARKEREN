package nl.haarlem.services.parkeerrechten.model;

import java.io.Serializable;

import java.sql.Timestamp;

import java.util.Calendar;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;

//@XmlType (propOrder={"id","begindatum","einddatum","naam","recht","bestedingslimiet"})
public class RechtType implements Serializable {
    private static final long serialVersionUID = 6194198511103620836L;

    private Long id;
    private Timestamp begindatum;
    private Timestamp einddatum;
    private Recht recht;
    private String naam;
    private Double bestedingslimiet;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setRecht(Recht recht) {
        this.recht = recht;
    }

    public Recht getRecht() {
        return recht;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public String getNaam() {
        return naam;
    }

    public void setBegindatum(Timestamp begindatum) {
        this.begindatum = begindatum;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getBegindatum() {
        return begindatum;
    }

    public void setEinddatum(Timestamp einddatum) {
        this.einddatum = einddatum;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getEinddatum() {
        return einddatum;
    }

    public void setBestedingslimiet(Double bestedingslimiet) {
        this.bestedingslimiet = bestedingslimiet;
    }

    public Double getBestedingslimiet() {
        return bestedingslimiet;
    }
}
