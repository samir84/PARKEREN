package nl.haarlem.services.parkeerrechten.model;

import java.util.List;

import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;

public class Bestedingsruimte {

    private double limiet;
    private double ruimte;
    private double verbruik;
    private List<Parkeertijden> parkeertijden;

    public void setLimiet(double limiet) {
        this.limiet = limiet;
    }

    public double getLimiet() {
        return limiet;
    }

    public void setRuimte(double ruimte) {
        this.ruimte = ruimte;
    }

    public double getRuimte() {
        return ruimte;
    }

    public void setVerbruik(double verbruik) {
        this.verbruik = verbruik;
    }

    public double getVerbruik() {
        return verbruik;
    }

    public void setParkeertijden(List<Parkeertijden> parkeertijden) {
        this.parkeertijden = parkeertijden;
    }

    public List<Parkeertijden> getParkeertijden() {
        return parkeertijden;
    }
}
