package nl.haarlem.services.parkeerrechten.model;

public class Bestedingsruimte {
    
    private double limiet;
    private double ruimte;
    private double verbruik;

    public void setLimiet(double limiet) {
        this.limiet = limiet;
    }

    public double getLimiet() {
        return limiet;
    }

    public void setRuimte(double ruimte) {
        this.ruimte = ruimte;
    }

    public double getRuimte() {
        return ruimte;
    }

    public void setVerbruik(double verbruik) {
        this.verbruik = verbruik;
    }

    public double getVerbruik() {
        return verbruik;
    }
}
