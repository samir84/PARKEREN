package nl.haarlem.services.parkeerrechten.model;

import java.io.Serializable;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;



public class Recht implements Serializable {

    private static final long serialVersionUID = 6194198511103620836L;

    private String activeringscode;
    private Timestamp begindatum;
    private Long bsn;
    private String iban;
    private Timestamp einddatum;
    private Long id;
    private String zone;
    private Registratie[] registratieLijst;

    private RechtType[] rechtTypeLijst;
    private String email;
    private String akkoordAlgVoorwaarden;
    private String akkoordIncasso;
    private Instelling[] Instellingen;
    
    public Recht() {
        super();
      
    }

    public void setActiveringscode(String activeringscode) {
        this.activeringscode = activeringscode;
    }

    public String getActiveringscode() {
        return activeringscode;
    }

    public void setBsn(Long bsn) {
        this.bsn = bsn;
    }

    public Long getBsn() {
        return bsn;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getZone() {
        return zone;
    }

    public void setRegistratieLijst(Registratie[] registratieLijst) {
        this.registratieLijst = registratieLijst;
    }

    public Registratie[] getRegistratieLijst() {
        return registratieLijst;
    }


    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }
    public void setBegindatum(Timestamp begindatum) {
        this.begindatum = begindatum;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getBegindatum() {
        return begindatum;
    }

    public void setEinddatum(Timestamp einddatum) {
        this.einddatum = einddatum;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getEinddatum() {
        return einddatum;
    }


    public void setRechtTypeLijst(RechtType[] rechtTypeLijst) {
        this.rechtTypeLijst = rechtTypeLijst;
    }

    public RechtType[] getRechtTypeLijst() {
        return rechtTypeLijst;
    }

    public void setAkkoordAlgVoorwaarden(String akkoordAlgVoorwaarden) {
        this.akkoordAlgVoorwaarden = akkoordAlgVoorwaarden;
    }

    public String getAkkoordAlgVoorwaarden() {
        return akkoordAlgVoorwaarden;
    }

    public void setAkkoordIncasso(String akkoordIncasso) {
        this.akkoordIncasso = akkoordIncasso;
    }

    public String getAkkoordIncasso() {
        return akkoordIncasso;
    }

    

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getIban() {
        return iban;
    }


    public void setInstellingen(Instelling[] Instellingen) {
        this.Instellingen = Instellingen;
    }

    public Instelling[] getInstellingen() {
        return Instellingen;
    }
}
