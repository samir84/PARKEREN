package nl.haarlem.services.parkeerrechten.model;

import java.io.Serializable;

import java.util.Calendar;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


public class Recht implements Serializable {
    
    private static final long serialVersionUID = 6194198511103620836L;
    
    private String activeringscode;
    private Calendar begindatum;
    private Long bsn;
    private Calendar einddatum;
    private Long id;
    private String zone;
    private Registratie[] registratieLijst;
    private RechtType[] rechtTypeLijst;
    private String email;
    private String bankNummer;
    private String akkoord;
    
    public Recht() {
        super();
    }

    public void setActiveringscode(String activeringscode) {
        this.activeringscode = activeringscode;
    }

    public String getActiveringscode() {
        return activeringscode;
    }

    public void setBegindatum(Calendar begindatum) {
        this.begindatum = begindatum;
    }

    public Calendar getBegindatum() {
        return begindatum;
    }

    public void setBsn(Long bsn) {
        this.bsn = bsn;
    }

    public Long getBsn() {
        return bsn;
    }

    public void setEinddatum(Calendar einddatum) {
        this.einddatum = einddatum;
    }

    public Calendar getEinddatum() {
        return einddatum;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getZone() {
        return zone;
    }

    public void setRegistratieLijst(Registratie[] registratieLijst) {
        this.registratieLijst = registratieLijst;
    }

    public Registratie[] getRegistratieLijst() {
        return registratieLijst;
    }

    public void setRechtTypeLijst(RechtType[] rechtTypeLijst) {
        this.rechtTypeLijst = rechtTypeLijst;
    }

    public RechtType[] getRechtTypeLijst() {
        return rechtTypeLijst;
    }


    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }


    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public void setBankNummer(String bankNummer) {
        this.bankNummer = bankNummer;
    }

    public String getBankNummer() {
        return bankNummer;
    }

    public void setAkkoord(String akkoord) {
        this.akkoord = akkoord;
    }

    public String getAkkoord() {
        return akkoord;
    }
}
