package nl.haarlem.services.parkeerrechten.model;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.jpa.InstellingenEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;

public class Instelling implements Serializable{

    private static final long serialVersionUID = 1L;
    private Timestamp datumcheck;
    private String key;
    private String value;

    public Instelling() {
        super();
    }


    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getDatumcheck() {
        return datumcheck;
    }

    public void setDatumcheck(Timestamp datumcheck) {
        this.datumcheck = datumcheck;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    
    
}
