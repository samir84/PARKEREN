package nl.haarlem.services.parkeerrechten.model;

public class Favoriet {

    private Long id;
    private String naam;
    private String kenteken;
    private String activeringscode;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public String getNaam() {
        return naam;
    }

    public void setKenteken(String kenteken) {
        this.kenteken = kenteken;
    }

    public String getKenteken() {
        return kenteken;
    }

    public void setActiveringscode(String activeringscode) {
        this.activeringscode = activeringscode;
    }

    public String getActiveringscode() {
        return activeringscode;
    }
}
