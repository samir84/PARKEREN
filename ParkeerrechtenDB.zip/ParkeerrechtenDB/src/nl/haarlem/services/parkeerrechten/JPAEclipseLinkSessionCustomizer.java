package nl.haarlem.services.parkeerrechten;

public class JPAEclipseLinkSessionCustomizer {
    public JPAEclipseLinkSessionCustomizer() {
        super();
    }
}
