package nl.haarlem.services.parkeerrechten;

import java.util.List;

import javax.ejb.Remote;

@Remote
public interface ParkeerrechtenSessionEJB {

}
