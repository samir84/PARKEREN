package nl.haarlem.services.parkeerrechten.service.impl;

import java.util.Collections;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import nl.haarlem.services.parkeerrechten.dao.InstellingenEntityDAO;
import nl.haarlem.services.parkeerrechten.dao.RechtEntityDAO;


import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.InstellingenEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.service.InstellingService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class InstellingServiceImpl implements InstellingService{

    private Logger log = LoggerFactory.getLogger(InstellingServiceImpl.class.getName());
    
    @EJB
    private InstellingenEntityDAO instellingDao;
    @EJB
    private RechtEntityDAO rechtEntityDao;
    
    
    public List<InstellingenEntity> findInstellingenEntityByRecht(RechtEntity recht) throws BezoekersparkerenException{
        
        List<InstellingenEntity> InstellingenEntity = null;
        
        if(instellingDao.findInstellingenEntityByRecht(recht) == null || instellingDao.findInstellingenEntityByRecht(recht).size() == 0){
            
            throw new BezoekersparkerenException("error","Geen InstellingenEntity gevonden voor recht met id: "+recht.getId());
        }
        
        return instellingDao.findInstellingenEntityByRecht(recht);
        
         
    }


    public void updateNotificationMailInstelling(String activeringscode,
                                 String value) throws BezoekersparkerenException {
        
        RechtEntity rechtEntity = rechtEntityDao.findByActiveringscode(activeringscode);
        if( rechtEntity == null){
            throw new BezoekersparkerenException("error","Geen Bezoekers recht gevonden met activeringscode: "+activeringscode); 
        }
        
        InstellingenEntity InstellingenEntity = instellingDao.findInstellingEntityByRechtAndKey(rechtEntity, "Email_Notification");
        InstellingenEntity.setValue(value);
        
        
    }
    
    public void updateInstelling(String activeringscode, String key,
                                 String value) throws BezoekersparkerenException {
        
        
        InstellingenEntity instelling = findInstellingByActiveringscodeAndKey(activeringscode , key);
        if(value == null || value.isEmpty()){
            throw new BezoekersparkerenException("error","Value mag niet leeg zijn!");
        }
        if(value.equalsIgnoreCase("JA")){
            instelling.setValue("J");
            instellingDao.updateInstellingEntity(instelling);
        }
        else if(value.equalsIgnoreCase("NEE")){
            instelling.setValue("N");
            instellingDao.updateInstellingEntity(instelling);
        }
        else{
            throw new BezoekersparkerenException("error","Value moet ja of nee zijn!");
        }
        
        
    }

    public void updateMailNotification(String activeringscode, String value) throws BezoekersparkerenException {
        RechtEntity rechtEntity = rechtEntityDao.findByActiveringscode(activeringscode);
        if( rechtEntity == null){
            throw new BezoekersparkerenException("error","Geen Bezoekers recht gevonden met activeringscode: "+activeringscode); 
        }
        
        InstellingenEntity instelling = instellingDao.findInstellingEntityByRechtAndKey(rechtEntity, "Email_Notification");
        if(value == null || value.isEmpty()){
            throw new BezoekersparkerenException("error","Value mag niet leeg zijn!");
        }
        if(value.equalsIgnoreCase("JA")){
            instelling.setValue("J");
            instellingDao.updateInstellingEntity(instelling);
        }
        else if(value.equalsIgnoreCase("NEE")){
            instelling.setValue("N");
            instellingDao.updateInstellingEntity(instelling);
        }
        else{
            throw new BezoekersparkerenException("error","Value moet ja of nee zijn!");
        }

    }

    public InstellingenEntity findNotificationMailByActiveringsCode(String activeringscode) throws BezoekersparkerenException {
        RechtEntity rechtEntity = rechtEntityDao.findByActiveringscode(activeringscode);
        
        InstellingenEntity  instelling = null;
        if( rechtEntity == null){
            throw new BezoekersparkerenException("error","Geen Bezoekers recht gevonden met activeringscode: "+activeringscode); 
        }
        InstellingenEntity instellingenEntity = instellingDao.findInstellingEntityByRechtAndKey(rechtEntity, "Email_Notification");
        
        if(instellingenEntity == null){
            throw new BezoekersparkerenException("error","Geen InstellingenEntity gevonden met activeringscode: "+activeringscode); 
        }
        return instellingenEntity;
    }

    public InstellingenEntity findInstellingByActiveringscodeAndKey(String activeringscode,String key) throws BezoekersparkerenException {
        RechtEntity rechtEntity = rechtEntityDao.findByActiveringscode(activeringscode);
        if( rechtEntity == null){
            throw new BezoekersparkerenException("error","Geen Bezoekers recht gevonden met activeringscode: "+activeringscode); 
        }
        return instellingDao.findInstellingEntityByRechtAndKey(rechtEntity, key);
    }

    
}
