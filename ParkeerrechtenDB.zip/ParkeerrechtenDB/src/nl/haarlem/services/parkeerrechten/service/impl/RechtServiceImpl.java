package nl.haarlem.services.parkeerrechten.service.impl;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import java.util.Map;

import javax.ejb.EJB;

import javax.ejb.Stateless;

import nl.haarlem.services.parkeerrechten.dao.AlgemeneVoorwaardenDAO;
import nl.haarlem.services.parkeerrechten.dao.InstellingenEntityDAO;
import nl.haarlem.services.parkeerrechten.dao.RechtEntityDAO;
import nl.haarlem.services.parkeerrechten.dao.RechtTypeDAO;
import nl.haarlem.services.parkeerrechten.dao.impl.RechtEntityDAOImpl;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtTypeEntity;
import nl.haarlem.services.parkeerrechten.model.Recht;
import nl.haarlem.services.parkeerrechten.model.RechtType;
import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.AlgemeneVoorwaardenEntity;
import nl.haarlem.services.parkeerrechten.jpa.InstellingenEntity;
import nl.haarlem.services.parkeerrechten.model.Instelling;
import nl.haarlem.services.parkeerrechten.service.RechtService;
import nl.haarlem.services.parkeerrechten.util.AppHelper;
import nl.haarlem.services.parkeerrechten.util.DateTimeHelper;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class RechtServiceImpl implements RechtService {

    private Logger log = LoggerFactory.getLogger(RechtServiceImpl.class.getName());
    
    @EJB
    private RechtEntityDAO rechtEntityDao;
    @EJB
    private RechtTypeDAO rechtTypeDAO;
    @EJB
    private AlgemeneVoorwaardenDAO algemeneVoorwaardenDAO;
    @EJB 
    private InstellingenEntityDAO insellingenDAO;
    
    public RechtServiceImpl() {

    }

    public String updateRecht(Recht recht) throws BezoekersparkerenException {

        String succes = "error";
        RechtEntity oldRechtEntity = null;
        try {
            if (recht == null) {
                //succes = "Bezoekers recht mag niet leeg zijn!";
                throw new BezoekersparkerenException("error","Bezoekers recht mag niet leeg zijn!");
            } else if (recht.getActiveringscode() == null ||
                       recht.getActiveringscode().isEmpty()) {
                // succes = "Activeringscode mag niet leeg zijn!";
                throw new BezoekersparkerenException("error","Activeringscode mag niet leeg zijn!");
            } else if ((recht.getEmail() == null ||
                        recht.getEmail().isEmpty()) &&
                       (recht.getIban() == null ||
                        recht.getIban().isEmpty())) {
                throw new BezoekersparkerenException("error","Bezoekers recht email en bankrekeningnummer mogen niet leeg zijn!");
            } else {
                oldRechtEntity = findByActiveringscode(recht.getActiveringscode());
                if(oldRechtEntity == null){
                    throw new BezoekersparkerenException("error","Geen Bezoekers recht gevonden met activeringscode: "+recht.getActiveringscode());
                }
                if (recht.getEmail() != null && !recht.getEmail().isEmpty()) {
                    oldRechtEntity.setEmail(recht.getEmail());
                }
                if (recht.getIban() != null &&
                    !recht.getIban().isEmpty()) {
                    oldRechtEntity.setIban(recht.getIban());
                }
                //validation of instelling must be ja or nee
                for(Instelling instelling : recht.getInstellingen() ) {
                    if(instelling.getKey()== null || instelling.getKey().isEmpty()){
                        throw new BezoekersparkerenException("Error","Instelling key mag niet leeg zijn!");
                    }
                    else if(instelling.getValue()== null || instelling.getValue().isEmpty()){
                        throw new BezoekersparkerenException("Error","Instelling value mag niet leeg zijn!");
                    }
                }
                List<InstellingenEntity> instellingenEntities = insellingenDAO.findInstellingenEntityByRecht(oldRechtEntity);
               
                for(int i=0 ; i < instellingenEntities.size();i++ ){
                    
                    InstellingenEntity instellingenEntity = instellingenEntities.get(i);
                    
                    if(instellingenEntity.getKey().equals(recht.getInstellingen()[i].getKey())){
                        log.info("Mail instelling: "+instellingenEntity.getKey()+"--value:"+instellingenEntity.getValue());
                        if(recht.getInstellingen()[i].getValue().equalsIgnoreCase("ja")){
                            instellingenEntity.setValue("J");
                        }else if(recht.getInstellingen()[i].getValue().equalsIgnoreCase("nee")){
                            instellingenEntity.setValue("N");
                        }
                        insellingenDAO.updateInstellingEntity(instellingenEntity);
                    }
                }
                
                oldRechtEntity.setInstellingenEntity(instellingenEntities);
                if(recht.getEmail()!= null){
                    oldRechtEntity.setEmail(recht.getEmail());  
                }
                if(recht.getIban() != null){
                    oldRechtEntity.setIban(recht.getIban());
                }
                succes = rechtEntityDao.updateRecht(oldRechtEntity);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }


        return succes;
    }


    public boolean isActiveringscodeExist(String randomCode) throws BezoekersparkerenException {
        
        return rechtEntityDao.isActiveringscodeExist(randomCode);
    }

    public RechtEntity findByActiveringscode(String activeringscode) throws BezoekersparkerenException {

        if (activeringscode == null || activeringscode.isEmpty()) {
            throw new BezoekersparkerenException("error","Activeringscode mag niet leeg zijn!");
        }
        return rechtEntityDao.findByActiveringscode(activeringscode);
    }

    public String opzeggenRecht(String activeringscode) throws BezoekersparkerenException {

        if (activeringscode == null || activeringscode.isEmpty()) {
            throw new BezoekersparkerenException("error","Activeringscode mag niet leeg zijn!");
        }
        return rechtEntityDao.opzeggenRecht(activeringscode);
    }

    public Recht ophalenBezoekersrechtByBSN(String bsn) throws BezoekersparkerenException {

        RechtEntity rechtEntity = rechtEntityDao.ophalenBezoekersrechtByBSN(bsn);
        if( rechtEntity == null){
           // throw new BezoekersparkerenException("error","Geen Bezoekers recht gevonden met bsn: "+bsn); 
            return null;
        }
        double limiet = 0;
        Recht recht = new Recht();
        RechtType[] rechtTypeArray = null;

        recht.setBsn(new Long(rechtEntity.getBsn()));
        recht.setActiveringscode(rechtEntity.getActiveringscode());
        recht.setIban(rechtEntity.getIban());

        Instelling[] instellingen = new Instelling[rechtEntity.getInstellingenEntity().size()];
        
        for(int i=0 ; i< instellingen.length ; i++){
            
            String  key = rechtEntity.getInstellingenEntity().get(i).getKey();
            String value =  null;
            
            if(rechtEntity.getInstellingenEntity().get(i).getValue().equalsIgnoreCase("J")){
                value = "ja";
            }
            if(rechtEntity.getInstellingenEntity().get(i).getValue().equalsIgnoreCase("N")){
                value = "nee";
            }
            Instelling Instelling = new Instelling();
            Instelling.setKey(key);
            Instelling.setValue(value);
            Instelling.setDatumcheck(new Timestamp(new Date().getTime()));
            instellingen[i] = Instelling;

        }
        
        recht.setInstellingen(instellingen);
        
        List<RechtTypeEntity> rechtTypeEntityList = rechtEntity.getRechtTypeList();
        if (rechtTypeEntityList != null) {
            rechtTypeArray = new RechtType[rechtTypeEntityList.size()];
            for (int i = 0; i < rechtTypeEntityList.size(); i++) {
                RechtTypeEntity rechtTypeEntity = rechtTypeEntityList.get(i);
                RechtType rechtType = new RechtType();
                rechtType.setBegindatum(rechtTypeEntity.getBegindatum());
                rechtType.setEinddatum(rechtTypeEntity.getEinddatum());
                rechtType.setId(rechtTypeEntity.getId());
                rechtType.setNaam(rechtTypeEntity.getNaam());
                //totdo: from business rule
                //DateTimeHelper.getInstance().BestedingsLimitByCurrentDate(rechtTypeEntity.getBestedingslimiet());
                limiet =  DateTimeHelper.getInstance().CalculateBestedingsLimit(rechtTypeEntity.getNaam(),rechtTypeEntity.getBegindatum());
                rechtType.setBestedingslimiet(limiet);
                rechtTypeArray[i] = rechtType;

            }

        }
        recht.setRechtTypeLijst(rechtTypeArray);
        recht.setZone(rechtEntity.getZone());
        recht.setEmail(rechtEntity.getEmail());

        return recht;
    }

    public Recht ophalenBezoekersrechtByActiveringscode(String activeringscode) throws BezoekersparkerenException {
       
        RechtEntity rechtEntity = rechtEntityDao.ophalenBezoekersrechtByActiveringscode(activeringscode);
        if( rechtEntity == null){
            throw new BezoekersparkerenException("error","Geen Bezoekers recht gevonden met activeringscode: "+activeringscode); 
        }
        
        Recht recht = new Recht();
        RechtType[] rechtTypeArray = null;
        double limiet = 0;

        recht.setActiveringscode(rechtEntity.getActiveringscode());
        recht.setBegindatum(rechtEntity.getBegindatum());
        recht.setEmail(rechtEntity.getEmail());
        recht.setIban(rechtEntity.getIban());
       
        Instelling[] instellingen = new Instelling[rechtEntity.getInstellingenEntity().size()];
        
        for(int i=0 ; i< instellingen.length ; i++){
            
            String  key = rechtEntity.getInstellingenEntity().get(i).getKey();
            String value =  null;
            
            if(rechtEntity.getInstellingenEntity().get(i).getValue().equalsIgnoreCase("J")){
                value = "ja";
            }
            if(rechtEntity.getInstellingenEntity().get(i).getValue().equalsIgnoreCase("N")){
                value = "nee";
            }
            Instelling Instelling = new Instelling();
            Instelling.setKey(key);
            Instelling.setValue(value);
            Instelling.setDatumcheck(new Timestamp(new Date().getTime()));
            instellingen[i] = Instelling;

        }
        
        recht.setInstellingen(instellingen);
        
        if (rechtEntity.getEinddatum() != null) {
            recht.setEinddatum(rechtEntity.getEinddatum());
        }
        List<RechtTypeEntity> rechtTypeEntityList =
            rechtEntity.getRechtTypeList();
        if (rechtTypeEntityList != null) {
            rechtTypeArray = new RechtType[rechtTypeEntityList.size()];
            for (int i = 0; i < rechtTypeEntityList.size(); i++) {
                RechtTypeEntity rechtTypeEntity =
                    rechtTypeEntityList.get(i);
                RechtType rechtType = new RechtType();
                rechtType.setBegindatum(rechtTypeEntity.getBegindatum());
                rechtType.setEinddatum(rechtTypeEntity.getEinddatum());
                rechtType.setId(rechtTypeEntity.getId());
                rechtType.setNaam(rechtTypeEntity.getNaam());
                //totdo: from business rule
                //rechtType.setBestedingslimiet(rechtTypeEntity.getBestedingslimiet());
                limiet = DateTimeHelper.getInstance().CalculateBestedingsLimit(rechtTypeEntity.getNaam(),rechtTypeEntity.getBegindatum());
                rechtType.setBestedingslimiet(limiet);
                rechtTypeArray[i] = rechtType;

            }

        }
        recht.setRechtTypeLijst(rechtTypeArray);
        recht.setZone(rechtEntity.getZone());
        
        return recht;
    }

    public boolean checkBezoekersrechtByBSN(String bsn) throws BezoekersparkerenException {
        return rechtEntityDao.checkBezoekersrechtByBSN(bsn);
    }

    public Long registrerenBezoekersrecht(Recht recht) throws BezoekersparkerenException {
        
        String akkoordVoorwaarden = recht.getAkkoordAlgVoorwaarden();
                String akkoordIncasso = recht.getAkkoordIncasso();
                if (akkoordVoorwaarden.equalsIgnoreCase("JA") && akkoordIncasso.equalsIgnoreCase("JA")) {

                    RechtEntity newRechtEntity = null;
                    
                    RechtEntity rechtEntity = new RechtEntity();
                    
                    AlgemeneVoorwaardenEntity algVoorwrd = new AlgemeneVoorwaardenEntity();
                    
                    rechtEntity.setBsn(recht.getBsn().toString());
                    //check if ActiveringsCode Alreay exist
                    String randomCode = AppHelper.generateActiveringscode(6);
                    
                    boolean activeringsCodeExist = isActiveringscodeExist(randomCode);
                    if (activeringsCodeExist) {
                        rechtEntity.setActiveringscode(AppHelper.generateNewActiveringsCode(randomCode));
                    } else {
                        rechtEntity.setActiveringscode(randomCode);
                    }

                    rechtEntity.setBegindatum(recht.getBegindatum());
                    if (recht.getEinddatum() != null) {
                        //rechtEntity.setEinddatum(new Timestamp(recht.getEinddatum().getTimeInMillis()));
                        rechtEntity.setEinddatum(recht.getEinddatum());
                    }
                    List<RechtTypeEntity> rechtTypeList = new ArrayList<RechtTypeEntity>();

                    RechtTypeEntity bezoekerRechtType = new RechtTypeEntity();
                    bezoekerRechtType.setBegindatum(new Timestamp(new Date().getTime()));
                    bezoekerRechtType.setNaam("BEZOEKER");
                    //double bestedingsLimit = DateTimeHelper.getInstance().BestedingsLimitByCurrentDate();
                    //bezoekerRechtType.setBestedingslimiet(bestedingsLimit);
                    rechtTypeList.add(bezoekerRechtType);

                    rechtEntity.setZone(recht.getZone());
                    rechtEntity.setEmail(recht.getEmail());
                    rechtEntity.setAkkoordIncasso("J");
                    rechtEntity.setIban(recht.getIban());
                    rechtEntity.setRechtTypeList(rechtTypeList);

                    rechtEntityDao.createRecht(rechtEntity);
                    newRechtEntity = rechtEntityDao.findById(rechtEntity.getId());
                    bezoekerRechtType.setRecht(newRechtEntity);

                    rechtTypeDAO.createRechtType(bezoekerRechtType);

                    Long rechtId = rechtEntity.getId();


                    if (rechtId != null) {
                        algVoorwrd.setDatumcheck(new Timestamp(new Date().getTime()));
                        algVoorwrd.setRecht(newRechtEntity);
                        algemeneVoorwaardenDAO.createAlgemeneVoorwaarden(algVoorwrd);
                        //create default notification email
                        InstellingenEntity instellingenEntity = new InstellingenEntity();
                        instellingenEntity.setDatumcheck(new Timestamp(new Date().getTime()));
                        instellingenEntity.setKey("Email_Notification");
                        instellingenEntity.setValue("J");
                        instellingenEntity.setRecht(newRechtEntity);
                        insellingenDAO.createInstellingenEntity(instellingenEntity);
                    }

                    return rechtEntity.getId();
                } else {
                    throw new BezoekersparkerenException("error","Algemene voorwaarden en  Incasso zijn niet akkoord!.");
                }
    }


    public RechtEntity findById(Long id) {
        return null;
    }

    public String wijzigenActiveringscode(String activeringscode) throws BezoekersparkerenException {
        
        RechtEntity rechtEntity = rechtEntityDao.findByActiveringscode(activeringscode);
            if(rechtEntity == null){
                throw new BezoekersparkerenException("error","Geen recht gevonden voor activeringscode: "+activeringscode);
            }                                                                              
        
        //check if ActiveringsCode Alreay exist
        String randomCode = AppHelper.generateActiveringscode(6);
        boolean activeringsCodeExist = isActiveringscodeExist(randomCode);
        if (activeringsCodeExist) {
            rechtEntity.setActiveringscode(AppHelper.generateNewActiveringsCode(randomCode));
        } else {
            rechtEntity.setActiveringscode(randomCode);
        }
        rechtEntityDao.merge(rechtEntity);
        return rechtEntity.getActiveringscode();
    }
}
