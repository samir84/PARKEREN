package nl.haarlem.services.parkeerrechten.service.impl;

import nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import java.util.concurrent.TimeUnit;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import javax.persistence.Query;

import nl.haarlem.services.parkeerrechten.dao.RechtEntityDAO;
import nl.haarlem.services.parkeerrechten.dao.RegistratieDAO;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.model.Registratie;
import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.service.RegistratieService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class RegistratieServiceImpl implements RegistratieService {

    private Logger log = LoggerFactory.getLogger(RegistratieServiceImpl.class.getName());

    @EJB
    private RegistratieDAO registratieDao;
    @EJB
    private RechtEntityDAO rechtEntityDao;

    public Long aanmeldenKenteken(Registratie registratie) throws BezoekersparkerenException {

        RechtEntity rechtEntity =
            rechtEntityDao.findByActiveringscode(registratie.getActiveringscode());
        return registratieDao.aanmeldenKenteken(registratie, rechtEntity);
    }

    public Registratie ophalenActieveRegistratie(Registratie registratie) throws BezoekersparkerenException {
        return registratieDao.ophalenActieveRegistratie(registratie);
    }

    public Double findTotalBedragByJaar(RechtEntity recht) {
        return registratieDao.findTotalBedragByJaar(recht);
    }

    public Registratie[] findRegistratiesByActiveringsCode(String activeringscode) throws BezoekersparkerenException {

        List<nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity> registraties =
            registratieDao.findRegistratiesByActiveringsCode(activeringscode);

        if (registraties == null || registraties.size() == 0) {

            //throw new BezoekersparkerenException("error","Geen active registraties gevonden met activeringscode : "+activeringscode);
            registraties = new ArrayList<nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity>();
        }

        Registratie[] registratieLijst = new Registratie[registraties.size()];
        for (int i = 0; i < registraties.size(); i++) {
            nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity registratieEntity = registraties.get(i);
            Registratie registratie = new Registratie();
            registratie.setId(registratieEntity.getId());
            registratie.setKenteken(registratieEntity.getKenteken());
            registratie.setActiveringscode(activeringscode);
            registratie.setBedrag(registratieEntity.getBedrag());
            //fix test
            //2
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(registratieEntity.getBegintijd().getTime());
            registratie.setBegintijd(calendar);
            if (registratieEntity.getEindtijd() != null) {
                Calendar calendar2 = Calendar.getInstance();
                calendar2.setTimeInMillis(registratieEntity.getEindtijd().getTime());
                registratie.setEindtijd(calendar2);
            }
            registratieLijst[i] = registratie;
        }

        return registratieLijst;
    }

    public Registratie[] ophalenRegstratiesHistorie(String activeringscode) throws BezoekersparkerenException {

        RechtEntity rechtEntity = rechtEntityDao.findByActiveringscode(activeringscode);
        if (rechtEntity == null) {
            throw new BezoekersparkerenException("error","Geen Bezoekers recht gevonden met activeringscode: " +
                                                activeringscode);
        }

         List<nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity> registraties = registratieDao.findValidByRechtHistorie(rechtEntity);
        if (registraties == null || registraties.size() == 0) {
            //throw new BezoekersparkerenException("error","Geen active registraties gevonden met activeringscode :" +activeringscode);
            return new Registratie[1];
        }
        Registratie[] registratieLijst = new Registratie[registraties.size()];
        for (int i = 0; i < registraties.size(); i++) {
            nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity registratieEntity = registraties.get(i);
            Registratie registratie = new Registratie();
            registratie.setKenteken(registratieEntity.getKenteken());
            if (registratieEntity.getBedrag() != null) {
                registratie.setBedrag(registratieEntity.getBedrag());
            }
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(registratieEntity.getBegintijd().getTime());
            registratie.setBegintijd(calendar);
            if (registratieEntity.getEindtijd() != null) {
                Calendar carlendar2 = Calendar.getInstance();
                carlendar2.setTimeInMillis(registratieEntity.getEindtijd().getTime());
                registratie.setEindtijd(carlendar2);
            }
            registratie.setActiveringscode(registratieEntity.getRecht().getActiveringscode());
            registratie.setId(registratieEntity.getId());
            registratieLijst[i] = registratie;
        }
        return registratieLijst;
    }

    public String afmeldenKenteken(Registratie registratie) throws BezoekersparkerenException {

        log.debug("###ParkeerrechtenSessionEJBBean.afmeldenKenteken");
        
        if(registratie.getActiveringscode() == null){
            throw new BezoekersparkerenException("error","Activeringscode is verplicht!");
        }
        if(registratie.getId() == null){
            throw new BezoekersparkerenException("error","Registratie id is verplicht!");
        }
        RechtEntity recht = rechtEntityDao.findByActiveringscode(registratie.getActiveringscode());
        if (recht == null) {
            throw new BezoekersparkerenException("error","Geen Beozkers recht gevonden met activeringscode :"+ registratie.getActiveringscode());
        }
        
        RegistratieEntity registratieEntity = registratieDao.findActiveById(registratie.getId());
            if (registratieEntity == null) {
                throw new BezoekersparkerenException("error","Geen bezoekers registratie gevonden met id :" +
                                                    registratie.getId() +" en activeringscode: "+registratie.getActiveringscode());
            }
            registratieEntity.setEindtijd(new Timestamp(Calendar.getInstance().getTimeInMillis()));
            registratieEntity.setBedrag(registratie.getBedrag());

            registratieDao.merge(registratieEntity);
            
        return "success";

       
    }

    public String deleteRegistratie(Registratie registratie) throws BezoekersparkerenException {
        
                   
                 nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity registratieEntity = registratieDao.findById(registratie.getId());
                if (registratieEntity == null) {
                    throw new BezoekersparkerenException("error","Geen Registratie gevonden met id :" +
                                                registratie.getId());
                }

                registratieDao.remove(registratieEntity);
                try {
                    TimeUnit.SECONDS.sleep(3);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return "success";
    }

    public String updateRegistratieEindtijd(Registratie registratie) throws BezoekersparkerenException {
        log.info("###ParkeerrechtenSessionEJBBean.ophalenStatusKenteken");
        //RechtEntity rechtEntity = (RechtEntity)em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode", registratie.getActiveringscode()).getResultList().get(0);
        RegistratieEntity registratieEntity = registratieDao.findById(registratie.getId());
        if (registratieEntity == null) {
            throw new BezoekersparkerenException("error","Geen Registratie gevonden met id :" +registratie.getId());
        }
        registratieEntity.setEindtijd(new Timestamp(registratie.getEindtijd().getTimeInMillis()));
        registratieEntity.setBedrag(registratie.getBedrag());
        registratieDao.merge(registratieEntity);
        return "success";
    }

    public boolean zoekGeregistreerdRegistratie(Registratie registratie) throws BezoekersparkerenException {
        RechtEntity rechtEntity =
            rechtEntityDao.findByActiveringscode(registratie.getActiveringscode());
        if (rechtEntity == null) {
            throw new BezoekersparkerenException("error","Geen Bezoekers recht gevonden met activeringscode :" +registratie.getActiveringscode());
        }
        Timestamp beginTijd = new Timestamp(registratie.getBegintijd().getTime().getTime());
        Timestamp eindTijd = new Timestamp(registratie.getBegintijd().getTime().getTime());
        List<nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity> registratieEntityList =  registratieDao.findGeregistreerdeRegistraties(rechtEntity,registratie.getKenteken(),beginTijd,eindTijd);
        if(registratieEntityList == null || registratieEntityList.size() == 0){
           // throw new BezoekersparkerenException("error","Geen registratie gevonden voor kenteken "+registratie.getKenteken());
           return false;
        }
        for (nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity registratieEntity : registratieEntityList) {
            return true;
        }
        return false;
    }
}
