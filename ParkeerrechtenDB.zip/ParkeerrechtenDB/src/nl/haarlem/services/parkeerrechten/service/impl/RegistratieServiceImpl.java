package nl.haarlem.services.parkeerrechten.service.impl;

import java.math.BigDecimal;

import nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import java.util.concurrent.TimeUnit;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import javax.jws.WebParam;

import javax.persistence.Query;

import nl.haarlem.services.parkeerrechten.dao.ParkeertijdenDAO;
import nl.haarlem.services.parkeerrechten.dao.RechtEntityDAO;
import nl.haarlem.services.parkeerrechten.dao.RegistratieDAO;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.model.Bestedingsruimte;
import nl.haarlem.services.parkeerrechten.model.Registratie;
import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;
import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;
import nl.haarlem.services.parkeerrechten.jpa.RechtTypeEntity;
import nl.haarlem.services.parkeerrechten.model.Parkeerkosten;
import nl.haarlem.services.parkeerrechten.model.Parkeertijd;
import nl.haarlem.services.parkeerrechten.service.RegistratieService;

import nl.haarlem.services.parkeerrechten.util.AppHelper;
import nl.haarlem.services.parkeerrechten.util.DateTimeHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class RegistratieServiceImpl implements RegistratieService {

    private Logger log =
        LoggerFactory.getLogger(RegistratieServiceImpl.class.getName());

    @EJB
    private RegistratieDAO registratieDao;
    @EJB
    private RechtEntityDAO rechtEntityDao;

    @EJB
    private ParkeertijdenDAO parkeertijdenenDAO;

    public Long aanmeldenKenteken(Registratie registratie) throws BezoekersparkerenException {

        RechtEntity rechtEntity =
            rechtEntityDao.findByAanmeldcode(registratie.getAanmeldcode());
        return registratieDao.aanmeldenKenteken(registratie, rechtEntity);
    }

    public Registratie ophalenActieveRegistratie(Registratie registratie) throws BezoekersparkerenException {
        return registratieDao.ophalenActieveRegistratie(registratie);
    }

    public Double findTotalBedragByJaar(RechtEntity recht) {
        return registratieDao.findTotalBedragByHuidigeJaar(recht);
    }

    public Registratie[] findRegistratiesByAanmeldcode(String aanmeldcode) throws BezoekersparkerenException {

        List<RegistratieEntity> registraties =
            registratieDao.findRegistratiesByAanmeldcode(aanmeldcode);

        if (registraties == null || registraties.size() == 0) {
            registraties = new ArrayList<nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity>();
        }

        Registratie[] registratieLijst = new Registratie[registraties.size()];
        for (int i = 0; i < registraties.size(); i++) {
            nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity registratieEntity =
                registraties.get(i);
            Registratie registratie = new Registratie();
            registratie.setId(registratieEntity.getId());
            registratie.setKenteken(registratieEntity.getKenteken());
            registratie.setAanmeldcode(aanmeldcode);
            registratie.setBedrag(registratieEntity.getBedrag());
            registratie.setBron(registratieEntity.getBron());
            //fix test
            //2
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(registratieEntity.getBegintijd().getTime());
            registratie.setBegintijd(calendar);
            if (registratieEntity.getEindtijd() != null) {
                Calendar calendar2 = Calendar.getInstance();
                calendar2.setTimeInMillis(registratieEntity.getEindtijd().getTime());
                registratie.setEindtijd(calendar2);
            }
            registratieLijst[i] = registratie;
        }

        return registratieLijst;
    }

    public Registratie[] ophalenRegstratiesHistorie(String aanmeldcode) throws BezoekersparkerenException {

        RechtEntity rechtEntity =rechtEntityDao.findByAanmeldcode(aanmeldcode);
        if (rechtEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen Bezoekers recht gevonden met aanmeldcode: " +
                                                 aanmeldcode);
        }

        List<RegistratieEntity> registraties =
            registratieDao.ophalenRegstratiesHistorieHuidigeJaar(rechtEntity);
        if (registraties == null || registraties.size() == 0) {
            //throw new BezoekersparkerenException("error","Geen active registraties gevonden met aanmeldcode :" +aanmeldcode);
            return new Registratie[1];
        }
        Registratie[] registratieLijst = new Registratie[registraties.size()];
        for (int i = 0; i < registraties.size(); i++) {
            RegistratieEntity registratieEntity = registraties.get(i);
            Registratie registratie = new Registratie();
            registratie.setKenteken(registratieEntity.getKenteken());
            if (registratieEntity.getBedrag() != null) {
                registratie.setBedrag(registratieEntity.getBedrag());
            }
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(registratieEntity.getBegintijd().getTime());
            registratie.setBegintijd(calendar);
            if (registratieEntity.getEindtijd() != null) {
                Calendar carlendar2 = Calendar.getInstance();
                carlendar2.setTimeInMillis(registratieEntity.getEindtijd().getTime());
                registratie.setEindtijd(carlendar2);
            }
            registratie.setAanmeldcode(registratieEntity.getRecht().getAanmeldcode());
            registratie.setId(registratieEntity.getId());
            registratie.setBron(registratieEntity.getBron());
            registratieLijst[i] = registratie;
        }
        return registratieLijst;
    }

    public String afmeldenKenteken(Registratie registratie) throws BezoekersparkerenException {

        log.debug("###ParkeerrechtenSessionEJBBean.afmeldenKenteken");

        if (registratie.getAanmeldcode() == null) {
            throw new BezoekersparkerenException("error",
                                                 "aanmeldcode is verplicht!");
        }
        if (registratie.getId() == null) {
            throw new BezoekersparkerenException("error",
                                                 "Registratie id is verplicht!");
        }
        RechtEntity recht =
            rechtEntityDao.findByAanmeldcode(registratie.getAanmeldcode());
        if (recht == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen Beozkers recht gevonden met aanmeldcode :" +
                                                 registratie.getAanmeldcode());
        }

        RegistratieEntity registratieEntity =
            registratieDao.findActiveById(registratie.getId());
        if (registratieEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen active bezoekers registratie gevonden met id :" +
                                                 registratie.getId() +
                                                 " en aanmeldcode: " +
                                                 registratie.getAanmeldcode());
        }
        registratieEntity.setEindtijd(new Timestamp(Calendar.getInstance().getTimeInMillis()));
        registratieEntity.setBedrag(registratie.getBedrag());
        registratieEntity.setBron(registratie.getBron());
        registratieDao.merge(registratieEntity);

        return "success";


    }

    public String deleteRegistratie(Registratie registratie) throws BezoekersparkerenException {


        RegistratieEntity registratieEntity =
            registratieDao.findById(registratie.getId());
        if (registratieEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen Registratie gevonden met id :" +
                                                 registratie.getId());
        }

        registratieDao.remove(registratieEntity);
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "success";
    }

    public String updateRegistratieEindtijd(Registratie registratie) throws BezoekersparkerenException {
        log.info("###ParkeerrechtenSessionEJBBean.ophalenStatusKenteken");
        RegistratieEntity registratieEntity =
            registratieDao.findById(registratie.getId());
        if (registratieEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen Registratie gevonden met id :" +
                                                 registratie.getId());
        }
        registratieEntity.setEindtijd(new Timestamp(registratie.getEindtijd().getTimeInMillis()));
        registratieEntity.setBedrag(registratie.getBedrag());
        registratieEntity.setBron(registratie.getBron());
        registratieDao.merge(registratieEntity);
        return "success";
    }

    public boolean zoekGeregistreerdRegistratie(Registratie registratie) throws BezoekersparkerenException {
        RechtEntity rechtEntity =
            rechtEntityDao.findByAanmeldcode(registratie.getAanmeldcode());
        if (rechtEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen Bezoekers recht gevonden met aanmeldcode :" +
                                                 registratie.getAanmeldcode());
        }
        Timestamp beginTijd =
            new Timestamp(registratie.getBegintijd().getTime().getTime());
        Timestamp eindTijd =
            new Timestamp(registratie.getBegintijd().getTime().getTime());
        List<RegistratieEntity> registratieEntityList =
            registratieDao.findGeregistreerdeRegistraties(rechtEntity,
                                                          registratie.getKenteken(),
                                                          beginTijd, eindTijd);
        if (registratieEntityList == null ||
            registratieEntityList.size() == 0) {
            // throw new BezoekersparkerenException("error","Geen registratie gevonden voor kenteken "+registratie.getKenteken());
            return false;
        }
        for (RegistratieEntity registratieEntity : registratieEntityList) {
            return true;
        }
        return false;
    }

    public Bestedingsruimte ophalenBestedingsruimte(String aanmeldcode) throws BezoekersparkerenException {
        Float limiet = new Float(0.00);
        double verbruik = 0;
        Bestedingsruimte bestedingsruimte = new Bestedingsruimte();

        RechtEntity rechtEntity =
            rechtEntityDao.findByAanmeldcode(aanmeldcode);
        if (rechtEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen bezoekers recht gevonden voor aanmeldcode: " +
                                                 aanmeldcode);
        }
        List<RechtTypeEntity> rechtTypeLijst =
            (List<RechtTypeEntity>)rechtEntity.getRechtTypeList();
        for (int j = 0; j < rechtTypeLijst.size(); j++) {
            RechtTypeEntity rechtType = (RechtTypeEntity)rechtTypeLijst.get(j);
            limiet =
                    limiet + AppHelper.getInstance().CalculateBestedingsLimit(rechtType.getNaam(),
                                                                              rechtType.getBegindatum());

        }

        Double totalBedragByJaar =
            registratieDao.findTotalBedragByHuidigeJaar(rechtEntity);
        verbruik = totalBedragByJaar;

        double ruimte =
            AppHelper.getInstance().roundTwoDecimal(limiet - verbruik);
        double roundlimiet = AppHelper.getInstance().roundTwoDecimal(limiet);
        verbruik = AppHelper.getInstance().roundTwoDecimal(verbruik);

        bestedingsruimte.setLimiet(roundlimiet);
        bestedingsruimte.setRuimte(ruimte);
        bestedingsruimte.setVerbruik(verbruik);


        return bestedingsruimte;
    }


    public Registratie ophalenRegistratieById(Long id) throws BezoekersparkerenException {

        if (id == null) {
            throw new BezoekersparkerenException("Error",
                                                 "Registratie id kan niet leeg zijn!");
        }
        Registratie registratie = new Registratie();
        RegistratieEntity registratieEntity = registratieDao.findById(id);

        if (registratieEntity == null) {

            return null;
        }

        Calendar begintijd = Calendar.getInstance();
        begintijd.setTimeInMillis(registratieEntity.getBegintijd().getTime());

        Calendar eindtijd = Calendar.getInstance();
        eindtijd.setTimeInMillis(registratieEntity.getEindtijd().getTime());

        registratie.setBegintijd(begintijd);
        registratie.setEindtijd(eindtijd);
        registratie.setKenteken(registratieEntity.getKenteken());
        registratie.setBedrag(registratieEntity.getBedrag());
        registratie.setAanmeldcode(registratieEntity.getRecht().getAanmeldcode());
        registratie.setZone(registratieEntity.getRecht().getZone());


        return registratie;
    }

    public List<Parkeertijd> ophalenParkeeraanmeldtijden(String aanmeldcode,Date aanmeldenDate) throws BezoekersparkerenException {

        if(aanmeldcode == null || aanmeldcode.isEmpty()){
            throw new BezoekersparkerenException("error","Geen bezoekers recht gevonden voor aanmeldcode: " +aanmeldcode);
        }
        
        if(aanmeldenDate == null ){
            throw new BezoekersparkerenException("error",
                                                 "Datum field is null of heeft geen valid format :yyyy-mm-ddThh:mm:ss");
        }
        Float limiet = new Float(0.00);
        double verbruik = 0;
        List<Parkeertijd> bestedingsruimteParkeertijden = new ArrayList<Parkeertijd>();
        
        //findByDagAndParkeerzone
        RechtEntity rechtEntity =
            rechtEntityDao.findByAanmeldcode(aanmeldcode);
        if (rechtEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen bezoekers recht gevonden voor aanmeldcode: " +
                                                 aanmeldcode);
        }
        List<RechtTypeEntity> rechtTypeLijst =(List<RechtTypeEntity>)rechtEntity.getRechtTypeList();
        for (int j = 0; j < rechtTypeLijst.size(); j++) {
            RechtTypeEntity rechtType = (RechtTypeEntity)rechtTypeLijst.get(j);
            limiet = limiet + AppHelper.getInstance().CalculateBestedingsLimit(rechtType.getNaam(),
                                                                              rechtType.getBegindatum());

        }

        Double totalBedragByJaar = registratieDao.findTotalBedragByHuidigeJaar(rechtEntity);
        verbruik = totalBedragByJaar;

        double ruimte = AppHelper.getInstance().roundTwoDecimal(limiet - verbruik);
        double roundlimiet = AppHelper.getInstance().roundTwoDecimal(limiet);
        verbruik = AppHelper.getInstance().roundTwoDecimal(verbruik);

        List<Parkeertijden> parkeertijden = null;
        
        String parkeerzone = rechtEntity.getZone();
        if (parkeerzone.equalsIgnoreCase("Zone C West") || parkeerzone.equalsIgnoreCase("C Noord")) {
            parkeerzone = "C";
        }
        log.info("parkeerzone: " + parkeerzone);

        Float fparkingcosts = new Float(0.0);
        Float totalParkingCosts = new Float(0.0);


        Calendar calBeginParkeertijden = Calendar.getInstance();
        Calendar calEindParkeertijden = Calendar.getInstance();
        Calendar aanmeldenCal = Calendar.getInstance();

        boolean setBeginparkingTime = true;
        int hours = 0;
        int minute = 0;

        double resterendRuimte = (ruimte - totalParkingCosts);
        
        while (resterendRuimte > 0) {
            //1. get Alle parkingtimes by the given date and loop each one
            log.info("aanmeldenDate {}, parkeerzone {}" ,aanmeldenDate , parkeerzone);
           
            parkeertijden = (List<Parkeertijden>)parkeertijdenenDAO.findByDayAndParkeerzone(aanmeldenDate, parkeerzone);
            log.info("parkeertijden is null ??:"+(parkeertijden== null));
            List<nl.haarlem.services.parkeerrechten.model.Parkeertijd> listParkeertijden = new ArrayList<nl.haarlem.services.parkeerrechten.model.Parkeertijd>();
            
            
            if( parkeertijden == null ){
                log.info("Go to the next day..");
                aanmeldenCal.setTime(aanmeldenDate);
                aanmeldenCal.add(Calendar.DATE, 1);
                parkeertijden = (List<Parkeertijden>)parkeertijdenenDAO.findByDayAndParkeerzone(aanmeldenCal.getTime(), parkeerzone);
                log.info("Next date is:"+aanmeldenCal.getTime());
            }
            
            log.info("total parkeertijden :"+parkeertijden.size());
            for(Parkeertijden parkeertijd : parkeertijden){
                
                nl.haarlem.services.parkeerrechten.model.Parkeertijd p = new nl.haarlem.services.parkeerrechten.model.Parkeertijd();
                
                p.setBegintijd(parkeertijd.getBegintijd());
                p.setEindtijd(parkeertijd.getEindtijd());
                //p.setDag(parkeertijd.getd);
                p.setTarief(parkeertijd.getTarief());
                
                //p.setParkeerzone(parkeertijd.getParkeerzone());
                listParkeertijden.add(p);
            }
            
            log.info("parkeertijden total before foor loop:"+(parkeertijden==null));
            log.info("parkeertijden SIZE :"+(parkeertijden.size()));
            log.info("resterendRuimte before foor loop:"+resterendRuimte);
            
            for (int i = 0; i < listParkeertijden.size(); i++) {
                //bereken total bedrag voor een Parkeertijden 15 min time block
                //kosten = (Parkeertijden.getTarief() * 15 ) /60;

                Parkeertijd parkeertijd =(Parkeertijd)listParkeertijden.get(i);
                calBeginParkeertijden.setTime(parkeertijd.getBegintijd());
                calEindParkeertijden.setTime(parkeertijd.getEindtijd());
                
                
                aanmeldenCal.setTime(aanmeldenDate);
                
               
                
                int year = aanmeldenCal.get(Calendar.YEAR);
                int month = aanmeldenCal.get(Calendar.MONTH);
                int day = aanmeldenCal.get(Calendar.DAY_OF_MONTH);

                if (setBeginparkingTime) {
                    hours = aanmeldenCal.get(calBeginParkeertijden.HOUR_OF_DAY);
                    minute = aanmeldenCal.get(calBeginParkeertijden.MINUTE);
                } else {
                    hours = calBeginParkeertijden.get(calBeginParkeertijden.HOUR_OF_DAY);
                    minute = calBeginParkeertijden.get(calBeginParkeertijden.MINUTE);
                }

                calBeginParkeertijden.set(year, month, day, hours, minute);
                calEindParkeertijden.set(year, month, day,
                                       calEindParkeertijden.get(calEindParkeertijden.HOUR_OF_DAY),
                                       calEindParkeertijden.get(calEindParkeertijden.MINUTE));

                Parkeerkosten parkeerkosten = new Parkeerkosten();
                parkeerkosten.setBegintijd(calBeginParkeertijden);
                parkeerkosten.setEindtijd(calEindParkeertijden);
                parkeerkosten.setZone(parkeerzone);

                fparkingcosts = berekenParkeerkosten(parkeerkosten);
                totalParkingCosts += fparkingcosts;
                log.info("ruimte {} before compare:", ruimte);
                log.info("totalParkingCosts {} before compare:",totalParkingCosts);

                BigDecimal ffBD = new BigDecimal("" + fparkingcosts);
                BigDecimal ddBD = new BigDecimal("" + resterendRuimte);

                if (resterendRuimte < fparkingcosts.doubleValue()) {
                    
                    setBeginparkingTime = true;
                    log.info("Before resterend te goed is:"+resterendRuimte);
                    log.info("ruimte is kleiner dan totaal cost voor Parkeertijden");
                    log.info("totalParkingCosts:" + (totalParkingCosts));
                    log.info("doe berekening hier en stop de loop!");
                    //
                    double tarief = parkeertijd.getTarief();
                    
                    int totalTimeblocks = GetTotalTimeBlocks(getTimeBlockCost(getTimeBlock(),tarief), resterendRuimte);
                    log.info("totalTimeblocks:" + totalTimeblocks);

                    calEindParkeertijden.set(year, month, day,calBeginParkeertijden.get(calBeginParkeertijden.HOUR_OF_DAY),
                                           calBeginParkeertijden.get(calBeginParkeertijden.MINUTE));
                    
                    calEindParkeertijden.add(Calendar.MINUTE, totalTimeblocks * getTimeBlock());
                    
                    
                    log.info("calBeginParkeertijden now:" +calBeginParkeertijden.getTime());
                    log.info("calEindParkeertijden now :" +calEindParkeertijden.getTime());

                    parkeertijd.setBegintijd(new Timestamp(calBeginParkeertijden.getTime().getTime()));
                    parkeertijd.setEindtijd(new Timestamp(calEindParkeertijden.getTime().getTime()));
                    
                    parkeerkosten.setBegintijd(calBeginParkeertijden);
                    parkeerkosten.setEindtijd(calEindParkeertijden);
                    parkeerkosten.setZone(parkeerzone);
                    
                    bestedingsruimteParkeertijden.add(parkeertijd);
                    
                    log.info("parkeertijd added:"+parkeertijd.getBegintijd()+"**"+parkeertijd.getEindtijd()+"**"+parkeertijd.getTarief());
                    log.info("Before resterend te goed is:"+resterendRuimte);
                    resterendRuimte = (ruimte - totalParkingCosts);
                    log.info("resterend te goed is:"+resterendRuimte);
                    
                    break;

                } else if (resterendRuimte > fparkingcosts.doubleValue()) {

                    setBeginparkingTime = false;
                    
                    parkeertijd.setBegintijd(new Timestamp(calBeginParkeertijden.getTime().getTime()));
                    parkeertijd.setEindtijd(new Timestamp(calEindParkeertijden.getTime().getTime()));
                    
                    bestedingsruimteParkeertijden.add(parkeertijd);
                    
                    log.info("parkeertijd added:"+parkeertijd.getBegintijd()+"**"+parkeertijd.getEindtijd()+"**"+totalParkingCosts);
                    resterendRuimte = (ruimte - totalParkingCosts);
                    log.info("resterend te goed is:"+resterendRuimte);

                } else if (ddBD.equals(ffBD)) {
                    
                    parkeertijd.setBegintijd(new Timestamp(calBeginParkeertijden.getTime().getTime()));
                    parkeertijd.setEindtijd(new Timestamp(calEindParkeertijden.getTime().getTime()));
                    
                    bestedingsruimteParkeertijden.add(parkeertijd);
                    log.info("parkeertijd added:"+parkeertijd.getBegintijd()+"**"+parkeertijd.getEindtijd()+"**"+totalParkingCosts);
                    resterendRuimte = (ruimte - totalParkingCosts);
                    log.info("resterend te goed is:"+resterendRuimte);
                    
                } else if (fparkingcosts.doubleValue() > resterendRuimte) {
                    log.info("totalParkingCosts-4:" + totalParkingCosts);
                    log.info(" parkeerkosten mag niet hoger zijn dan de bestedingsruimte!!!");
                }

            }
            log.info("*******************************************************************************");
            log.info("resterend te goed is:"+resterendRuimte);
            log.info("*******************************************************************************");
            if (resterendRuimte > 0) {

                Calendar cal = Calendar.getInstance();
                cal.setTime(aanmeldenDate);
                cal.add(Calendar.DATE,
                        1); //minus number would decrement the days
                aanmeldenDate = cal.getTime();
            }
        }

        return bestedingsruimteParkeertijden;


    }

    /**
     * Deze methode moet op basis van de tarief per parkeerzone
     * @param parkeerkosten
     * @return
     */
    public Float berekenParkeerkosten(Parkeerkosten parkeerkosten) {


        //calculate unit price based on rate per hour and block of 15 minut
        //Example 0.12 per hour and block of 15 min
        // (0.12*15) / 60 = 0.3
        //1: get rate by day and park zon
        Float f_parkingcosts = new Float(0.0);
        /*List<Parkeertijdenen> Parkeertijdenen = ParkeertijdenenService.ophalenParkeertijdenenByDateEnParkeerzone(parkeerkosten.getBegintijd().getTime(),parkeerkosten.getZone());
        for(Parkeertijdenen Parkeertijden :Parkeertijdenen){
            log.info("begintijd:: {}",Parkeertijden.getBegintijd());
            if(parkeerkosten.getBegintijd().getTime().getTime() <= Parkeertijden.getBegintijd().getTime() && parkeerkosten.getEindtijd().getTime().getTime() <= Parkeertijden.getEindtijd().getTime()){
                log.info("begintijd start vanaf: {}",Parkeertijden.getBegintijd().getTime());
                beginTijd = Parkeertijden.getBegintijd();
               // f_parkingcosts = Parkeertijden.g
                break;
            }

        }*/

        int i_parkingcosts = 0;
        int unitprice = 3;
        Calendar calendarBeginTijd = Calendar.getInstance();
        calendarBeginTijd.setTime(parkeerkosten.getBegintijd().getTime());
        Calendar calendarEindTijd;
        // Set the time block in minutes (TODO TODO TODO: get it from the Business Rule)
       // int timeBlock = 15;
        // Set the starttime
        // calendarBeginTijd = parkeerkosten.getBegintijd();

        // Set the endtime to compare with
        calendarEindTijd = parkeerkosten.getEindtijd();
        boolean is2min =
            DateTimeHelper.getInstance().checkDifferenceBeginTimeEndTimeIs2min(calendarBeginTijd,
                                                                               calendarEindTijd);
        if (is2min) {
            return f_parkingcosts;
        }
        // Compare the parkingtime with the endtime and add 15 minutes each time it's before the endtime
        while (calendarBeginTijd.compareTo(calendarEindTijd) == -1) {
            // Add parkingcosts according to the Business Rule (TODO TODO TODO: get it from the Business Rule)
            int hour = calendarBeginTijd.get(Calendar.HOUR_OF_DAY);
            int blockprice = 0;
            if (hour >= 9 && hour < 18) {
                blockprice = unitprice;
            }
            if (hour >= 18 && hour < 23) {
                blockprice = unitprice * 2;
            }
            i_parkingcosts += blockprice;
            // Add a timeBlock to the parkingtime
            calendarBeginTijd.add(Calendar.MINUTE, getTimeBlock());


        }

        f_parkingcosts = ((float)i_parkingcosts / 100);
        log.info("berekenparkeerkosten begintijd:" +
                 parkeerkosten.getBegintijd().getTime());
        log.info("berekenparkeerkosten eindtijd:" +
                 parkeerkosten.getEindtijd().getTime());
        log.info("berekenparkeerkosten kosten:" + f_parkingcosts);
        return f_parkingcosts;
    }
    
    /**
     *Set the time block in minutes (TODO TODO TODO: get it from the Business Rule)
     * @return
     */
    private int getTimeBlock() {
    
        int timeBlock = 15;
       return timeBlock;
    }

    private float getTimeBlockCost(int timeBlock, double tarief) {
            // tarief is per hour
            float timeBlockCost = (float) (tarief*timeBlock)/60;
            return timeBlockCost;
    }
    
    private int GetTotalTimeBlocks(float timeBlockCost, double ruimte) {

            float totalTimeBlock = (float) (ruimte/timeBlockCost);
            return (int) totalTimeBlock;
        }
}
