package nl.haarlem.services.parkeerrechten.service.impl;

import java.math.BigDecimal;

import nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import java.util.concurrent.TimeUnit;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import javax.jws.WebParam;

import javax.persistence.Query;

import nl.haarlem.services.parkeerrechten.dao.ParkeertijdenDao;
import nl.haarlem.services.parkeerrechten.dao.RechtEntityDAO;
import nl.haarlem.services.parkeerrechten.dao.RegistratieDAO;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.model.Bestedingsruimte;
import nl.haarlem.services.parkeerrechten.model.Registratie;
import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;
import nl.haarlem.services.parkeerrechten.jpa.RechtTypeEntity;
import nl.haarlem.services.parkeerrechten.model.Parkeerkosten;
import nl.haarlem.services.parkeerrechten.service.RegistratieService;

import nl.haarlem.services.parkeerrechten.util.AppHelper;
import nl.haarlem.services.parkeerrechten.util.DateTimeHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class RegistratieServiceImpl implements RegistratieService {

    private Logger log =
        LoggerFactory.getLogger(RegistratieServiceImpl.class.getName());

    @EJB
    private RegistratieDAO registratieDao;
    @EJB
    private RechtEntityDAO rechtEntityDao;
    
    @EJB
    private ParkeertijdenDao parkeertijdenDao;

    public Long aanmeldenKenteken(Registratie registratie) throws BezoekersparkerenException {

        RechtEntity rechtEntity =
            rechtEntityDao.findByAanmeldcode(registratie.getAanmeldcode());
        return registratieDao.aanmeldenKenteken(registratie, rechtEntity);
    }

    public Registratie ophalenActieveRegistratie(Registratie registratie) throws BezoekersparkerenException {
        return registratieDao.ophalenActieveRegistratie(registratie);
    }

    public Double findTotalBedragByJaar(RechtEntity recht) {
        return registratieDao.findTotalBedragByHuidigeJaar(recht);
    }

    public Registratie[] findRegistratiesByAanmeldcode(String aanmeldcode) throws BezoekersparkerenException {

        List<RegistratieEntity> registraties =
            registratieDao.findRegistratiesByAanmeldcode(aanmeldcode);

        if (registraties == null || registraties.size() == 0) {

            //throw new BezoekersparkerenException("error","Geen active registraties gevonden met aanmeldcode : "+aanmeldcode);
            registraties =
                    new ArrayList<nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity>();
        }

        Registratie[] registratieLijst = new Registratie[registraties.size()];
        for (int i = 0; i < registraties.size(); i++) {
            nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity registratieEntity =
                registraties.get(i);
            Registratie registratie = new Registratie();
            registratie.setId(registratieEntity.getId());
            registratie.setKenteken(registratieEntity.getKenteken());
            registratie.setAanmeldcode(aanmeldcode);
            registratie.setBedrag(registratieEntity.getBedrag());
            registratie.setBron(registratieEntity.getBron());
            //fix test
            //2
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(registratieEntity.getBegintijd().getTime());
            registratie.setBegintijd(calendar);
            if (registratieEntity.getEindtijd() != null) {
                Calendar calendar2 = Calendar.getInstance();
                calendar2.setTimeInMillis(registratieEntity.getEindtijd().getTime());
                registratie.setEindtijd(calendar2);
            }
            registratieLijst[i] = registratie;
        }

        return registratieLijst;
    }

    public Registratie[] ophalenRegstratiesHistorie(String aanmeldcode) throws BezoekersparkerenException {

        RechtEntity rechtEntity =
            rechtEntityDao.findByAanmeldcode(aanmeldcode);
        if (rechtEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen Bezoekers recht gevonden met aanmeldcode: " +
                                                 aanmeldcode);
        }

        List<RegistratieEntity> registraties =
            registratieDao.ophalenRegstratiesHistorieHuidigeJaar(rechtEntity);
        if (registraties == null || registraties.size() == 0) {
            //throw new BezoekersparkerenException("error","Geen active registraties gevonden met aanmeldcode :" +aanmeldcode);
            return new Registratie[1];
        }
        Registratie[] registratieLijst = new Registratie[registraties.size()];
        for (int i = 0; i < registraties.size(); i++) {
            RegistratieEntity registratieEntity = registraties.get(i);
            Registratie registratie = new Registratie();
            registratie.setKenteken(registratieEntity.getKenteken());
            if (registratieEntity.getBedrag() != null) {
                registratie.setBedrag(registratieEntity.getBedrag());
            }
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(registratieEntity.getBegintijd().getTime());
            registratie.setBegintijd(calendar);
            if (registratieEntity.getEindtijd() != null) {
                Calendar carlendar2 = Calendar.getInstance();
                carlendar2.setTimeInMillis(registratieEntity.getEindtijd().getTime());
                registratie.setEindtijd(carlendar2);
            }
            registratie.setAanmeldcode(registratieEntity.getRecht().getAanmeldcode());
            registratie.setId(registratieEntity.getId());
            registratie.setBron(registratieEntity.getBron());
            registratieLijst[i] = registratie;
        }
        return registratieLijst;
    }

    public String afmeldenKenteken(Registratie registratie) throws BezoekersparkerenException {

        log.debug("###ParkeerrechtenSessionEJBBean.afmeldenKenteken");

        if (registratie.getAanmeldcode() == null) {
            throw new BezoekersparkerenException("error",
                                                 "aanmeldcode is verplicht!");
        }
        if (registratie.getId() == null) {
            throw new BezoekersparkerenException("error",
                                                 "Registratie id is verplicht!");
        }
        RechtEntity recht =
            rechtEntityDao.findByAanmeldcode(registratie.getAanmeldcode());
        if (recht == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen Beozkers recht gevonden met aanmeldcode :" +
                                                 registratie.getAanmeldcode());
        }

        RegistratieEntity registratieEntity =
            registratieDao.findActiveById(registratie.getId());
        if (registratieEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen active bezoekers registratie gevonden met id :" +
                                                 registratie.getId() +
                                                 " en aanmeldcode: " +
                                                 registratie.getAanmeldcode());
        }
        registratieEntity.setEindtijd(new Timestamp(Calendar.getInstance().getTimeInMillis()));
        registratieEntity.setBedrag(registratie.getBedrag());
        registratieEntity.setBron(registratie.getBron());
        registratieDao.merge(registratieEntity);

        return "success";


    }

    public String deleteRegistratie(Registratie registratie) throws BezoekersparkerenException {


        RegistratieEntity registratieEntity =
            registratieDao.findById(registratie.getId());
        if (registratieEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen Registratie gevonden met id :" +
                                                 registratie.getId());
        }

        registratieDao.remove(registratieEntity);
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "success";
    }

    public String updateRegistratieEindtijd(Registratie registratie) throws BezoekersparkerenException {
        log.info("###ParkeerrechtenSessionEJBBean.ophalenStatusKenteken");
        RegistratieEntity registratieEntity =
            registratieDao.findById(registratie.getId());
        if (registratieEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen Registratie gevonden met id :" +
                                                 registratie.getId());
        }
        registratieEntity.setEindtijd(new Timestamp(registratie.getEindtijd().getTimeInMillis()));
        registratieEntity.setBedrag(registratie.getBedrag());
        registratieEntity.setBron(registratie.getBron());
        registratieDao.merge(registratieEntity);
        return "success";
    }

    public boolean zoekGeregistreerdRegistratie(Registratie registratie) throws BezoekersparkerenException {
        RechtEntity rechtEntity =
            rechtEntityDao.findByAanmeldcode(registratie.getAanmeldcode());
        if (rechtEntity == null) {
            throw new BezoekersparkerenException("error",
                                                 "Geen Bezoekers recht gevonden met aanmeldcode :" +
                                                 registratie.getAanmeldcode());
        }
        Timestamp beginTijd =
            new Timestamp(registratie.getBegintijd().getTime().getTime());
        Timestamp eindTijd =
            new Timestamp(registratie.getBegintijd().getTime().getTime());
        List<RegistratieEntity> registratieEntityList =
            registratieDao.findGeregistreerdeRegistraties(rechtEntity,
                                                          registratie.getKenteken(),
                                                          beginTijd, eindTijd);
        if (registratieEntityList == null ||
            registratieEntityList.size() == 0) {
            // throw new BezoekersparkerenException("error","Geen registratie gevonden voor kenteken "+registratie.getKenteken());
            return false;
        }
        for (RegistratieEntity registratieEntity : registratieEntityList) {
            return true;
        }
        return false;
    }

    public Bestedingsruimte ophalenBestedingsruimte(String aanmeldcode) throws BezoekersparkerenException {
        Float limiet = new Float(0.00);
        double verbruik = 0;
        Bestedingsruimte bestedingsruimte = new Bestedingsruimte();

        RechtEntity rechtEntity = rechtEntityDao.findByAanmeldcode(aanmeldcode);
        if (rechtEntity == null) {
            throw new BezoekersparkerenException("error","Geen bezoekers recht gevonden voor aanmeldcode: " +aanmeldcode);
        }
        List<RechtTypeEntity> rechtTypeLijst =(List<RechtTypeEntity>)rechtEntity.getRechtTypeList();
        for (int j = 0; j < rechtTypeLijst.size(); j++) {
            RechtTypeEntity rechtType = (RechtTypeEntity)rechtTypeLijst.get(j);
            limiet = limiet + AppHelper.getInstance().CalculateBestedingsLimit(rechtType.getNaam(),rechtType.getBegindatum());

        }

        Double totalBedragByJaar =  registratieDao.findTotalBedragByHuidigeJaar(rechtEntity);
        verbruik = totalBedragByJaar;
        
        double ruimte =  AppHelper.getInstance().roundTwoDecimal(limiet - verbruik);
        double roundlimiet = AppHelper.getInstance().roundTwoDecimal(limiet);
        verbruik = AppHelper.getInstance().roundTwoDecimal(verbruik);
        
        bestedingsruimte.setLimiet(roundlimiet);
        bestedingsruimte.setRuimte(ruimte);
        bestedingsruimte.setVerbruik(verbruik);


        return bestedingsruimte;
    }
    


    public Registratie ophalenRegistratieById(Long id) throws BezoekersparkerenException {
        
        if(id == null){
            throw new BezoekersparkerenException("Error","Registratie id kan niet leeg zijn!");
        }
        Registratie registratie = new Registratie();
        RegistratieEntity registratieEntity = registratieDao.findById(id);
        
        if(registratieEntity == null ){
            
            return null;
        }
        
        Calendar begintijd = Calendar.getInstance();
        begintijd.setTimeInMillis(registratieEntity.getBegintijd().getTime());
        
        Calendar eindtijd = Calendar.getInstance();
        eindtijd.setTimeInMillis(registratieEntity.getEindtijd().getTime());
        
        registratie.setBegintijd(begintijd);
        registratie.setEindtijd(eindtijd);
        registratie.setKenteken(registratieEntity.getKenteken());
        registratie.setBedrag(registratieEntity.getBedrag());
        registratie.setAanmeldcode(registratieEntity.getRecht().getAanmeldcode());
        registratie.setZone(registratieEntity.getRecht().getZone());
        
        
        return registratie ;
    }
    
    public Bestedingsruimte ophalenBestedingsruimte_TEST(String aanmeldcode , Date aanmeldenDate) throws BezoekersparkerenException {
        
        
        Float limiet = new Float(0.00);
        double verbruik = 0;
        List<Parkeertijden> bestedingsruimteParkeertijden = new ArrayList<Parkeertijden>();
        Bestedingsruimte bestedingsruimte = new Bestedingsruimte();

        RechtEntity rechtEntity = rechtEntityDao.findByAanmeldcode(aanmeldcode);
        if (rechtEntity == null) {
            throw new BezoekersparkerenException("error","Geen bezoekers recht gevonden voor aanmeldcode: " +aanmeldcode);
        }
        List<RechtTypeEntity> rechtTypeLijst =(List<RechtTypeEntity>)rechtEntity.getRechtTypeList();
        for (int j = 0; j < rechtTypeLijst.size(); j++) {
            RechtTypeEntity rechtType = (RechtTypeEntity)rechtTypeLijst.get(j);
            limiet = limiet + AppHelper.getInstance().CalculateBestedingsLimit(rechtType.getNaam(),rechtType.getBegindatum());

        }

        Double totalBedragByJaar =  registratieDao.findTotalBedragByHuidigeJaar(rechtEntity);
        verbruik = totalBedragByJaar;
        
        double ruimte =  AppHelper.getInstance().roundTwoDecimal(limiet - verbruik);
        double roundlimiet = AppHelper.getInstance().roundTwoDecimal(limiet);
        verbruik = AppHelper.getInstance().roundTwoDecimal(verbruik);
        
        List<Parkeertijden> parkeertijden = null;
        String parkeerzone = rechtEntity.getZone();
        if(parkeerzone.equalsIgnoreCase("Zone C West")){
            parkeerzone ="C Noord";
        }
        log.info("parkeerzone: "+parkeerzone);
        
        Float fparkingcosts = new Float(0.0);
        Float totalParkingCosts = new Float(0.0);
       
            
        Calendar calBeginParkeertijd = Calendar.getInstance();
        Calendar calEindParkeertijd = Calendar.getInstance();
        Calendar aanmeldenCal = Calendar.getInstance();
        
        boolean setBeginparkingTime = true; 
        int hours = 0;
        int minute = 0;
        

        while(ruimte-totalParkingCosts > 0){
            //1. get Alle parkingtimes by the given date and loop each one
            parkeertijden = parkeertijdenDao.findByDayAndParkeerzone(aanmeldenDate,parkeerzone);
            
            
            for(int i = 0; i< parkeertijden.size(); i++){
                //bereken total bedrag voor een parkeertijd 15 min time block
                //kosten = (parkeertijd.getTarief() * 15 ) /60;
                
                Parkeertijden parkeertijd = (Parkeertijden) parkeertijden.get(i);
                log.info("parkeertijd begin tijd:"+parkeertijd.getBegintijd());
                log.info("parkeertijd eind tijd:"+parkeertijd.getEindtijd());
                calBeginParkeertijd.setTime(parkeertijd.getBegintijd());
                calEindParkeertijd.setTime(parkeertijd.getEindtijd());
            
                aanmeldenCal.setTime(aanmeldenDate);
                
                int year = aanmeldenCal.get(Calendar.YEAR);
                int month = aanmeldenCal.get(Calendar.MONTH);
                int day = aanmeldenCal.get(Calendar.DAY_OF_MONTH);
                
                if(setBeginparkingTime){
                    hours = aanmeldenCal.get(calBeginParkeertijd.HOUR_OF_DAY);
                    minute = aanmeldenCal.get(calBeginParkeertijd.MINUTE);
                }else{
                    hours = calBeginParkeertijd.get(calBeginParkeertijd.HOUR_OF_DAY);
                    minute = calBeginParkeertijd.get(calBeginParkeertijd.MINUTE);
                }

                calBeginParkeertijd.set(year, month, day, hours, minute);
                calEindParkeertijd.set(year, month, day, calEindParkeertijd.get(calEindParkeertijd.HOUR_OF_DAY), calEindParkeertijd.get(calEindParkeertijd.MINUTE));
                       
                Parkeerkosten parkeerkosten = new Parkeerkosten();
                parkeerkosten.setBegintijd(calBeginParkeertijd);
                parkeerkosten.setEindtijd(calEindParkeertijd);
                parkeerkosten.setZone(parkeerzone);

                fparkingcosts = berekenParkeerkosten (parkeerkosten);
                totalParkingCosts+=fparkingcosts;
                log.info("ruimte {} before compare:",ruimte);
                log.info("totalParkingCosts {} before compare:",totalParkingCosts);
                
                BigDecimal ffBD = new BigDecimal(""+totalParkingCosts);
                BigDecimal ddBD = new BigDecimal(""+ruimte);
                
                if ( ruimte < totalParkingCosts.doubleValue()){
                    
                    log.info("wat moet ik doen????");
                    log.info("totalParkingCosts:"+(totalParkingCosts));
                    log.info("rest:"+(totalParkingCosts.doubleValue()-ruimte));
                    log.info("calBeginParkeertijd"+ calBeginParkeertijd.getTime());
                    
                }else if ( ruimte > totalParkingCosts.doubleValue()   ){
                    
                    setBeginparkingTime = false;
                    
                    log.info("totalParkingCost-2:"+totalParkingCosts);
                    bestedingsruimteParkeertijden.add(parkeertijd);
                    
                }else if (ddBD.equals(ffBD)){
                   log.info(" parkingcosts equals ruimte!");
                    log.info("totalParkingCosts-3:"+totalParkingCosts);
                    bestedingsruimteParkeertijden.add(parkeertijd);
                }else if(totalParkingCosts.doubleValue() > ruimte){
                    log.info("totalParkingCosts-4:"+totalParkingCosts);
                    log.info(" parkeerkosten mag niet hoger zijn dan de bestedingsruimte!!!");
                }

            }
            log.info("*******************************************************************************");
            if(ruimte-totalParkingCosts > 0){
                
                Calendar cal = Calendar.getInstance();
                cal.setTime(aanmeldenDate);
                cal.add(Calendar.DATE, 1); //minus number would decrement the days
                aanmeldenDate = cal.getTime();
            }
        };
        
        
        
        
        bestedingsruimte.setLimiet(roundlimiet);
        bestedingsruimte.setRuimte(ruimte);
        bestedingsruimte.setVerbruik(verbruik);
        bestedingsruimte.setParkeertijden(bestedingsruimteParkeertijden);
        return bestedingsruimte;


        
    }
    
    /**
     * Deze methode moet op basis van de tarief per parkeerzone
     * @param parkeerkosten
     * @return
     */
    public Float berekenParkeerkosten (Parkeerkosten parkeerkosten) {
        
        
        //calculate unit price based on rate per hour and block of 15 minut
        //Example 0.12 per hour and block of 15 min
        // (0.12*15) / 60 = 0.3
        //1: get rate by day and park zon
        Float f_parkingcosts = new Float(0.0);
        /*List<Parkeertijden> parkeertijden = parkeertijdenService.ophalenParkeertijdenByDateEnParkeerzone(parkeerkosten.getBegintijd().getTime(),parkeerkosten.getZone());
        for(Parkeertijden parkeertijd :parkeertijden){
            log.info("begintijd:: {}",parkeertijd.getBegintijd());
            if(parkeerkosten.getBegintijd().getTime().getTime() <= parkeertijd.getBegintijd().getTime() && parkeerkosten.getEindtijd().getTime().getTime() <= parkeertijd.getEindtijd().getTime()){
                log.info("begintijd start vanaf: {}",parkeertijd.getBegintijd().getTime());
                beginTijd = parkeertijd.getBegintijd();
               // f_parkingcosts = parkeertijd.g
                break;
            }
            
        }*/
   
        int i_parkingcosts = 0;
        int unitprice = 3;
        Calendar calendarBeginTijd = Calendar.getInstance();
        calendarBeginTijd.setTime(parkeerkosten.getBegintijd().getTime());
        Calendar calendarEindTijd;
        // Set the time block in minutes (TODO TODO TODO: get it from the Business Rule)
        int timeBlock = 15;
        // Set the starttime
       // calendarBeginTijd = parkeerkosten.getBegintijd();
  
        // Set the endtime to compare with
        calendarEindTijd = parkeerkosten.getEindtijd();
        boolean is2min = DateTimeHelper.getInstance().checkDifferenceBeginTimeEndTimeIs2min(calendarBeginTijd, calendarEindTijd);
            if(is2min){
                return f_parkingcosts;
            }
        // Compare the parkingtime with the endtime and add 15 minutes each time it's before the endtime
        while (calendarBeginTijd.compareTo(calendarEindTijd) == -1) {
            // Add parkingcosts according to the Business Rule (TODO TODO TODO: get it from the Business Rule)
                int hour = calendarBeginTijd.get(Calendar.HOUR_OF_DAY);
                int blockprice = 0;
                if (hour >= 9 && hour < 18) {
                    blockprice = unitprice;
                }
                if (hour >= 18 && hour < 23) {
                    blockprice = unitprice * 2;
                }
                i_parkingcosts += blockprice;
                // Add a timeBlock to the parkingtime
                calendarBeginTijd.add(Calendar.MINUTE, timeBlock); 
            
            
        }
       
        f_parkingcosts = ((float)i_parkingcosts / 100);
        log.info("berekenparkeerkosten begintijd:"+parkeerkosten.getBegintijd().getTime());
        log.info("berekenparkeerkosten eindtijd:"+parkeerkosten.getEindtijd().getTime());
        log.info("berekenparkeerkosten kosten:"+f_parkingcosts);
        return f_parkingcosts;
    }
}
