package nl.haarlem.services.parkeerrechten.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import nl.haarlem.services.parkeerrechten.dao.ParkeerzoneDAO;
import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;
import nl.haarlem.services.parkeerrechten.jpa.Parkeerzone;
import nl.haarlem.services.parkeerrechten.service.ParkeerzoneService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class ParkeerzoneServiceImpl implements ParkeerzoneService {

    private Logger log =
        LoggerFactory.getLogger(ParkeerzoneServiceImpl.class.getName());

    @EJB
    private ParkeerzoneDAO parkeerzoneDAO;

    public List<Parkeerzone> findAllParkeerzones() {

        List<Parkeerzone> parkeerzones = new ArrayList<Parkeerzone>() ;


       /* for (Parkeerzone pakeerzone : parkeerzoneDAO.findAllParkeerzones()) {

            Parkeerzone newParkeerzone = new Parkeerzone();
            newParkeerzone.setZone(pakeerzone.getZone());
            List<Betaaldparkeertijden> betaaldparkeertijden = new ArrayList<Betaaldparkeertijden>();
            
            
            for (Betaaldparkeertijden betaaldparkeertijd : pakeerzone.getBetaaldparkeertijden()) {
                
                    Betaaldparkeertijden newbetaaldparkeertijd = new Betaaldparkeertijden();
                    newbetaaldparkeertijd.setBegintijd(betaaldparkeertijd.getBegintijd());
                    newbetaaldparkeertijd.setEindtijd(betaaldparkeertijd.getEindtijd());
                    newbetaaldparkeertijd.setDag(betaaldparkeertijd.getDag());

                    // newBetaaldparkeertijden.setPakeerzone(betaaldparkeertijden.getPakeerzone());
                    betaaldparkeertijden.add(newbetaaldparkeertijd);
            }
            
            newParkeerzone.setBetaaldparkeertijden(betaaldparkeertijden);
            parkeerzones.add(newParkeerzone);
        }*/

        return parkeerzones;
    }

}
