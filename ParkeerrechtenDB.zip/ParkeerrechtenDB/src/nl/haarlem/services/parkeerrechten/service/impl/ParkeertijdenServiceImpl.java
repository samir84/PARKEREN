package nl.haarlem.services.parkeerrechten.service.impl;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;

import javax.ejb.Stateless;



import nl.haarlem.services.parkeerrechten.dao.ParkeertijdenDAO;
import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;
import nl.haarlem.services.parkeerrechten.jpa.Parkeerzone;
import nl.haarlem.services.parkeerrechten.service.ParkeertijdenService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class ParkeertijdenServiceImpl implements ParkeertijdenService{

    private Logger log = LoggerFactory.getLogger(ParkeertijdenServiceImpl.class.getName());

    @EJB
    private ParkeertijdenDAO parkeertijdenDao;
    

    public List<Parkeertijden> findAll() {
        
        List<Parkeertijden> resultParkeertijden = new ArrayList<Parkeertijden>();
        
        List<Parkeertijden> bezoekersParkeertijden = new ArrayList<Parkeertijden>();
            //parkeertijdenDao.findByType("bezoekers");
        List<Parkeertijden> betaaldParkeertijden = new ArrayList<Parkeertijden>();//parkeertijdenDao.findByType("betaald");
       // List<Parkeertijden> vrijParkeertijden = parkeertijdenDao.findByType("vrij");

       
        Calendar calendar = Calendar.getInstance();
        
        String dag = null;
        String zone = null;
        
        for(Parkeertijden bezoekersParkeertijd :parkeertijdenDao.findByType("bezoekers")){
            
            //calendar.setTime(bezoekersParkeertijd.getBegintijd());
            
            Parkeertijden newbezoekersParkeertijd = new Parkeertijden();
            newbezoekersParkeertijd.setBegintijd(bezoekersParkeertijd.getBegintijd());
            newbezoekersParkeertijd.setEindtijd(bezoekersParkeertijd.getEindtijd());
            newbezoekersParkeertijd.setDag(bezoekersParkeertijd.getDag());
            Parkeerzone parkeerzone = new Parkeerzone();
            parkeerzone.setZone(bezoekersParkeertijd.getParkeerzone().getZone());
            newbezoekersParkeertijd.setParkeerzone(parkeerzone);
            newbezoekersParkeertijd.setTarief(bezoekersParkeertijd.getTarief());
            
            bezoekersParkeertijden.add(newbezoekersParkeertijd);    
            
            for(Parkeertijden betaaldParkeertijd :parkeertijdenDao.findByType("betaald")){
                
                
                Parkeertijden newbetaaldparkeertijd = new Parkeertijden();
                if(bezoekersParkeertijd.getDag().equalsIgnoreCase(bezoekersParkeertijd.getDag()) && bezoekersParkeertijd.getParkeerzone().getZone().equalsIgnoreCase(bezoekersParkeertijd.getParkeerzone().getZone())){
                    
                    
                    
                    
                    
                    newbetaaldparkeertijd.setBegintijd(bezoekersParkeertijd.getEindtijd());
                    newbetaaldparkeertijd.setEindtijd(bezoekersParkeertijd.getEindtijd());
                    Parkeerzone parkeerzone1 = new Parkeerzone();
                    parkeerzone1.setZone(bezoekersParkeertijd.getParkeerzone().getZone());
                    newbetaaldparkeertijd.setParkeerzone(parkeerzone1);
                    newbetaaldparkeertijd.setDag(bezoekersParkeertijd.getDag());
                    newbetaaldparkeertijd.setTarief(bezoekersParkeertijd.getTarief());
                    break;
                    
                    
                }
                
                betaaldParkeertijden.add(newbetaaldparkeertijd);
                
            }
            
        }
        
        resultParkeertijden.addAll(bezoekersParkeertijden);
        resultParkeertijden.addAll(betaaldParkeertijden);
        return resultParkeertijden;
    }


    public List<Parkeertijden> findByParkeerzone(String parkeerzone) {
        return parkeertijdenDao.findByParkeerzone(parkeerzone);
    }



    public Parkeertijden findByDatum(Timestamp begintijd) {
        return parkeertijdenDao.findByDatum(begintijd);
    }
    

    public List<Parkeertijden> ophalenParkeertijdenByDateEnParkeerzone(Date date,String parkeerzone) {             
        return  parkeertijdenDao.findByDayAndParkeerzone(date,parkeerzone);
    }

    public List<Parkeertijden> ophalenParkeertijdenByDate(Date date) {
        
        return parkeertijdenDao.findByDay(date);
    }


    public List<Parkeertijden> findByType(String type) {
        return parkeertijdenDao.findByType(type);
    }
}
