package nl.haarlem.services.parkeerrechten.service.impl;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;

import javax.ejb.Stateless;



import nl.haarlem.services.parkeerrechten.dao.ParkeertijdenDao;
import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;
import nl.haarlem.services.parkeerrechten.service.ParkeertijdenService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class ParkeertijdenServiceImpl implements ParkeertijdenService{

    private Logger log = LoggerFactory.getLogger(ParkeertijdenServiceImpl.class.getName());

    @EJB
    private ParkeertijdenDao parkeertijdenDao;
    

    public List<Parkeertijden> findAll() {
        
        return parkeertijdenDao.findAll();
    }


    public List<Parkeertijden> findByParkeerzone(String parkeerzone) {
        return parkeertijdenDao.findByParkeerzone(parkeerzone);
    }

    public List<Parkeertijden> findByParkeerzoneEnTijdsVenster(String parkeerzone,
                                                               Timestamp begintijd,
                                                               Timestamp eindtijd) {
        return parkeertijdenDao.findByParkeerzoneEnTijdsVenster(parkeerzone, begintijd, eindtijd);
    }


    public List<Parkeertijden> findByTijdsVenster(Timestamp begintijd,
                                                  Timestamp eindtijd) {
        return parkeertijdenDao.findByTijdsVenster(begintijd, eindtijd);
    }


    public Parkeertijden findByDatum(Timestamp begintijd) {
        return parkeertijdenDao.findByDatum(begintijd);
    }
    

    public List<Parkeertijden> ophalenParkeertijdenByDateEnParkeerzone(Date date,String parkeerzone) {             
        return  parkeertijdenDao.findByDayAndParkeerzone(date,parkeerzone);
    }

    public List<Parkeertijden> ophalenParkeertijdenByDate(Date date) {
        
        return parkeertijdenDao.findByDay(date);
    }
    
    
}
