package nl.haarlem.services.parkeerrechten.service;

import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.InstellingenEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;

@Local
public interface InstellingService {
   
    public List<InstellingenEntity> findInstellingenEntityByRecht(RechtEntity recht) throws BezoekersparkerenException;

    public void updateInstelling(String activeringscode, String key,String value)throws BezoekersparkerenException;
    public InstellingenEntity findNotificationMailByActiveringsCode(String activeringscode) throws BezoekersparkerenException;
    public void updateMailNotification(String activeringscode,String value)throws BezoekersparkerenException;
    public InstellingenEntity findInstellingByActiveringscodeAndKey(String activeringscode, String key) throws BezoekersparkerenException;
}
