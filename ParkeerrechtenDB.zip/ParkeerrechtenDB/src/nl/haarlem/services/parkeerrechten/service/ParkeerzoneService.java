package nl.haarlem.services.parkeerrechten.service;

import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.jpa.Parkeerzone;

@Local
public interface ParkeerzoneService {
    
    public List<Parkeerzone> findAllParkeerzones();
}
