package nl.haarlem.services.parkeerrechten.service;

import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.model.Registratie;

@Local
public interface RegistratieService {
    
    public Long aanmeldenKenteken(Registratie registratie) throws BezoekersparkerenException;
    public String afmeldenKenteken(Registratie registratie) throws BezoekersparkerenException;
    public Registratie ophalenActieveRegistratie(Registratie registratie) throws BezoekersparkerenException;
    public Double findTotalBedragByJaar(RechtEntity recht);
    
    public Registratie[] findRegistratiesByActiveringsCode(String activeringscode) throws BezoekersparkerenException;
    public Registratie[] ophalenRegstratiesHistorie(String activeringscode) throws BezoekersparkerenException;
    
    public String deleteRegistratie(Registratie registratie) throws BezoekersparkerenException;
    public String updateRegistratieEindtijd(Registratie registratie) throws BezoekersparkerenException;
    
    public boolean zoekGeregistreerdRegistratie(Registratie registratie) throws BezoekersparkerenException;
}
