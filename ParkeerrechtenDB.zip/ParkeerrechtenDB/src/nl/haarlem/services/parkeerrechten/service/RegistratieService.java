package nl.haarlem.services.parkeerrechten.service;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.model.Bestedingsruimte;
import nl.haarlem.services.parkeerrechten.model.Parkeertijd;
import nl.haarlem.services.parkeerrechten.model.Registratie;

@Local
public interface RegistratieService {
    
    public Registratie ophalenRegistratieById(Long id) throws BezoekersparkerenException;
    public Long aanmeldenKenteken(Registratie registratie) throws BezoekersparkerenException;
    public String afmeldenKenteken(Registratie registratie) throws BezoekersparkerenException;
    public Registratie ophalenActieveRegistratie(Registratie registratie) throws BezoekersparkerenException;
    public Double findTotalBedragByJaar(RechtEntity recht);
    
    public Registratie[] findRegistratiesByAanmeldcode(String aanmeldcode) throws BezoekersparkerenException;
    public Registratie[] ophalenRegstratiesHistorie(String aanmeldcode) throws BezoekersparkerenException;
    public Bestedingsruimte ophalenBestedingsruimte(String aanmeldcode) throws BezoekersparkerenException;
    public String deleteRegistratie(Registratie registratie) throws BezoekersparkerenException;
    public String updateRegistratieEindtijd(Registratie registratie) throws BezoekersparkerenException;
    
    public boolean zoekGeregistreerdRegistratie(Registratie registratie) throws BezoekersparkerenException;


    public List<Parkeertijd> ophalenParkeeraanmeldtijden(String aanmeldcode, Date date) throws BezoekersparkerenException;
}
