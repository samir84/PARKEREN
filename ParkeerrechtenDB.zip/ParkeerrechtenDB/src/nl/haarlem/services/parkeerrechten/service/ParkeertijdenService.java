package nl.haarlem.services.parkeerrechten.service;

import java.sql.Timestamp;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;


@Local
public interface ParkeertijdenService {
    
    public List<Parkeertijden> findAll();
    
    public List<Parkeertijden> findByParkeerzone(String parkeerzone);
    public List<Parkeertijden> findByParkeerzoneEnTijdsVenster(String parkeerzone,Timestamp begintijd, Timestamp eindtijd);
    public List<Parkeertijden> findByTijdsVenster(Timestamp begintijd, Timestamp eindtijd);
    public Parkeertijden findByDatum(Timestamp begintijd);

    public List<Parkeertijden> ophalenParkeertijdenByDate(Date date);
    public List<Parkeertijden> ophalenParkeertijdenByDateEnParkeerzone(Date date,String parkeerzone);
}
