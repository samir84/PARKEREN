package nl.haarlem.services.parkeerrechten.service;

import java.util.List;

import javax.ejb.Local;


import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.model.Recht;
import nl.haarlem.services.parkeerrechten.model.Registratie;

@Local
public interface RechtService {
   
    public boolean isAanmeldcode(String randomCode)throws BezoekersparkerenException ;
    public String updateRecht(Recht recht) throws BezoekersparkerenException;
    public String opzeggenRecht(String aanmeldcode) throws BezoekersparkerenException;
    public Recht ophalenBezoekersrechtByBSN(String bsn)throws  BezoekersparkerenException;
    public Recht ophalenBezoekersrechtByAanmeldcode(String aanmeldcode) throws  BezoekersparkerenException;
    public boolean checkBezoekersrechtByBSN(String bsn) throws  BezoekersparkerenException;
    public RechtEntity findByAanmeldcode(String aanmeldcode) throws  BezoekersparkerenException;
    public Long registrerenBezoekersrecht(Recht recht) throws BezoekersparkerenException;
    public String wijzigenAanmeldcode(String aanmeldcode) throws BezoekersparkerenException;

    public Recht ophalenRechtByNummerAanduiding(String nummerAanduiding) throws BezoekersparkerenException;
    
    public boolean verwijderRecht(String bsn);

}
