package nl.haarlem.services.parkeerrechten.service;

import java.util.List;

import javax.ejb.Local;


import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity;
import nl.haarlem.services.parkeerrechten.model.Recht;
import nl.haarlem.services.parkeerrechten.model.Registratie;

@Local
public interface RechtService {
   
    public boolean isActiveringscodeExist(String randomCode)throws BezoekersparkerenException ;
    public String updateRecht(Recht recht) throws BezoekersparkerenException;
    public String opzeggenRecht(String activeringscode) throws BezoekersparkerenException;
    public Recht ophalenBezoekersrechtByBSN(String bsn)throws  BezoekersparkerenException;
    public Recht ophalenBezoekersrechtByActiveringscode(String activeringscode) throws  BezoekersparkerenException;
    public boolean checkBezoekersrechtByBSN(String bsn) throws  BezoekersparkerenException;
    public RechtEntity findByActiveringscode(String activeringscode) throws  BezoekersparkerenException;
    public Long registrerenBezoekersrecht(Recht recht) throws BezoekersparkerenException;
    public String wijzigenActiveringscode(String activeringscode) throws BezoekersparkerenException;
    
}
