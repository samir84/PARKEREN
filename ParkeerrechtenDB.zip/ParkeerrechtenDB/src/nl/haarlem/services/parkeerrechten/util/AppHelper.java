package nl.haarlem.services.parkeerrechten.util;

import java.io.PrintStream;

import java.sql.Timestamp;

import java.text.DecimalFormat;

import java.util.Calendar;
import java.util.UUID;

public class AppHelper {


    private static AppHelper instance = null;

    protected AppHelper() {
        // Exists only to defeat instantiation.
    }

    public static AppHelper getInstance() {
        if (instance == null) {
            instance = new AppHelper();
        }
        return instance;
    }

    /**
     *Generate a unique random id for Activeringscode
     * @param string length
     * @return
     */
    public static String generateActiveringscode(int length) {
        UUID uuid = UUID.randomUUID();
        return uuid.toString().substring(0, length);

    }

    public static String generateNewActiveringsCode(String oldcode) {

        UUID uuid = UUID.randomUUID();
        String newCode = uuid.toString().substring(0, oldcode.length());
        while (oldcode.equals(newCode)) {
            newCode = generateActiveringscode(newCode.length());
        }
        return newCode;
    }
    private Double round(Double bedrag) {
        return Double.parseDouble(new DecimalFormat("##.####").format(bedrag));
    }

    private Timestamp calendarToTimestamp(Calendar calendar) {
        return new Timestamp(calendar.getTimeInMillis());
    }

    private Calendar timestampToCalendar(long millis) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        return calendar;
    }
    public boolean checkDifferenceBeginTimeEndTimeIs2min(Calendar calendarBegintime , Calendar calendarEndtime){
        
        long diffMinutes = (calendarEndtime.getTimeInMillis() - calendarBegintime.getTimeInMillis() ) / (60 * 1000) % 60; 
        
        return diffMinutes <= 2 ? true:false;
    }
}
