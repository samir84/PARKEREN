package nl.haarlem.services.parkeerrechten.util;

import java.sql.Timestamp;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateTimeHelper {

    private Logger log = LoggerFactory.getLogger(DateTimeHelper.class.getName());
    private static DateTimeHelper instance = null;

    protected DateTimeHelper() {
        // Exists only to defeat instantiation.
    }

    public static DateTimeHelper getInstance() {
        if (instance == null) {
            instance = new DateTimeHelper();
        }
        return instance;
    }

    private Timestamp calendarToTimestamp(Calendar calendar) {
        return new Timestamp(calendar.getTimeInMillis());
    }

    private Calendar timestampToCalendar(long millis) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        return calendar;
    }
    
   

    public boolean checkDifferenceBeginTimeEndTimeIs2min(Calendar calendarBegintime , Calendar calendarEndtime){
        
        Date start = calendarBegintime.getTime();
        Date end = calendarEndtime.getTime();
       if( start == null || end == null ) return false;
           
        long diff = end.getTime() - start.getTime();
        long diffSeconds = diff / 1000 % 60;
        long diffMinutes = diff / (60 * 1000) % 60;
        long diffHours = diff / (60 * 60 * 1000);
    
        
        if(diffHours == 0 && diffMinutes <2 ){
            return true;
        }
        else{
            return false;
        }

    }
    


}
