package nl.haarlem.services.parkeerrechten.util;

import java.sql.Timestamp;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateTimeHelper {

    private Logger log = LoggerFactory.getLogger(DateTimeHelper.class.getName());
    private static DateTimeHelper instance = null;

    protected DateTimeHelper() {
        // Exists only to defeat instantiation.
    }

    public static DateTimeHelper getInstance() {
        if (instance == null) {
            instance = new DateTimeHelper();
        }
        return instance;
    }

    private  Float ophalenBestedingsLimit(String rechtType) {
        if (rechtType.equalsIgnoreCase("BEZOEKER")) {
            return new Float(125);
        } else if (rechtType.equalsIgnoreCase("MANTELZORG")) {
            return new Float(25);
        } else {
            return new Float(0);
        }
    }

    /**
     *
     * @return bestedingslimiet anaf de begindatum(lopende maand) van de rechistratie
     */
    public  Float CalculateBestedingsLimit(String rechtType , Timestamp date) {
        double bestedingsLimit = ophalenBestedingsLimit(rechtType);
        log.info("date: "+date);
        Float result = new Float(0);
        Calendar cal = Calendar.getInstance();
        if(isSameYear(date, new Date())){
            cal.setTimeInMillis(date.getTime());
            int restMonthsOfYear = 12 - cal.get(Calendar.MONTH);
            log.info("restMonthsOfYear): "+restMonthsOfYear);
            result = new Float((restMonthsOfYear * bestedingsLimit) / 12);
        }else{  
            result = new Float(bestedingsLimit);
        }
        
        return result;
    }
    private boolean isSameYear(Date date1, Date date2) {
        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(date1);
        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTime(date2);
        boolean sameYear = calendar1.get(Calendar.YEAR) == calendar2.get(Calendar.YEAR);
        return sameYear;
    }

    public static void main (String args[]) throws ParseException {
        
        //final Calendar cal = Calendar.getInstance();
        //cal.set(2017, Calendar.JANUARY, 1);

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date parsedDate = dateFormat.parse("01-02-17");
            Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
       
        Float result = new DateTimeHelper().getInstance().CalculateBestedingsLimit("BEZOEKER" ,timestamp);
        System.out.println(result);           
    }
    


}
