package nl.haarlem.services.parkeerrechten.jpa;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;


@Entity
@Table(name = "RECHTTYPE")
@NamedQueries( { @NamedQuery(name = "Rechtype.findAll",
                             query = "select o from RechtTypeEntity o"),
                 @NamedQuery(name = "Rechtype.findByRechtID",
                             query = "select o from RechtTypeEntity o where o.recht = :p_recht") })
public class RechtTypeEntity implements Serializable {
    private static final long serialVersionUID = -2544589134548624485L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
                    generator = "SeqRechtTypeId")
    @SequenceGenerator(name = "SeqRechtTypeId",
                       sequenceName = "SEQ_RECHT_TYPE_ID")
    @Column(nullable = false)
    private Long id;
    private Timestamp begindatum;
    private Timestamp einddatum;
    @ManyToOne
    @JoinColumn(name = "RECHT_ID")
    private RechtEntity recht;
    @Column(length = 20)
    private String naam;

    public RechtTypeEntity() {
    }

    public RechtTypeEntity(Timestamp begindatum, Timestamp einddatum, Long id,
                           RechtEntity recht, String naam) {
        this.begindatum = begindatum;
        this.einddatum = einddatum;
        this.id = id;
        this.recht = recht;
        this.naam = naam;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getBegindatum() {
        return begindatum;
    }

    public void setBegindatum(Timestamp begindatum) {
        this.begindatum = begindatum;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getEinddatum() {
        return einddatum;
    }

    public void setEinddatum(Timestamp einddatum) {
        this.einddatum = einddatum;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public RechtEntity getRecht() {
        return recht;
    }

    public void setRecht(RechtEntity recht) {
        this.recht = recht;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }


}
