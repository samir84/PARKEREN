package nl.haarlem.services.parkeerrechten.jpa;

import java.io.Serializable;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "Parkeerzone.findAll", query = "select o from Parkeerzone o")
})
@Table(name = "PARKEERZONE")
public class Parkeerzone implements Serializable {
    @Id
    @Column(nullable = false)
    private Long id;
    @Column(nullable = false, length = 50)
    private String zone;
    @OneToMany(mappedBy = "parkeerzone")
    private List<Parkeertijden> parkeertijdenList;

    public Parkeerzone() {
    }

    public Parkeerzone(Long id, String zone) {
        this.id = id;
        this.zone = zone;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public List<Parkeertijden> getParkeertijdenList() {
        return parkeertijdenList;
    }

    public void setParkeertijdenList(List<Parkeertijden> parkeertijdenList) {
        this.parkeertijdenList = parkeertijdenList;
    }

    public Parkeertijden addParkeertijden(Parkeertijden parkeertijden) {
        getParkeertijdenList().add(parkeertijden);
        parkeertijden.setParkeerzone(this);
        return parkeertijden;
    }

    public Parkeertijden removeParkeertijden(Parkeertijden parkeertijden) {
        getParkeertijdenList().remove(parkeertijden);
        parkeertijden.setParkeerzone(null);
        return parkeertijden;
    }
}
