package nl.haarlem.services.parkeerrechten.jpa;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;


@Entity
@Table(name = "Registratie")
@NamedQueries({
  @NamedQuery(name = "Registratie.findAll", query = "select o from RegistratieEntity o"),
  @NamedQuery(name = "Registratie.findById", query = "select o from RegistratieEntity o where o.id = :p_id"),
  @NamedQuery(name = "Registratie.findValidByRecht", query = "select o from RegistratieEntity o where o.recht = :p_recht and (o.eindtijd IS NULL or o.eindtijd > CURRENT_TIMESTAMP)"),
  @NamedQuery(name = "Registratie.findValidByRechtHistorie", query = "select o from RegistratieEntity o where o.recht = :p_recht and (o.eindtijd IS NOT NULL and o.eindtijd < CURRENT_TIMESTAMP) order by o.eindtijd desc"),
  @NamedQuery(name = "Registratie.findActieveRegistratieByKenteken", query = "select o from RegistratieEntity o where o.kenteken = :p_kenteken and o.recht = :p_recht and o.begintijd < CURRENT_TIMESTAMP and o.eindtijd > CURRENT_TIMESTAMP"),
  @NamedQuery(name = "Registratie.findGeregistreerdeRegistraties", query = "select o from RegistratieEntity o where o.kenteken = :p_kenteken and o.recht = :p_recht and (:p_begintijd BETWEEN o.begintijd and o.eindtijd or :p_eindtijd BETWEEN o.begintijd and o.eindtijd)"),
  @NamedQuery(name = "Registratie.findActieveRegistratieById", query = "select o from RegistratieEntity o where o.id = :p_id and (o.eindtijd IS NULL or o.eindtijd > CURRENT_TIMESTAMP)"),
  @NamedQuery(name = "Registratie.findRegistratiesHuidigJaar", query = "select SUM(o.bedrag) from RegistratieEntity o where o.recht = :p_recht and o.begintijd > :p_datum")
})
public class RegistratieEntity implements Serializable {
    private Double bedrag;
    private Timestamp begintijd;
    private Timestamp eindtijd;
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "SeqRegistratieId") 
    @SequenceGenerator(name = "SeqRegistratieId", sequenceName = "SEQ_REGISTRATIE_ID")
    private Long id;
    @Column(length = 20)
    private String kenteken;
    @ManyToOne
    @JoinColumn(name = "RECHT_ID")
    private RechtEntity recht;

    public RegistratieEntity() {
    }

    public RegistratieEntity(Double bedrag, Timestamp begintijd, Timestamp eindtijd,
                       Long id, String kenteken, RechtEntity recht) {
        this.bedrag = bedrag;
        this.begintijd = begintijd;
        this.eindtijd = eindtijd;
        this.id = id;
        this.kenteken = kenteken;
        this.recht = recht;
    }

    public Double getBedrag() {
        return bedrag;
    }

    public void setBedrag(Double bedrag) {
        this.bedrag = bedrag;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getBegintijd() {
        return begintijd;
    }

    public void setBegintijd(Timestamp begintijd) {
        this.begintijd = begintijd;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getEindtijd() {
        return eindtijd;
    }

    public void setEindtijd(Timestamp eindtijd) {
        this.eindtijd = eindtijd;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getKenteken() {
        return kenteken;
    }

    public void setKenteken(String kenteken) {
        this.kenteken = kenteken;
    }


    public RechtEntity getRecht() {
        return recht;
    }

    public void setRecht(RechtEntity recht) {
        this.recht = recht;
    }
}
