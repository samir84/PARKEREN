package nl.haarlem.services.parkeerrechten.jpa;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.persistence.Table;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;

@Entity
@Table(name = "Instellingen")
@NamedQueries({
  @NamedQuery(name = "InstellingenEntity.findAll", query = "select o from InstellingenEntity o"),
    @NamedQuery(name = "InstellingenEntity.findInstellingenEntityByRecht", query = "select o from InstellingenEntity o where o.recht =:p_recht "),
      @NamedQuery(name = "InstellingenEntity.findInstellingByRechtAndKey", query = "select o from InstellingenEntity o where o.recht =:p_recht and o.key= :p_key"),
  @NamedQuery(name = "InstellingenEntity.findEmailNotifictionByRechtId", query = "select o from InstellingenEntity o where o.recht =:p_recht and o.key='Email_Notification'")
})
public class InstellingenEntity implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Column(name="DATUMCHECK")
    private Timestamp datumcheck;
    @Column(name="KEY")
    private String key;
    @Column(name="VALUE")
    private String value;
    @Id     
    @ManyToOne
    @JoinColumn(name = "RECHT_ID")
    private RechtEntity recht;

    public InstellingenEntity() {
    }

    
    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getDatumcheck() {
        return datumcheck;
    }

    public void setDatumcheck(Timestamp datumcheck) {
        this.datumcheck = datumcheck;
    }

  


    public void setRecht(RechtEntity recht) {
        this.recht = recht;
    }

    public RechtEntity getRecht() {
        return recht;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
