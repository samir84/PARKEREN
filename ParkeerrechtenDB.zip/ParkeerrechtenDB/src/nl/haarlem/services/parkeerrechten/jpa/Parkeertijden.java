package nl.haarlem.services.parkeerrechten.jpa;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;

@Entity
@Table(name = "Parkeertijden")
@NamedQueries( { @NamedQuery(name = "Parkeertijden.findAll", query = "select o from Parkeertijden o order by o.parkeerzone, o.begintijd"),
                 @NamedQuery(name = "Parkeertijden.findByParkeerzone", 
                            query ="select o from Parkeertijden o where UPPER(o.parkeerzone) = UPPER(:p_parkeerzone)  "),
                 @NamedQuery(name = "Parkeertijden.findByTijdsVenster", 
                             query ="select o from Parkeertijden o where o.begintijd= :p_begintijd and o.eindtijd= :p_eindtijd"),
                 @NamedQuery(name = "Parkeertijden.findByParkeerzoneEnTijdsVenster", 
                             query ="select o from Parkeertijden o where UPPER(o.parkeerzone)= UPPER(:p_parkeerzone) and o.begintijd= :p_begintijd and o.eindtijd= :p_eindtijd"),
                 @NamedQuery(name = "Parkeertijden.findByDatum", 
                             query ="select o from Parkeertijden o where o.begintijd>= :p_begintijd and o.eindtijd<= :p_eindtijd")
})

public class Parkeertijden implements Serializable{
    
    private static final long serialVersionUID = -5814597527317150423L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    //@GeneratedValue(strategy = GenerationType.SEQUENCE,
                    //generator = "SeqParkeertijdenId")
    //@SequenceGenerator(name = "SeqParkeertijdenId", sequenceName = "SEQ_PARKEERTIJDEN_ID")
    private Long id;
    
    @Column(nullable = false, length = 20)
    private String parkeerzone;
    
    @Column(length = 1)
    private String maandag;
    @Column(length = 1)
    private String dinsdag;
    @Column(length = 1)
    private String woensdag;
    @Column(length = 1)
    private String donderdag;
    @Column(length = 1)
    private String vrijdag;
    @Column(length = 1)
    private String zaterdag;
    @Column(length = 1)
    private String zondag;
    
    private Timestamp begintijd;
    private Timestamp eindtijd;
    private double tarief;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    

    public void setBegintijd(Timestamp begintijd) {
        this.begintijd = begintijd;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getBegintijd() {
        return begintijd;
    }

    public void setEindtijd(Timestamp eindtijd) {
        this.eindtijd = eindtijd;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getEindtijd() {
        return eindtijd;
    }

    public void setParkeerzone(String parkeerzone) {
        this.parkeerzone = parkeerzone;
    }

    public String getParkeerzone() {
        return parkeerzone;
    }

    public void setMaandag(String maandag) {
        this.maandag = maandag;
    }

    public String getMaandag() {
        return maandag;
    }

    public void setDinsdag(String dinsdag) {
        this.dinsdag = dinsdag;
    }

    public String getDinsdag() {
        return dinsdag;
    }

    public void setWoensdag(String woensdag) {
        this.woensdag = woensdag;
    }

    public String getWoensdag() {
        return woensdag;
    }

    public void setDonderdag(String donderdag) {
        this.donderdag = donderdag;
    }

    public String getDonderdag() {
        return donderdag;
    }

    public void setVrijdag(String vrijdag) {
        this.vrijdag = vrijdag;
    }

    public String getVrijdag() {
        return vrijdag;
    }

    public void setZaterdag(String zaterdag) {
        this.zaterdag = zaterdag;
    }

    public String getZaterdag() {
        return zaterdag;
    }

    public void setZondag(String zondag) {
        this.zondag = zondag;
    }

    public String getZondag() {
        return zondag;
    }

    public void setTarief(double tarief) {
        this.tarief = tarief;
    }

    public double getTarief() {
        return tarief;
    }
}
