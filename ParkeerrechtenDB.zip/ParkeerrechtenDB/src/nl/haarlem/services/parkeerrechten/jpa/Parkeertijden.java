package nl.haarlem.services.parkeerrechten.jpa;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;

@Entity
@NamedQueries({
  @NamedQuery(name = "Parkeertijden.findAll", query = "select o from Parkeertijden o order by o.begintijd"),
  @NamedQuery(name = "Parkeertijden.findByType", query = "select o from Parkeertijden o where o.type =:p_type order by o.begintijd,o.parkeerzone.zone")
})
public class Parkeertijden implements Serializable {
    
    @Column(nullable = false)
    private Timestamp begintijd;
    @Column(nullable = false, length = 20)
    private String dag;
    @Column(nullable = false)
    private Timestamp eindtijd;
    @Id
    @Column(nullable = false)
    private Long id;
    private Double tarief;
    @Column(nullable = false, length = 20)
    private String type;
    @ManyToOne
    @JoinColumn(name = "PARKEERZONE_ID")
    private Parkeerzone parkeerzone;

    public Parkeertijden() {
    }

    public Parkeertijden(Timestamp begintijd, String dag, Timestamp eindtijd,
                         Long id, Parkeerzone parkeerzone1, Double tarief,
                         String type) {
        this.begintijd = begintijd;
        this.dag = dag;
        this.eindtijd = eindtijd;
        this.id = id;
        this.parkeerzone = parkeerzone1;
        this.tarief = tarief;
        this.type = type;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getBegintijd() {
        return begintijd;
    }

    public void setBegintijd(Timestamp begintijd) {
        this.begintijd = begintijd;
    }

    public String getDag() {
        return dag;
    }

    public void setDag(String dag) {
        this.dag = dag;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getEindtijd() {
        return eindtijd;
    }

    public void setEindtijd(Timestamp eindtijd) {
        this.eindtijd = eindtijd;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public Double getTarief() {
        return tarief;
    }

    public void setTarief(Double tarief) {
        this.tarief = tarief;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Parkeerzone getParkeerzone() {
        return parkeerzone;
    }

    public void setParkeerzone(Parkeerzone parkeerzone1) {
        this.parkeerzone = parkeerzone1;
    }
}
