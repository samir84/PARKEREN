package nl.haarlem.services.parkeerrechten.jpa;


import java.io.Serializable;

import java.sql.Timestamp;

import java.util.List;

import java.util.Set;


import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.QueryHint;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.annotations.CacheType;

@Entity
@Table(name = "Recht")
@NamedQueries( { @NamedQuery(name = "Recht.findAll",
                             query = "select o from RechtEntity o"),
                 
                 @NamedQuery(name = "Recht.findByBSN", query = "select o from RechtEntity o where o.bsn = :p_bsn and (o.einddatum IS NULL or o.einddatum > :p_huidigeTijd)"),

                 @NamedQuery(name = "Recht.findByAanmeldcode", query = "select o from RechtEntity o where o.aanmeldcode = :p_aanmeldcode and (o.einddatum IS NULL or o.einddatum > :p_huidigeTijd) "),
                 @NamedQuery(name = "Recht.findRechtByNummerAanduiding", query = "select o from RechtEntity o where o.nummerAanduiding = :p_nummerAanduiding and (o.einddatum IS NULL or o.einddatum > :p_huidigeTijd)")
                 
        } )

public class RechtEntity implements Serializable {

    private static final long serialVersionUID = -5814597527317150423L;
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
                    generator = "SeqRechtId")
    @SequenceGenerator(name = "SeqRechtId", sequenceName = "SEQ_RECHT_ID")
    private Long id;

    @Column(nullable = false, length = 20)
    private String aanmeldcode;

    private Timestamp begindatum;

    @Column(name = "IBAN")
    private String iban;
    @Column(name="NUMMER_AANDUIDING", unique = true)
    private String nummerAanduiding;
    @Column(name = "BSN")
    private String bsn;
    @Column(name = "EMAILADRES")
    private String email;
    private Timestamp einddatum;

    @Column(name = "AKKOORD_INCASSO", length = 1)
    private String akkoordIncasso;
    @Column(length = 20)
    private String zone;
    
    @OneToMany(mappedBy = "recht",cascade=CascadeType.ALL, orphanRemoval=true)
    private List<InstellingenEntity> InstellingenEntity;
    
    @OneToMany(mappedBy = "recht",cascade=CascadeType.ALL, orphanRemoval=true)
    private List<RegistratieEntity> registratieList;
    @OneToMany(mappedBy = "recht",cascade=CascadeType.ALL, orphanRemoval=true)
    private List<RechtTypeEntity> rechtTypeList;

    @OneToOne(mappedBy = "recht",cascade=CascadeType.ALL, orphanRemoval=true)
    private AlgemeneVoorwaardenEntity algemeneVoorwaarden;

    public RechtEntity() {
    }

    public RechtEntity(String aanmeldcode, Timestamp begindatum,
                       String bsn, Timestamp einddatum, Long id, String zone,
                       String email) {
        this.aanmeldcode = aanmeldcode;
        this.begindatum = begindatum;
        this.bsn = bsn;
        this.einddatum = einddatum;
        this.id = id;
        this.zone = zone;
        this.email = email;
    }

    

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getBegindatum() {
        return begindatum;
    }

    public void setBegindatum(Timestamp begindatum) {
        this.begindatum = begindatum;
    }

    public String getBsn() {
        return bsn;
    }

    public void setBsn(String bsn) {
        this.bsn = bsn;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getEinddatum() {
        return einddatum;
    }

    public void setEinddatum(Timestamp einddatum) {
        this.einddatum = einddatum;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public List<nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity> getRegistratieList() {
        return registratieList;
    }

    public void setRegistratieList(List<nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity> registratieList) {
        this.registratieList = registratieList;
    }

    public nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity addRegistratie(nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity registratie) {
        getRegistratieList().add(registratie);
        registratie.setRecht(this);
        return registratie;
    }

    public nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity removeRegistratie(nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity registratie) {
        getRegistratieList().remove(registratie);
        registratie.setRecht(null);
        return registratie;
    }

    public List<RechtTypeEntity> getRechtTypeList() {
        return rechtTypeList;
    }

    public void setRechtTypeList(List<RechtTypeEntity> rechtTypeList) {
        this.rechtTypeList = rechtTypeList;
    }

    public RechtTypeEntity addRechtType(RechtTypeEntity rechtType) {
        getRechtTypeList().add(rechtType);
        rechtType.setRecht(this);
        return rechtType;
    }

    public RechtTypeEntity removeRechtType(RechtTypeEntity rechtType) {
        getRechtTypeList().remove(rechtType);
        rechtType.setRecht(null);
        return rechtType;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getIban() {
        return iban;
    }

    public void setAkkoordIncasso(String akkoordIncasso) {
        this.akkoordIncasso = akkoordIncasso;
    }

    public String getAkkoordIncasso() {
        return akkoordIncasso;
    }


    public void setInstellingenEntity(List<InstellingenEntity> InstellingenEntity) {
        this.InstellingenEntity = InstellingenEntity;
    }

    public List<InstellingenEntity> getInstellingenEntity() {
        return InstellingenEntity;
    }


    public void setNummerAanduiding(String nummerAanduiding) {
        this.nummerAanduiding = nummerAanduiding;
    }

    public String getNummerAanduiding() {
        return nummerAanduiding;
    }

    public void setAlgemeneVoorwaarden(AlgemeneVoorwaardenEntity algemeneVoorwaarden) {
        this.algemeneVoorwaarden = algemeneVoorwaarden;
    }

    public AlgemeneVoorwaardenEntity getAlgemeneVoorwaarden() {
        return algemeneVoorwaarden;
    }

    public void setAanmeldcode(String aanmeldcode) {
        this.aanmeldcode = aanmeldcode;
    }

    public String getAanmeldcode() {
        return aanmeldcode;
    }
}
