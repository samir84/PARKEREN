package nl.haarlem.services.parkeerrechten.jpa;

import java.io.Serializable;

import java.sql.Timestamp;

import java.util.List;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import nl.haarlem.services.parkeerrechten.util.TimestampAdapter;

@Entity
@Table(name = "Recht")
@NamedQueries({
  @NamedQuery(name = "Recht.findAll", query = "select o from RechtEntity o"),
  @NamedQuery(name = "Recht.findByBSN", query = "select o from RechtEntity o where o.bsn = :p_bsn"),
  @NamedQuery(name = "Recht.findByActiveringscode", query = "select o from RechtEntity o where o.activeringscode = :p_activeringscode")
  //@NamedQuery(name = "Recht.findBezoekersrechtByBSN", query = "select o from RechtEntity o where o.bsn = :p_bsn")
})

public class RechtEntity implements Serializable {
    
    private static final long serialVersionUID = -5814597527317150423L;
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "SeqRechtId") 
    @SequenceGenerator(name = "SeqRechtId", sequenceName = "SEQ_RECHT_ID")
    private Long id;
    
    @Column(nullable = false, length = 20)
    private String activeringscode;
    
    private Timestamp begindatum;
    
    private String bsn;
    @Column(name = "EMAILADRES")
    private String email;
    private Timestamp einddatum;

   
    @Column(length = 20)
    private String zone;
    @OneToMany(mappedBy = "recht")
    private List<RegistratieEntity> registratieList;
    @OneToMany(mappedBy = "recht")
    private List<RechtTypeEntity> rechtTypeList;
    
    @OneToMany(mappedBy = "recht", targetEntity = AlgemeneVoorwaardenEntity.class )
    private List<AlgemeneVoorwaardenEntity> algemeneVoorwaarden;
    
    public RechtEntity() {
    }

    public RechtEntity(String activeringscode, Timestamp begindatum, String bsn,
                 Timestamp einddatum, Long id, String zone, String email) {
        this.activeringscode = activeringscode;
        this.begindatum = begindatum;
        this.bsn = bsn;
        this.einddatum = einddatum;
        this.id = id;
        this.zone = zone;
        this.email = email;
    }

    public String getActiveringscode() {
        return activeringscode;
    }

    public void setActiveringscode(String activeringscode) {
        this.activeringscode = activeringscode;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)
    public Timestamp getBegindatum() {
        return begindatum;
    }

    public void setBegindatum(Timestamp begindatum) {
        this.begindatum = begindatum;
    }

    public String getBsn() {
        return bsn;
    }

    public void setBsn(String bsn) {
        this.bsn = bsn;
    }

    @XmlJavaTypeAdapter(value = TimestampAdapter.class, type = Timestamp.class)  
    public Timestamp getEinddatum() {
        return einddatum;
    }

    public void setEinddatum(Timestamp einddatum) {
        this.einddatum = einddatum;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public List<RegistratieEntity> getRegistratieList() {
        return registratieList;
    }

    public void setRegistratieList(List<RegistratieEntity> registratieList) {
        this.registratieList = registratieList;
    }

    public RegistratieEntity addRegistratie(RegistratieEntity registratie) {
        getRegistratieList().add(registratie);
        registratie.setRecht(this);
        return registratie;
    }

    public RegistratieEntity removeRegistratie(RegistratieEntity registratie) {
        getRegistratieList().remove(registratie);
        registratie.setRecht(null);
        return registratie;
    }

    public List<RechtTypeEntity> getRechtTypeList() {
        return rechtTypeList;
    }

    public void setRechtTypeList(List<RechtTypeEntity> rechtTypeList) {
        this.rechtTypeList = rechtTypeList;
    }

    public RechtTypeEntity addBestedingsruimte(RechtTypeEntity rechtType) {
        getRechtTypeList().add(rechtType);
        rechtType.setRecht(this);
        return rechtType;
    }

    public RechtTypeEntity removeRechtType(RechtTypeEntity rechtType) {
        getRechtTypeList().remove(rechtType);
        rechtType.setRecht(null);
        return rechtType;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setAlgemeneVoorwaarden(List<AlgemeneVoorwaardenEntity> algemeneVoorwaarden) {
        this.algemeneVoorwaarden = algemeneVoorwaarden;
    }

    public List<AlgemeneVoorwaardenEntity> getAlgemeneVoorwaarden() {
        return algemeneVoorwaarden;
    }
}
