package nl.haarlem.services.parkeerrechten.test;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import nl.haarlem.services.parkeerrechten.ParkeerrechtenSessionEJBBean;
import nl.haarlem.services.parkeerrechten.model.Recht;

public class ParkeerrechtenTestclient {
    
    public static void main(String[] arg) {
        Recht recht = new Recht();
        recht.setBsn(185890805l);
        recht.setBankNummer("");
        recht.setAkkoord("Y");
        final Context context;
        try {
          context = getInitialContext();
           ParkeerrechtenSessionEJBBean facade = (ParkeerrechtenSessionEJBBean)context.lookup("ParkeerrechtenDB#nl.haarlem.services.parkeerrechten.ParkeerrechtenSessionEJB");
            facade.registrerenBezoekersrecht(recht);
            
        } catch (NamingException e) {
            e.printStackTrace();
        }
        System.out.println("testing123....");
        
    }
    
    private static Context getInitialContext() throws NamingException {
        Hashtable env = new Hashtable();
        // WebLogic Server 10.x connection details
        env.put( Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory" );
        //env.put(Context.PROVIDER_URL, "t3://127.0.0.1:7101");
        env.put(Context.PROVIDER_URL, "t3://wohso.ssc.lan:8001");
        return new InitialContext( env );
    }
}
