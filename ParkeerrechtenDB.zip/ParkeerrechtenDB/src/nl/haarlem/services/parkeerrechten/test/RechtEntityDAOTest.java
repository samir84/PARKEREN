package nl.haarlem.services.parkeerrechten.test;

import java.sql.Timestamp;

import java.util.Date;

import nl.haarlem.services.parkeerrechten.dao.impl.RechtEntityDAOImpl;

import nl.haarlem.services.parkeerrechten.model.Recht;

import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;

import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;

import nl.haarlem.services.parkeerrechten.model.Instelling;
import nl.haarlem.services.parkeerrechten.service.impl.RechtServiceImpl;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class RechtEntityDAOTest extends JPAtTest {

    private RechtEntityDAOImpl rechtEntityDao = new RechtEntityDAOImpl();
    private RechtServiceImpl rechtServiceImpl = new RechtServiceImpl();

    @Before
    public void initializeEM(){
        rechtEntityDao.setEm(em);
    }
    
    //@Test
    public void ophalenBezoekersRechtBYBSN() throws BezoekersparkerenException {
        
        String bsn = "123456";
        //Recht recht = rechtEntityDao.ophalenBezoekersrechtByBSN(bsn);
        RechtEntity recht = rechtEntityDao.ophalenBezoekersrechtByBSN(bsn);
        System.out.println("aanmeldcode: "+recht.getAanmeldcode());
        Assert.assertNotNull(recht);
    }
    // @Test
     public void findRechtByaanmeldcode() throws BezoekersparkerenException {
         //String aanmeldcode = "AC1000";
         String aanmeldcode = "asasd";
         System.out.println("is already there? :" +
                            rechtServiceImpl.findByAanmeldcode(aanmeldcode));
         Assert.assertEquals(new Long(1000),rechtServiceImpl.findByAanmeldcode(aanmeldcode).getId());
     }
   
    
  
    
    
    //@Test
    public void updateRechtTest() throws BezoekersparkerenException {
       // RechtEntityDao.setEm(em);
        //String aanmeldcode = "AC1000";
        System.out.println("test update recht!");
        Recht recht = new Recht();
        recht.setAanmeldcode("952dde");
        recht.setIban("banknummer-test");
        recht.setEmail("samir.elazzouzi@haarlem.nl");
        Instelling instelling = new Instelling();
        instelling.setDatumcheck(new Timestamp(new Date().getTime()));
        instelling.setKey("Email_Notification");
        instelling.setValue("nee");
        rechtServiceImpl.updateRecht(recht);
        System.out.println("email is: "+rechtEntityDao.findByAanmeldcode("AC1000").getEmail());
        Assert.assertEquals("1samir.elazzouzi@haarlem.nl",rechtEntityDao.findByAanmeldcode("AC1000").getEmail());
    }
    
    //@Test
    public void ophalenRegstratiesHistorie(){
        
        String aanmeldcode = "AC1000";
        RechtEntity rechtEntity = rechtEntityDao.findByAanmeldcode(aanmeldcode);
        if (rechtEntity == null) {
           System.out.println("Geen Bezoekers recht gevonden met aanmeldcode :" +
                                                aanmeldcode);
        }
        System.out.println("rechtEntity :" +rechtEntity.getBsn());
    }
   
}
