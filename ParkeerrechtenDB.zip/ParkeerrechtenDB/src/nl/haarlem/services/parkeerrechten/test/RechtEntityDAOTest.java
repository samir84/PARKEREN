package nl.haarlem.services.parkeerrechten.test;

import java.sql.Timestamp;

import java.util.Date;

import nl.haarlem.services.parkeerrechten.dao.impl.RechtEntityDAOImpl;

import nl.haarlem.services.parkeerrechten.model.Recht;

import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;

import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;

import nl.haarlem.services.parkeerrechten.model.Instelling;
import nl.haarlem.services.parkeerrechten.service.impl.RechtServiceImpl;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class RechtEntityDAOTest extends JPAtTest {

    private RechtEntityDAOImpl rechtEntityDao = new RechtEntityDAOImpl();
    private RechtServiceImpl rechtServiceImpl = new RechtServiceImpl();

    @Before
    public void initializeEM(){
        rechtEntityDao.setEm(em);
    }
    
    //@Test
    public void ophalenBezoekersRechtBYBSN() throws BezoekersparkerenException {
        
        String bsn = "123456";
        //Recht recht = rechtEntityDao.ophalenBezoekersrechtByBSN(bsn);
        RechtEntity recht = rechtEntityDao.ophalenBezoekersrechtByBSN(bsn);
        System.out.println("Activeringscode: "+recht.getActiveringscode());
        Assert.assertNotNull(recht);
    }
    // @Test
     public void findRechtByActiveringscode() throws BezoekersparkerenException {
         //String activeringscode = "AC1000";
         String activeringscode = "asasd";
         System.out.println("is already there? :" +
                            rechtServiceImpl.findByActiveringscode(activeringscode));
         Assert.assertEquals(new Long(1000),rechtServiceImpl.findByActiveringscode(activeringscode).getId());
     }
    //@Test
    public void isActiveringscodeExist() {
        //RechtEntityDao.setEm(em);
        //String activeringscode = "AC0980";
        String activeringscode = "AC1000";
        System.out.println("is already there? :" +
                           rechtEntityDao.isActiveringscodeExist(activeringscode));
        Assert.assertEquals(true,
                            rechtEntityDao.isActiveringscodeExist(activeringscode));
    }
    
  
    
    
    @Test
    public void updateRechtTest() throws BezoekersparkerenException {
       // RechtEntityDao.setEm(em);
        //String activeringscode = "AC1000";
        System.out.println("test update recht!");
        Recht recht = new Recht();
        recht.setActiveringscode("952dde");
        recht.setIban("banknummer-test");
        recht.setEmail("samir.elazzouzi@haarlem.nl");
        Instelling instelling = new Instelling();
        instelling.setDatumcheck(new Timestamp(new Date().getTime()));
        instelling.setKey("Email_Notification");
        instelling.setValue("nee");
        rechtServiceImpl.updateRecht(recht);
        System.out.println("email is: "+rechtEntityDao.findByActiveringscode("AC1000").getEmail());
        Assert.assertEquals("1samir.elazzouzi@haarlem.nl",rechtEntityDao.findByActiveringscode("AC1000").getEmail());
    }
    
    //@Test
    public void ophalenRegstratiesHistorie(){
        
        String activeringscode = "AC1000";
        RechtEntity rechtEntity = rechtEntityDao.findByActiveringscode(activeringscode);
        if (rechtEntity == null) {
           System.out.println("Geen Bezoekers recht gevonden met activeringscode :" +
                                                activeringscode);
        }
        System.out.println("rechtEntity :" +rechtEntity.getBsn());
    }
   
}
