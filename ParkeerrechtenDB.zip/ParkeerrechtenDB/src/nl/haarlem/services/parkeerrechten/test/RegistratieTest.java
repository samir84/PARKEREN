package nl.haarlem.services.parkeerrechten.test;

import java.util.List;

import nl.haarlem.services.parkeerrechten.dao.RegistratieDAO;

import nl.haarlem.services.parkeerrechten.dao.impl.RegistratieDAOImpl;

import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;

import nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity;

import nl.haarlem.services.parkeerrechten.model.Recht;
import nl.haarlem.services.parkeerrechten.model.Registratie;
import nl.haarlem.services.parkeerrechten.service.impl.RechtServiceImpl;

import nl.haarlem.services.parkeerrechten.service.impl.RegistratieServiceImpl;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class RegistratieTest extends JPAtTest{

    RegistratieDAOImpl registratieDAO = new RegistratieDAOImpl();
    RechtServiceImpl rechtServiceImpl = new RechtServiceImpl();
    RegistratieServiceImpl registratieServiceImpl = new RegistratieServiceImpl();
    
    @Before
    public void initializeEM(){
        registratieDAO.setEm(em);
    }
    
    //@Test
    public void ophalenRegistraties() throws BezoekersparkerenException {
        
        String activeringscode = "AC1000";
        List<nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity> registraties = registratieDAO.findRegistratiesByActiveringsCode(activeringscode);
        System.out.println("total:"+registraties.size());
        for(nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity obj : registraties){
            System.out.println(obj.getKenteken());
        }
        
    }
    
    //@Test
    public void ophalenActiveRegistratie() throws BezoekersparkerenException{
        nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity registratieEntity = registratieDAO.findById(44807L);
        System.out.println("kenteken: "+registratieEntity.getKenteken());
    }
    //@Test
    public void registrerenbezoekersRechtTest() throws BezoekersparkerenException {
        
        Recht recht = new Recht();
        recht.setBsn(new Long("21"));
        recht.setEmail("email@resr.com");
        recht.setIban("123232323");
        recht.setAkkoordAlgVoorwaarden("ja");
        recht.setAkkoordIncasso("ja");
       Long result =  rechtServiceImpl.registrerenBezoekersrecht(recht);
       
       System.out.println("result:"+result);
    }
    //@Test
    public void afmeldenTest() throws BezoekersparkerenException {
         
        Registratie registratie = new Registratie();  
        registratie.setActiveringscode("AC1000");
        registratie.setId(new Long("47759"));
        Assert.assertEquals("success", registratieServiceImpl.afmeldenKenteken(registratie));
    }
    
    
}
