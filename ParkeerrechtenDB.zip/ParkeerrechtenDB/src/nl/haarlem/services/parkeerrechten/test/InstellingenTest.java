package nl.haarlem.services.parkeerrechten.test;

import java.util.List;

import nl.haarlem.services.parkeerrechten.dao.impl.InstellingenEntityDAOImpl;

import nl.haarlem.services.parkeerrechten.dao.impl.RechtEntityDAOImpl;

import nl.haarlem.services.parkeerrechten.jpa.InstellingenEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class InstellingenTest extends JPAtTest {

    private InstellingenEntityDAOImpl instellingenDao = new InstellingenEntityDAOImpl();
    private RechtEntityDAOImpl rechtEntityDao = new RechtEntityDAOImpl();


    @Before
    public void initializeEM() {
        instellingenDao.setEm(em);
    }

//@Test
    public void findInstellingByRechtAndKey() {

        String key = "Email_Notification";
        String aanmeldcode = "AC1000";
        RechtEntity rechtEntity = rechtEntityDao.findByAanmeldcode(aanmeldcode);
        InstellingenEntity instellingen = instellingenDao.findInstellingEntityByRechtAndKey(rechtEntity, key);
        System.out.println("date:"+instellingen.getDatumcheck());
        Assert.assertNotNull(instellingen);
    }
    
    @Test
    public void findInstellingenEntityByRecht(){
        String aanmeldcode = "AC1000";
        RechtEntity rechtEntity = rechtEntityDao.findByAanmeldcode(aanmeldcode);
        System.out.println("recht id: "+rechtEntity.getIban());
        List<InstellingenEntity> instellingenEntities = instellingenDao.findInstellingenEntityByRecht(rechtEntity);
        System.out.println("total gevonden instelling: "+instellingenEntities.size());
        Assert.assertEquals(2, instellingenEntities.size());

        
    }
}
