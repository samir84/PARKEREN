package nl.haarlem.services.parkeerrechten.test;

import nl.haarlem.services.parkeerrechten.dao.impl.InstellingenEntityDAOImpl;

import nl.haarlem.services.parkeerrechten.dao.impl.RechtEntityDAOImpl;

import nl.haarlem.services.parkeerrechten.jpa.InstellingenEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class InstellingenTest extends JPAtTest {

    private InstellingenEntityDAOImpl instellingenDao = new InstellingenEntityDAOImpl();
    private RechtEntityDAOImpl rechtEntityDao = new RechtEntityDAOImpl();


    @Before
    public void initializeEM() {
        instellingenDao.setEm(em);
    }

// @Test
    public void findInstellingByRechtAndKey() {

        String key = "Email_Notification";
        String activeringscode = "AC1000";
        RechtEntity rechtEntity = rechtEntityDao.findByActiveringscode(activeringscode);
        InstellingenEntity instellingen = instellingenDao.findInstellingEntityByRechtAndKey(rechtEntity, key);
        System.out.println("date:"+instellingen.getDatumcheck());
        Assert.assertNotNull(instellingen);
    }
}
