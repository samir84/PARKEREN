package nl.haarlem.services.parkeerrechten.test;

import java.io.FileNotFoundException;

import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;

import javax.persistence.Persistence;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

import weblogic.ejbgen.Session;

public class JPAtTest {

    protected static EntityManagerFactory emf;
    protected static EntityManager em;

    @BeforeClass
    public static void init() throws FileNotFoundException {
        emf = Persistence.createEntityManagerFactory("ParkeerrechtenDB-test");
        em = emf.createEntityManager();
    }


    @AfterClass
    public static void tearDown() {
        em.clear();
        em.close();
        emf.close();
    }
}
