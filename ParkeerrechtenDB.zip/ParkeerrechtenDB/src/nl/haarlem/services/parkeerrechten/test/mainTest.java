package nl.haarlem.services.parkeerrechten.test;

import java.util.Calendar;

public class mainTest {
    public static void main(String args[]){
        
        Calendar calendarBegintime = Calendar.getInstance();
        calendarBegintime.set(2017, 6, 6, 3, 10, 0);
        Calendar calendarEndtime = Calendar.getInstance();
        calendarEndtime.set(2017, 6, 6, 3, 12, 0);
        long diffMinutes = (calendarEndtime.getTimeInMillis() - calendarBegintime.getTimeInMillis() ) / (60 * 1000) % 60; 
        System.out.println("difference: "+diffMinutes);
    }
}
