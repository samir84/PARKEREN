package nl.haarlem.services.parkeerrechten.test;

import java.sql.Timestamp;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;

import java.util.Date;
import java.util.List;
import java.util.Locale;


import java.util.UUID;

import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtTypeEntity;
import nl.haarlem.services.parkeerrechten.model.Bestedingsruimte;
import nl.haarlem.services.parkeerrechten.model.Parkeerkosten;
import nl.haarlem.services.parkeerrechten.util.AppHelper;

import nl.haarlem.services.parkeerrechten.util.DateTimeHelper;

import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

public class mainTest {
    public static void main(String args[]) throws ParseException {
        
        /*Calendar calendarBegintime = Calendar.getInstance();
        calendarBegintime.set(2017, 6, 6, 3, 10, 0);
        Calendar calendarEndtime = Calendar.getInstance();
        calendarEndtime.set(2017, 6, 6, 3, 12, 0);
        long diffMinutes = (calendarEndtime.getTimeInMillis() - calendarBegintime.getTimeInMillis() ) / (60 * 1000) % 60; 
        System.out.println("difference: "+diffMinutes);*/
        
        /*Parkeerkosten parkeerkosten = new Parkeerkosten();
        Calendar calBeginTijd = Calendar.getInstance();
        String customFormat = "yyyy-MM-dd'T'HH:mm:ss";
        SimpleDateFormat sdf = new SimpleDateFormat(customFormat);
        calBeginTijd.setTime(sdf.parse("2017-06-28T10:01:00"));// all done
        System.out.println("calBeginTijd: "+calBeginTijd.getTime());
        Calendar calEndTijd = Calendar.getInstance();
        calEndTijd.setTime(sdf.parse("2017-06-28T10:02:55"));// all done
        System.out.println("calEndTijd: "+calEndTijd.getTime());
        parkeerkosten.setBegintijd(calBeginTijd);
        parkeerkosten.setEindtijd(calEndTijd);
        parkeerkosten.setZone("C");
        
        System.out.println("berekenParkeerkosten: "+berekenParkeerkosten(parkeerkosten));
*/
        //test();
       // String regex0="^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-(8|9|a|b)[a-f0-9]{3}-[a-f0-9]{12}";
      //  String regex1="/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i";
      //  String regex2 ="38400000-8cf0-11bd-b23e-10b96e4ef00d";
        
        
        for(int i=0; i < 1000; i++){
            UUID uuid = UUID.randomUUID();
            String str = uuid.toString();
            //System.out.println("test:"+str);
            if (str.matches("/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i")) {
                System.out.println("found match:"+str);
            }
        }
       
    }
    
    public static Bestedingsruimte ophalenBestedingsruimte(String aanmeldcode) throws BezoekersparkerenException {
         
         
        Float limiet = new Float(0.00);
        double verbruik = 0;
        Bestedingsruimte bestedingsruimte = new Bestedingsruimte();

        RechtEntity rechtEntity = new RechtEntity();
        rechtEntity.setAanmeldcode(aanmeldcode);   
        List<RechtTypeEntity> rechtTypeLijst = new ArrayList<RechtTypeEntity>();
        
        RechtTypeEntity gebruiker = new RechtTypeEntity();
        gebruiker.setNaam("BEZOEKER");
        gebruiker.setBegindatum(new Timestamp(new Date().getTime()));

        rechtTypeLijst.add(gebruiker);
        
        rechtEntity.setRechtTypeList(rechtTypeLijst);
            
            
        if (rechtEntity == null) {
            throw new BezoekersparkerenException("error", "Geen bezoekers recht gevonden voor aanmeldcode: " + aanmeldcode);
        }

        for (int j = 0; j < rechtTypeLijst.size(); j++) {
            
            RechtTypeEntity rechtType = (RechtTypeEntity)rechtTypeLijst.get(j);
            limiet =limiet + AppHelper.getInstance().CalculateBestedingsLimit(rechtType.getNaam(),rechtType.getBegindatum());
            System.out.println("limiet:"+limiet); 

        }

        Double totalBedragByJaar =  30.0;
        verbruik = totalBedragByJaar;
        
        double ruimte =  AppHelper.getInstance().roundTwoDecimal(limiet - verbruik);
        double roundlimiet = AppHelper.getInstance().roundTwoDecimal(limiet);
        verbruik = AppHelper.getInstance().roundTwoDecimal(verbruik);
        
        bestedingsruimte.setLimiet(roundlimiet);
        bestedingsruimte.setRuimte(ruimte);
        bestedingsruimte.setVerbruik(verbruik);


        return bestedingsruimte;
    }
    public static Float berekenParkeerkosten(Parkeerkosten parkeerkosten) {
            
            Float f_parkingcosts = new Float(0.0);
            int i_parkingcosts = 0;
            int unitprice = 3;
            Calendar calendarBeginTijd;
            Calendar calendarEndtime;
            // Set the time block in minutes (TODO TODO TODO: get it from the Business Rule)
            int timeBlock = 15;
            // Set the starttime
            calendarBeginTijd = parkeerkosten.getBegintijd();
            // Set the endtime to compare with
            calendarEndtime = parkeerkosten.getEindtijd();
            
            boolean is2min = DateTimeHelper.getInstance().checkDifferenceBeginTimeEndTimeIs2min(calendarBeginTijd, calendarEndtime);
                if(is2min){
                    return f_parkingcosts;
                }
            // Compare the parkingtime with the endtime and add 15 minutes each time it's before the endtime
            while (calendarBeginTijd.compareTo(calendarEndtime) == -1) {
                // Add parkingcosts according to the Business Rule (TODO TODO TODO: get it from the Business Rule)
                    int hour = calendarBeginTijd.get(Calendar.HOUR_OF_DAY);
                    int blockprice = 0;
                    if (hour >= 9 && hour < 18) {
                        blockprice = unitprice;
                    }
                    if (hour >= 18 && hour < 23) {
                        blockprice = unitprice * 2;
                    }
                    i_parkingcosts += blockprice;
                    // Add a timeBlock to the parkingtime
                    calendarBeginTijd.add(Calendar.MINUTE, timeBlock); 
                
            }
            f_parkingcosts = ((float)i_parkingcosts / 100);
            return f_parkingcosts;
        }
    public static double round(double value, int digits) {
        double scale = Math.pow(10, digits);
        return Math.round(value * scale) / scale;
    }
    public static void test() {
            double d = 18.5;
            int r = (int) Math.round(d*100);
            double f = r / 100.0;
           System.out.println(f);
         }
    
}
