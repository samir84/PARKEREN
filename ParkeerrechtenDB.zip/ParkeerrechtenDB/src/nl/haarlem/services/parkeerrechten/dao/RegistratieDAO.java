package nl.haarlem.services.parkeerrechten.dao;

import java.sql.Timestamp;

import java.util.List;

import javax.ejb.Local;

import javax.jws.WebParam;

import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity;
import nl.haarlem.services.parkeerrechten.model.Registratie;

@Local
public interface RegistratieDAO {

    public RegistratieEntity findById(Long id);
    
    public RegistratieEntity findActiveById(Long id);

    public List<RegistratieEntity> findAll();

    public List<RegistratieEntity> findValidByRecht(RechtEntity recht);

    public List<RegistratieEntity> findValidByRechtHistorie(RechtEntity recht);


    public RegistratieEntity findActieveRegistratieById(Long id);

    public List<RegistratieEntity> findRegistratiesHuidigJaar(RechtEntity recht);
    
    public Double findTotalBedragByJaar(RechtEntity recht);
   
    public Registratie ophalenActieveRegistratie(Registratie registratie) throws BezoekersparkerenException;;
    
    public Long aanmeldenKenteken(Registratie registratie,RechtEntity rechtEntity);
    
    public List<RegistratieEntity> findRegistratiesByActiveringsCode(String activeringscode) throws BezoekersparkerenException;

    public void merge(RegistratieEntity registratieEntity);

    public void remove(RegistratieEntity registratieEntity);
    
    public List<RegistratieEntity> findGeregistreerdeRegistraties(RechtEntity rechtEntity,String kenteken , Timestamp begingTijd, Timestamp EindTijd);

    public List<RegistratieEntity> findActieveRegistratieByKenteken(String string,
                                                                    RechtEntity rechtEntity);
}
