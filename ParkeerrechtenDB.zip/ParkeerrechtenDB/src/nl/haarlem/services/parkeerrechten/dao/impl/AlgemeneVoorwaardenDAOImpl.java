package nl.haarlem.services.parkeerrechten.dao.impl;

import java.util.Calendar;

import javax.ejb.Stateless;

import java.util.logging.Logger;

import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import nl.haarlem.services.parkeerrechten.dao.AlgemeneVoorwaardenDAO;
import nl.haarlem.services.parkeerrechten.jpa.AlgemeneVoorwaardenEntity;
//import nl.haarlem.services.parkeerrechten.jpa.AlgemeneVoorwaardenPK;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.model.Recht;

@Stateless
public class AlgemeneVoorwaardenDAOImpl implements AlgemeneVoorwaardenDAO {

    private Logger log =
        Logger.getLogger(AlgemeneVoorwaardenDAOImpl.class.getName());

    @PersistenceContext(unitName = "ParkeerrechtenDB")
    private EntityManager em;

    public void createAlgemeneVoorwaarden(AlgemeneVoorwaardenEntity algVoorwrd) {
        log.info("Create AlgemeneVoorwaarden for the right id " +
                 algVoorwrd.getRecht().getId());
        em.persist(algVoorwrd);
    }
}
