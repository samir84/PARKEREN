package nl.haarlem.services.parkeerrechten.dao.impl;

import java.util.Collections;
import java.util.List;

import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;

import nl.haarlem.services.parkeerrechten.dao.ParkeerzoneDAO;
import nl.haarlem.services.parkeerrechten.jpa.Parkeerzone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class ParkeerzoneDAOImpl implements ParkeerzoneDAO{

    private Logger log = LoggerFactory.getLogger(ParkeerzoneDAOImpl.class.getName());

    @PersistenceContext(unitName = "ParkeerrechtenDB")
    private EntityManager em;

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public EntityManager getEm() {
        return em;
    }


    public List<Parkeerzone> findAllParkeerzones() {
            log.info("Parkeerzone.findAll..");
            List<Parkeerzone> pakeerzones = null;
            Query query = em.createNamedQuery("Parkeerzone.findAll");
            if (query.getResultList() != null &&
                query.getResultList().size() > 0) {
                pakeerzones = (List<Parkeerzone>)query.getResultList();
            }
            return pakeerzones;
    }
}
