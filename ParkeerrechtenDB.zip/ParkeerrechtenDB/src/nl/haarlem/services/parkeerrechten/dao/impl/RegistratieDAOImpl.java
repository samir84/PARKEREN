package nl.haarlem.services.parkeerrechten.dao.impl;

import java.sql.Timestamp;

import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;

import javax.jws.WebMethod;
import javax.jws.WebParam;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;

import nl.haarlem.services.parkeerrechten.dao.RegistratieDAO;
import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity;
import nl.haarlem.services.parkeerrechten.model.Registratie;

import org.eclipse.persistence.internal.jpa.EJBQueryImpl;
import org.eclipse.persistence.jpa.JpaEntityManager;
import org.eclipse.persistence.queries.DatabaseQuery;
import org.eclipse.persistence.sessions.DatabaseRecord;
import org.eclipse.persistence.sessions.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class RegistratieDAOImpl implements RegistratieDAO {

    private Logger log = LoggerFactory.getLogger(RegistratieDAOImpl.class.getName());

    @PersistenceContext(unitName = "ParkeerrechtenDB")
    private EntityManager em;

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public EntityManager getEm() {
        return em;
    }


    public RegistratieEntity findById(Long id) {
        return em.find(RegistratieEntity.class, id);
    }

    public List<RegistratieEntity> findAll() {
        log.info("Registratie.findAll..");
        List<RegistratieEntity> registraties = null;
        Query query = em.createNamedQuery("Registratie.findAll");
        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            registraties = (List<RegistratieEntity>)query.getResultList();
        }
        return registraties;
    }


    public List<RegistratieEntity> ophalenRegstratiesHistorieHuidigeJaar(RechtEntity rechtEntity) {

        log.info("ophalenRegstratiesHistorieHuidigeJaar..");
        List<RegistratieEntity> registraties = null;
        Query query = em.createNamedQuery("Registratie.findHistorieHuidigeJaar");
        query.setParameter("p_recht", rechtEntity);
        
        Calendar calendar = Calendar.getInstance();
        calendar.set(calendar.get(Calendar.YEAR), 0, 1, 0, 0, 0);
        query.setParameter("p_huidigeJaar",new Timestamp(calendar.getTimeInMillis()));

        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            registraties = (List<RegistratieEntity>)query.getResultList();
        }

        return registraties;
    }

    public List<RegistratieEntity> findActieveRegistratieByKenteken(String kenteken,
                                                                    RechtEntity rechtEntity) {

        List<RegistratieEntity> registratieList = null;
        Query query =
            em.createNamedQuery("Registratie.findActieveRegistratieByKenteken");
        query.setParameter("p_kenteken", kenteken);
        query.setParameter("p_recht", rechtEntity);

        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {

            registratieList = query.getResultList();
        }

        return registratieList;
    }


    public Double findTotalBedragByHuidigeJaar(RechtEntity recht) {

        Double TotalBedrag = new Double("0.00");
        Query query = em.createNamedQuery("Registratie.findTotalBedragByHuidigeJaar");
        query.setParameter("p_recht", recht);
        Calendar calendar = Calendar.getInstance();
        calendar.set(calendar.get(Calendar.YEAR), 0, 1, 0, 0, 0);
        query.setParameter("p_huidigeJaar",new Timestamp(calendar.getTimeInMillis()));
        if (query.getSingleResult() != null) {
            TotalBedrag = (Double)query.getSingleResult();
        }


        return TotalBedrag;
    }

    public Registratie ophalenActieveRegistratie(@WebParam(name =
                                                           "registratie")
        Registratie registratie) throws BezoekersparkerenException {

        Calendar calendar = Calendar.getInstance();

            Query query = em.createNamedQuery("Registratie.findActieveRegistratieById");
            query.setParameter("p_id", registratie.getId());
            query.setParameter("p_huidigeTijd", new Timestamp(calendar.getTimeInMillis()));
            //RegistratieEntity registratieEntity = (RegistratieEntity)query.getSingleResult();
            
            if (query.getResultList() != null &&
                    query.getResultList().size() > 0) {
                    RegistratieEntity registratieEntity = (RegistratieEntity)query.getResultList().get(0);
                    
                    registratie.setId(registratieEntity.getId());
                    registratie.setAanmeldcode(registratieEntity.getRecht().getAanmeldcode());
                    registratie.setKenteken(registratieEntity.getKenteken());
                    registratie.setBedrag(registratieEntity.getBedrag());
                    registratie.setBron(registratieEntity.getBron());
                    Calendar beginT = Calendar.getInstance();
                    beginT.setTimeInMillis(registratieEntity.getBegintijd().getTime());
                    registratie.setBegintijd(beginT);
                    registratie.setZone(registratieEntity.getRecht().getZone());
                    if (registratieEntity.getEindtijd() != null) {
                        Calendar eindT = Calendar.getInstance();
                        eindT.setTimeInMillis(registratieEntity.getEindtijd().getTime());
                        registratie.setEindtijd(eindT);
                    }
                } else {
                    log.info("Geen active registratie gevonden met id: "+registratie.getId());
                    return null;
                }
            


        return registratie;
    }

    public Long aanmeldenKenteken(Registratie registratie,
                                  RechtEntity rechtEntity) {

        log.debug("aanmeldenKenteken: " + registratie.getKenteken());
        RegistratieEntity registratieEntity = new RegistratieEntity();
        registratieEntity.setRecht(rechtEntity);
        registratieEntity.setKenteken(registratie.getKenteken());
        registratieEntity.setBron(registratie.getBron());
        if (registratie.getBegintijd() != null) {
            registratieEntity.setBegintijd(new Timestamp(registratie.getBegintijd().getTimeInMillis()));
        } else {
            registratieEntity.setBegintijd(new Timestamp(Calendar.getInstance().getTimeInMillis()));
        }
        if (registratie.getEindtijd() != null) {
            registratieEntity.setEindtijd(new Timestamp(registratie.getEindtijd().getTimeInMillis()));
        }
        if (registratie.getBedrag() != null) {
            registratieEntity.setBedrag(registratie.getBedrag());
        }
        em.persist(registratieEntity);
        log.debug("Kenteken : " + registratie.getKenteken() +
                  " is met succes aangemeld return id is: " +
                  registratieEntity.getId() + " Time: " +
                  System.currentTimeMillis());

        return registratieEntity.getId();
    }


    public List<RegistratieEntity> findRegistratiesByAanmeldcode(String Aanmeldcode) throws BezoekersparkerenException {
        RechtEntity rechtEntity = null;
        List<RegistratieEntity> registraties = null;
        Calendar calendar = Calendar.getInstance();
        try {
            Date now = new Date();
            rechtEntity =
                    (RechtEntity)em.createNamedQuery("Recht.findByAanmeldcode").setParameter("p_aanmeldcode",
                                                                                                 Aanmeldcode).setParameter("p_huidigeTijd", now).getResultList().get(0);
        } catch (Exception e) {
            throw new BezoekersparkerenException("error",
                                                "Geen bezoekers recht gevonden met Aanmeldcode: " +
                                                Aanmeldcode);
        }
        Query query = em.createNamedQuery("Registratie.findActiveRegistraties");
        query.setParameter("p_recht", rechtEntity);
        query.setParameter("p_huidigeTijd", new Timestamp(calendar.getTimeInMillis()));

        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {

            registraties = (List<RegistratieEntity>)query.getResultList();
        }
        return registraties;
    }

    public void merge(RegistratieEntity registratieEntity) {
        em.merge(registratieEntity);
    }

    public void remove(RegistratieEntity registratieEntity) {
        em.remove(registratieEntity);
    }

    public List<RegistratieEntity> findGeregistreerdeRegistraties(RechtEntity rechtEntity,
                                                                  String kenteken,
                                                                  Timestamp begingTijd,
                                                                  Timestamp EindTijd) {

        List<RegistratieEntity> registratieEntityList = null;
        Query query =
            em.createNamedQuery("Registratie.findGeregistreerdeRegistraties");
        query.setParameter("p_recht", rechtEntity);
        query.setParameter("p_kenteken", kenteken);
        query.setParameter("p_begintijd", begingTijd);
        query.setParameter("p_eindtijd", EindTijd);

        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            registratieEntityList =
                    (List<RegistratieEntity>)query.getResultList();
        }
        return registratieEntityList;
    }


    public RegistratieEntity findActieveRegistratieById(Long id) {

        Calendar calendar = Calendar.getInstance();
        Query query =
            em.createNamedQuery("Registratie.findActieveRegistratieById");
        query.setParameter("p_huidigeTijd",
                           new Timestamp(calendar.getTimeInMillis()));
        query.setParameter("p_id", id);

        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            return (RegistratieEntity)query.getResultList().get(0);
        } else {
            return null;
        }


    }

    public RegistratieEntity findActiveById(Long id) {

        RegistratieEntity registratieEntity = null;
        try {
            Calendar calendar = Calendar.getInstance();
            Query query = em.createNamedQuery("Registratie.findActiveById");
            query.setParameter("p_id", id);
            query.setParameter("p_huidigeTijd",
                               new Timestamp(calendar.getTimeInMillis()));

            registratieEntity =
                    (RegistratieEntity)query.getResultList().get(0);

            if (registratieEntity == null) {
                throw new BezoekersparkerenException("error",
                                                    "Geen registratie gevonden met id: " +
                                                    id);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return registratieEntity;
    }


    public List<RegistratieEntity> ophalenRegstratiesHistorieByJaar(RechtEntity recht,
                                                                    int year) {
        return Collections.emptyList();
    }
}
