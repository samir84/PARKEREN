package nl.haarlem.services.parkeerrechten.dao;

import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtTypeEntity;
import nl.haarlem.services.parkeerrechten.model.RechtType;

@Local
public interface RechtTypeDAO {

    List<RechtTypeEntity> findAll();

    void createRechtType(RechtTypeEntity rechtType);

    List<RechtTypeEntity> findByRechtID(RechtEntity recht);
}
