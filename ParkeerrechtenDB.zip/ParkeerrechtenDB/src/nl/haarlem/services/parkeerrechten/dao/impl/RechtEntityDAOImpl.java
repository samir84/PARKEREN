package nl.haarlem.services.parkeerrechten.dao.impl;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;

import nl.haarlem.services.parkeerrechten.dao.RechtEntityDAO;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtTypeEntity;

import nl.haarlem.services.parkeerrechten.model.Recht;
import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;


import nl.haarlem.services.parkeerrechten.util.AppHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class RechtEntityDAOImpl implements RechtEntityDAO {

    private Logger log =
        LoggerFactory.getLogger(RechtTypeDAOImpl.class.getName());

    @PersistenceContext(unitName = "ParkeerrechtenDB")
    private EntityManager em;
    
    public void setEm(EntityManager em) {
        this.em = em;
    }
    public EntityManager getEm() {
        return em;
    }
    
    public boolean isActiveringscodeExist(String activeringscode) {
        boolean exist = false;

        log.debug("Recht.findByActiveringscode: " + activeringscode);
        List<RechtEntity> rechtEntities = new ArrayList<RechtEntity>();
        try {
            rechtEntities =
                    em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode",
                                                                                    activeringscode).getResultList();

            if (rechtEntities == null) {
                //throw new BezoekersparkerenException("error","Bezoerkersparkeerrecht niet gevonden for  " +activeringscode);
                exist = false;
            }
            if (rechtEntities.size() > 0) {
                exist = true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return exist;
    }


    public RechtEntity findByActiveringscode(String activeringscode){

        RechtEntity rechtEntity = null;
        try {
            Query query = em.createNamedQuery("Recht.findByActiveringscode");
            query.setParameter("p_activeringscode",activeringscode);
            Date now = new Date();
            //query.setParameter("p_einddatum",now);
            
            List<RechtEntity> rechtEntityList = (List<RechtEntity>) query.getResultList();
            
            if(rechtEntityList != null && rechtEntityList.size() > 0){
                rechtEntity = rechtEntityList.get(0);
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return rechtEntity;
    }

    /**
     *
     * @param email and bank number
     * @return
     */
    public String updateRecht(RechtEntity oldRechtEntity) {
        String succes = "error";
        log.debug("updateRecht..");

        try {
            em.merge(oldRechtEntity);
            RechtEntity newRechtEntity =
                findByActiveringscode(oldRechtEntity.getActiveringscode());

            if (newRechtEntity.getEmail().equals(oldRechtEntity.getEmail()) &&
                newRechtEntity.getIban().equals(oldRechtEntity.getIban())) {
                succes = "succes";
            } else {
                succes =
                        "Bezoekers recht is niet gewijzigd door enn internal error!";
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }


        return succes;
    }


    public String opzeggenRecht(String activeringscode) throws BezoekersparkerenException{
        String succes = null;
           //opzeggen query
           RechtEntity oldRechtEntity = findByActiveringscode(activeringscode);
            if(oldRechtEntity == null){
                throw new BezoekersparkerenException("error","Geen Bezoekers recht gevonden met activeringscode: "+activeringscode);
            }
            Timestamp now = new Timestamp(new Date().getTime());
            oldRechtEntity.setEinddatum(now);
            em.merge(oldRechtEntity);
            RechtEntity newRechtEntity = findByActiveringscode(activeringscode);

            if (newRechtEntity.getEinddatum().equals(now)) {
                succes = "succes";
            } else {
                throw new BezoekersparkerenException( "error", "Bezoekers recht is niet gewijzigd door enn internal error!");
            }
    
        return succes;
    }

    public RechtEntity ophalenBezoekersrechtByBSN(String bsn) {
       
        RechtEntity rechtEntity = null;
        Query query = em.createNamedQuery("Recht.findByBSN");
        query.setParameter("p_bsn",bsn);
        Date now = new Date();
       // query.setParameter("p_einddatum",now);
        List<RechtEntity> rechtEntityList = (List<RechtEntity>) query.getResultList();
        
        if(rechtEntityList != null && rechtEntityList.size() > 0){
            rechtEntity = rechtEntityList.get(0);
        }
            return rechtEntity;
    }

    public RechtEntity ophalenBezoekersrechtByActiveringscode(String activeringscode)  {
        
        RechtEntity rechtEntity = null;
        Query query = em.createNamedQuery("Recht.findByActiveringscode");
        query.setParameter("p_activeringscode",activeringscode);
        Date now = new Date();
      //  query.setParameter("p_einddatum",now);
        
        List<RechtEntity> rechtEntityList = (List<RechtEntity>) query.getResultList();
        if(rechtEntityList != null && rechtEntityList.size() > 0){
            rechtEntity =  rechtEntityList.get(0);
        }
        
        return rechtEntity;
    }

    public boolean checkBezoekersrechtByBSN(String bsn) throws BezoekersparkerenException{
        
        boolean exist = false;
        
        Query query = em.createNamedQuery("Recht.findByBSN");
        query.setParameter("p_bsn",bsn);
        Date now = new Date();
        //query.setParameter("p_einddatum",now);
        
        List<RechtEntity> rechtEntityList = (List<RechtEntity>) query.getResultList();
        if(rechtEntityList!= null & rechtEntityList.size() > 1){
            exist = true;
            throw new BezoekersparkerenException("error","Er mag maar 1 recht per bezoeker!");
        }else if(rechtEntityList!= null && rechtEntityList.size() == 1){
            exist = true;
        }
        return exist;
    }

    public void createRecht(RechtEntity rechtEntity) {
        em.persist(rechtEntity);
    }

    public RechtEntity findById(Long id) {
        return em.find(RechtEntity.class, id);
    }


    public void merge(RechtEntity rechtEntity) {
        em.merge(rechtEntity);
    }
}
