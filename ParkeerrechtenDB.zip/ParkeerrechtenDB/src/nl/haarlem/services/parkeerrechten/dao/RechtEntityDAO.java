package nl.haarlem.services.parkeerrechten.dao;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.model.Recht;
import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;

@Local
public interface RechtEntityDAO {

    public RechtEntity findById(Long id);
    public RechtEntity findByActiveringscode(String activeringscode);
    public RechtEntity ophalenBezoekersrechtByBSN(String bsn);
    public boolean isActiveringscodeExist(String activeringscode) throws BezoekersparkerenException ;
    public String updateRecht(RechtEntity oldRechtEntity);
    public String opzeggenRecht(String activeringscode)throws  BezoekersparkerenException;

    public RechtEntity ophalenBezoekersrechtByActiveringscode(String activeringscode) throws  BezoekersparkerenException;
    public boolean checkBezoekersrechtByBSN(String String) throws  BezoekersparkerenException;

    public void createRecht(RechtEntity rechtEntity);

    public void merge(RechtEntity rechtEntity);
}
