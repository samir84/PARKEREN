package nl.haarlem.services.parkeerrechten.dao;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.model.Recht;
import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;

@Local
public interface RechtEntityDAO {

    public RechtEntity findById(Long id);
    public RechtEntity findByAanmeldcode(String aanmeldcode);
    public RechtEntity ophalenBezoekersrechtByBSN(String bsn)throws  BezoekersparkerenException;
    public boolean isAanmeldcode(String aanmeldcode) throws BezoekersparkerenException ;
    public String updateRecht(RechtEntity oldRechtEntity);
    public String opzeggenRecht(String aanmeldcode)throws  BezoekersparkerenException;

    public RechtEntity ophalenBezoekersrechtByAanmeldcode(String aanmeldcode) throws  BezoekersparkerenException;
    public boolean checkBezoekersrechtByBSN(String String) throws  BezoekersparkerenException;

    public void createRecht(RechtEntity rechtEntity);

    public void merge(RechtEntity rechtEntity);

    public RechtEntity ophalenRechtByNummerAanduiding(String nummerAanduiding) throws BezoekersparkerenException;

    public boolean verwijderRecht(String bsn);
}
