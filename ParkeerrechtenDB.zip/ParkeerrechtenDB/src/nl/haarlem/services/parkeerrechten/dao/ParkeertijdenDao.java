package nl.haarlem.services.parkeerrechten.dao;

import java.sql.Timestamp;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;

@Local
public interface ParkeertijdenDao {
    
    List<Parkeertijden> findAll();
    
    List<Parkeertijden> findByParkeerzone(String parkeerzone);
    List<Parkeertijden> findByParkeerzoneEnTijdsVenster(String parkeerzone,Timestamp begintijd, Timestamp eindtijd);
    List<Parkeertijden> findByTijdsVenster(Timestamp begintijd, Timestamp eindtijd);
    Parkeertijden findByDatum(Timestamp begintijd);

    public List<Parkeertijden> findByDay(Date date);
    
    public List<Parkeertijden> findByDayAndParkeerzone(Date date,String parkeerzone);
}
