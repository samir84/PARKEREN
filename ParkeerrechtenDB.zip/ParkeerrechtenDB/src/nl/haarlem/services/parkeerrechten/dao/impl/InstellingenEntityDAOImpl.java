package nl.haarlem.services.parkeerrechten.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;

import nl.haarlem.services.parkeerrechten.dao.InstellingenEntityDAO;
import nl.haarlem.services.parkeerrechten.jpa.InstellingenEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;


import nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class InstellingenEntityDAOImpl implements InstellingenEntityDAO{


    private Logger log = LoggerFactory.getLogger(InstellingenEntityDAOImpl.class.getName());

    @PersistenceContext(unitName = "ParkeerrechtenDB")
    private EntityManager em;
    
    public void setEm(EntityManager em) {
        this.em = em;
    }
    public EntityManager getEm() {
        return em;
    }
    
    
    
    public List<InstellingenEntity> findInstellingenEntityByRecht(RechtEntity recht) {
        
        log.debug("InstellingenEntity.findInstellingenEntityByRecht: " + recht.getId());
        List<InstellingenEntity> intsellingen = null;
        try {
             Query query = em.createNamedQuery("InstellingenEntity.findInstellingenEntityByRecht");
             query.setParameter("p_recht",recht);
            if(query.getResultList() != null && query.getResultList().size() > 0){
                intsellingen = (List<InstellingenEntity>)query.getResultList();
            }
           
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        return intsellingen;
    }

    public void createInstellingenEntity(InstellingenEntity instelling) {
        em.persist(instelling);
    }


    public void updateInstellingEntity(InstellingenEntity instelling) {
        log.info("update instelling by kye : "+instelling.getKey() +" value: "+instelling.getValue());
        em.merge(instelling);
    }

    public InstellingenEntity findInstellingEntityByRechtAndKey(RechtEntity rechtEntity , String key) {
        log.debug("InstellingenEntity.findInstellingByRechtAndKey: " + rechtEntity.getId());
        List<InstellingenEntity> intsellingen = null;
             Query query = em.createNamedQuery("InstellingenEntity.findInstellingByRechtAndKey");
             query.setParameter("p_recht",rechtEntity);
            query.setParameter("p_key",key);

            return (InstellingenEntity) query.getSingleResult();
    }


}
