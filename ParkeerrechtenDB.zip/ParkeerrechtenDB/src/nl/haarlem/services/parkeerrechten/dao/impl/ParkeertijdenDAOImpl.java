package nl.haarlem.services.parkeerrechten.dao.impl;

import java.lang.reflect.Field;

import java.lang.reflect.Method;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import javax.persistence.criteria.Root;

import nl.haarlem.services.parkeerrechten.dao.ParkeertijdenDao;
import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;


import org.python.parser.ast.Break;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class ParkeertijdenDAOImpl implements ParkeertijdenDao{
   
    private Logger log = LoggerFactory.getLogger(ParkeertijdenDAOImpl.class.getName());

    @PersistenceContext(unitName = "ParkeerrechtenDB")
    private EntityManager em;

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public EntityManager getEm() {
        return em;
    }


    public List<Parkeertijden> findAll() {
        log.info("Parkeertijden.findAll..");
        List<Parkeertijden> parkeertijden = null;
        Query query = em.createNamedQuery("Parkeertijden.findAll");
        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            parkeertijden = (List<Parkeertijden>)query.getResultList();
        }
        return parkeertijden;
    }

    public List<Parkeertijden> findByParkeerzone(String parkeerzone) {
        
        log.info("Parkeertijden.findByParkeerzone..");
        List<Parkeertijden> parkeertijden = null;
        Query query = em.createNamedQuery("Parkeertijden.findByParkeerzone");
        query.setParameter("p_parkeerzone", parkeerzone);
        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            parkeertijden = (List<Parkeertijden>)query.getResultList();
        }
        return parkeertijden;
    }

    public List<Parkeertijden> findByParkeerzoneEnTijdsVenster(String parkeerzone,
                                                               Timestamp begintijd,
                                                               Timestamp eindtijd) {
        log.info("Parkeertijden.findByParkeerzoneEnTijdsVenster..");
        List<Parkeertijden> parkeertijden = null;
        Query query = em.createNamedQuery("Parkeertijden.findByParkeerzoneEnTijdsVenster");
        query.setParameter("p_parkeerzone", parkeerzone);
        query.setParameter("p_begintijd", begintijd);
        query.setParameter("p_eindtijd", eindtijd);
        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            parkeertijden = (List<Parkeertijden>)query.getResultList();
        }
        return parkeertijden;
    }

    public List<Parkeertijden> findByTijdsVenster(Timestamp begintijd,
                                                  Timestamp eindtijd) {
        log.info("Parkeertijden.findByTijdsVenster..");
        List<Parkeertijden> parkeertijden = null;
        Query query = em.createNamedQuery("Parkeertijden.findByTijdsVenster");
        query.setParameter("p_begintijd", begintijd);
        query.setParameter("p_eindtijd", eindtijd);
        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            parkeertijden = (List<Parkeertijden>)query.getResultList();
        }
        return parkeertijden;
    }

    public Parkeertijden findByDatum(Timestamp datum) {
        log.info("Parkeertijden.findByTijdsVenster..");
        Parkeertijden parkeertijden = null;
        Query query = em.createNamedQuery("Parkeertijden.findByTijdsVenster");
        
        Calendar beginCal = Calendar.getInstance();
        beginCal.set(beginCal.get(Calendar.YEAR), 0, 1, 0, 0, 0);
        
        Calendar eindCal = Calendar.getInstance();
        eindCal.set(eindCal.get(Calendar.YEAR), 0, 1, 23, 59, 0);
        
        query.setParameter("p_begintijd", new Timestamp(beginCal.getTimeInMillis()));
        query.setParameter("p_eindtijd", new Timestamp(eindCal.getTimeInMillis()));
        
        if (query.getResultList() != null &&
            query.getResultList().size() > 0) {
            parkeertijden = (Parkeertijden)query.getResultList().get(0);
        }
        return parkeertijden;
    }

    

    public List<Parkeertijden> findByDayAndParkeerzone(Date date,String parkeerzone) {
        log.info("Parkeertijden.findByDayAndParkeerzone..");
    
        
        List<Parkeertijden> parkeertijdenList = null;
        String dagnaam = null;
        String[] dagen = {"zondag", "maandag","dinsdag","woensdag","donderdag","vrijdag","zaterdag"};
        try{
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH);
            int day = cal.get(Calendar.DAY_OF_WEEK);
            dagnaam = dagen[day-1];
           
           
            String strquery = "select o from Parkeertijden o where (UPPER(o.parkeerzone)= UPPER(:p_parkeerzone) and  "+"o."+dagnaam+"!='N')";
            log.info(strquery);
            Query query = em.createQuery(strquery);
            
            query.setParameter("p_parkeerzone", parkeerzone);
            
           
            if (query.getResultList() != null &&
                query.getResultList().size() > 0) {
                parkeertijdenList = (List<Parkeertijden>)query.getResultList();
                log.info("total parkeertijden: "+parkeertijdenList.size());
                for(int i =0 ; i < parkeertijdenList.size(); i++){

                    Parkeertijden parkeertijd = (Parkeertijden) parkeertijdenList.get(i);
                    setDayNull(dagnaam,parkeertijd);
                    em.clear();
                        
                    
                }
                
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        

        return parkeertijdenList;
    }

   

    public List<Parkeertijden> findByDay(Date date) {
        log.info("Parkeertijden.findByDay..");
        List<Parkeertijden> parkeertijdenList = null;
        String dagnaam = null;
        String[] dagen = {"zondag", "maandag","dinsdag","woensdag","donderdag","vrijdag","zaterdag"};
        try{
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH);
            int day = cal.get(Calendar.DAY_OF_WEEK);
            dagnaam = dagen[day-1];
           
           
            String strquery = "select o from Parkeertijden o where o."+dagnaam+"!='N'";
            log.info(strquery);
            Query query = em.createQuery(strquery);
           
            if (query.getResultList() != null &&
                query.getResultList().size() > 0) {
                parkeertijdenList = (List<Parkeertijden>)query.getResultList();
                log.info("total parkeertijden: "+parkeertijdenList.size());
                for(int i =0 ; i < parkeertijdenList.size(); i++){

                    Parkeertijden parkeertijd = (Parkeertijden) parkeertijdenList.get(i);
                    setDayNull(dagnaam,parkeertijd);
                    em.clear();
                        
                    
                }
                
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        

        return parkeertijdenList;
    }
    
    private void setDayNull(String dag,Parkeertijden parkeertijd) {
        
        if(dag.equalsIgnoreCase("zondag")){
            parkeertijd.setMaandag(null);
            parkeertijd.setDinsdag(null);
            parkeertijd.setWoensdag(null);
            parkeertijd.setDonderdag(null); 
            parkeertijd.setVrijdag(null);
            parkeertijd.setZaterdag(null);
        }else if(dag.equalsIgnoreCase("maandag")){
            parkeertijd.setZondag(null);
            parkeertijd.setDinsdag(null);
            parkeertijd.setWoensdag(null);
            parkeertijd.setDonderdag(null); 
            parkeertijd.setVrijdag(null);
            parkeertijd.setZaterdag(null);
        }else if(dag.equalsIgnoreCase("dinsdag")){
            parkeertijd.setZondag(null);
            parkeertijd.setMaandag(null);
            parkeertijd.setWoensdag(null);
            parkeertijd.setDonderdag(null); 
            parkeertijd.setVrijdag(null);
            parkeertijd.setZaterdag(null);
        }else if(dag.equalsIgnoreCase("woensdag")){
            parkeertijd.setZondag(null);
            parkeertijd.setMaandag(null);
            parkeertijd.setDinsdag(null);
            parkeertijd.setDonderdag(null); 
            parkeertijd.setVrijdag(null);
            parkeertijd.setZaterdag(null);
        }else if(dag.equalsIgnoreCase("donderdag")){
            parkeertijd.setZondag(null);
            parkeertijd.setMaandag(null);
            parkeertijd.setDinsdag(null);
            parkeertijd.setWoensdag(null);
            parkeertijd.setVrijdag(null);
            parkeertijd.setZaterdag(null);
        }else if(dag.equalsIgnoreCase("vrijdag")){
            parkeertijd.setZondag(null);
            parkeertijd.setMaandag(null);
            parkeertijd.setDinsdag(null);
            parkeertijd.setWoensdag(null);
            parkeertijd.setDonderdag(null);
            parkeertijd.setZaterdag(null);
        }else if(dag.equalsIgnoreCase("zaterdag")){
            parkeertijd.setZondag(null);
            parkeertijd.setMaandag(null);
            parkeertijd.setDinsdag(null);
            parkeertijd.setWoensdag(null);
            parkeertijd.setDonderdag(null);
            parkeertijd.setVrijdag(null);
            
        }
    }

    
}
