package nl.haarlem.services.parkeerrechten;

import java.util.List;

import javax.ejb.Local;

@Local
public interface ParkeerrechtenSessionEJBLocal {
}
