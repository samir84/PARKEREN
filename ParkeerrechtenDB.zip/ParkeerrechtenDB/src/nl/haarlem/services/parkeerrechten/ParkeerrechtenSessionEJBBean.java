package nl.haarlem.services.parkeerrechten;


import java.io.IOException;

import java.net.URI;

import java.net.URISyntaxException;

import java.sql.Timestamp;

import java.text.DecimalFormat;

import java.util.Calendar;
import java.util.List;
import java.util.ArrayList;

import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;


import javax.ejb.TransactionManagement;

import javax.ejb.TransactionManagementType;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import nl.haarlem.services.parkeerrechten.dao.AlgemeneVoorwaardenDAO;
import nl.haarlem.services.parkeerrechten.model.Bestedingsruimte;
import nl.haarlem.services.parkeerrechten.model.Message;
import nl.haarlem.services.parkeerrechten.model.Parkeerkosten;
import nl.haarlem.services.parkeerrechten.model.Recht;
import nl.haarlem.services.parkeerrechten.model.RechtType;
import nl.haarlem.services.parkeerrechten.model.Registratie;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtTypeEntity;
import nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity;
import nl.haarlem.services.parkeerrechten.model.Verbruik;
import nl.haarlem.services.parkeerrechten.dao.impl.*;
import nl.haarlem.services.parkeerrechten.jpa.AlgemeneVoorwaardenEntity;


@Stateless(name = "ParkeerrechtenDB", mappedName = "ParkeerrechtenDB")
@WebService(name = "ParkeerrechtenService",
            portName = "ParkeerrechtenServicePort")
public class ParkeerrechtenSessionEJBBean implements ParkeerrechtenSessionEJB,
                                                     ParkeerrechtenSessionEJBLocal {
    @PersistenceContext(unitName = "ParkeerrechtenDB")
    private EntityManager em;


    private Logger logger =
        Logger.getLogger(ParkeerrechtenSessionEJBBean.class.getName());
    @EJB
    private AlgemeneVoorwaardenDAO algemeneVoorwaardenDAOImpl;

    public ParkeerrechtenSessionEJBBean() {
    }

    @WebMethod
    public Recht[] ophalenParkeerrechten(@WebParam(name = "bsn")
        String bsn) {
        List<RechtEntity> rechtEntities =
            em.createNamedQuery("Recht.findByBSN").setParameter("p_bsn",
                                                                bsn).getResultList();
        int aantal = rechtEntities.size();
        Recht[] rechten = new Recht[aantal];
        for (int i = 0; i < aantal; i++) {
            RechtEntity rechtEntity = rechtEntities.get(i);
            Recht recht = new Recht();
            recht.setActiveringscode(rechtEntity.getActiveringscode());
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(rechtEntity.getBegindatum().getTime());
            recht.setBegindatum(calendar);
            recht.setEmail(rechtEntity.getEmail());
            if (rechtEntity.getEinddatum() != null) {
                calendar.setTimeInMillis(rechtEntity.getEinddatum().getTime());
                recht.setEinddatum(calendar);
            }
            //recht.setType(rechtEntity.getType());
            recht.setZone(rechtEntity.getZone());
            rechten[i] = recht;
        }
        return rechten;
    }

    @WebMethod
    public Recht ophalenBezoekersrechtByBSN(@WebParam(name = "bsn")
        String bsn) throws ServiceException {
        Recht recht = new Recht();
       
        List<RechtEntity> rechtEntityList = em.createNamedQuery("Recht.findByBSN").setParameter("p_bsn",bsn).getResultList();
        if (rechtEntityList.size() == 1) {
            RechtEntity rechtEntity = rechtEntityList.get(0);
            
            recht.setBsn(new Long(rechtEntity.getBsn()));
            recht.setActiveringscode(rechtEntity.getActiveringscode());
            
           
            RechtType[] rechtTypeLijst = null;
            List<RechtTypeEntity> rechtTypeEntityList = rechtEntity.getRechtTypeList();
            
            if (rechtTypeEntityList != null) {
                rechtTypeLijst = new RechtType[rechtTypeEntityList.size()];
                for ( int i = 0 ; i < rechtTypeEntityList.size(); i++ ) {

                    RechtType rechtType = new RechtType();
                    java.sql.Timestamp beginTimestamp = calendarToTimestamp(rechtTypeEntityList.get(i).getBegindatum());
                    java.sql.Timestamp endTimestamp = calendarToTimestamp(rechtTypeEntityList.get(i).getEinddatum());
                    rechtTypeEntity.setBegindatum(beginTimestamp);
                    rechtTypeEntity.setEinddatum(endTimestamp);
                    rechtTypeEntity.setNaam(rechtTypeEntityList.get(i).getNaam());
                    rechtTypeEntity.setRecht(rechtTypeEntityList.get(i).getRecht());

                    rechtTypeList.add(rechtTypeEntity);

                }
            }
            
            recht.setRechtTypeLijst(rechtTypeLijst);
            recht.setZone(rechtEntity.getZone());
            recht.setEmail(rechtEntity.getEmail());
        }
        return recht;
    }

    @WebMethod
    public Recht ophalenBezoekersrechtByActiveringscode(@WebParam(name =
                                                                  "activeringscode")
        String activeringscode) throws ServiceException {
        Recht recht = new Recht();
        List<RechtEntity> rechtEntityList =
            em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode",
                                                                            activeringscode).getResultList();
        if (rechtEntityList.size() == 1) {
            RechtEntity rechtEntity = rechtEntityList.get(0);
            recht.setActiveringscode(rechtEntity.getActiveringscode());
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(rechtEntity.getBegindatum().getTime());
            recht.setBegindatum(calendar);
            recht.setEmail(rechtEntity.getEmail());
            if (rechtEntity.getEinddatum() != null) {
                calendar.setTimeInMillis(rechtEntity.getEinddatum().getTime());
                recht.setEinddatum(calendar);
            }
            // recht.setType("Bezoekersrecht");
            // loop
            //
            recht.setZone(rechtEntity.getZone());

        } else {
            throw new ServiceException("Activeringscode is niet geldig.");
        }
        return recht;
    }

    @WebMethod
    public Long registrerenBezoekersrecht(@WebParam(name = "recht")Recht recht) {
       
            RechtEntity rechtEntity = new RechtEntity();
            AlgemeneVoorwaardenEntity algVoorwrd = new AlgemeneVoorwaardenEntity();
            rechtEntity.setBsn(recht.getBsn().toString());
            //rechtEntity.setActiveringscode(recht.getActiveringscode());
            rechtEntity.setActiveringscode(generateActiveringscode());
            rechtEntity.setBegindatum(new Timestamp(recht.getBegindatum().getTimeInMillis()));
            if (recht.getEinddatum() != null) {
                rechtEntity.setEinddatum(new Timestamp(recht.getEinddatum().getTimeInMillis()));
            }
            List<RechtTypeEntity> rechtTypeList = new ArrayList<RechtTypeEntity>();
            if (recht.getRechtTypeLijst() != null) {
                for (RechtType rechtType : recht.getRechtTypeLijst()) {

                    RechtTypeEntity rechtTypeEntity = new RechtTypeEntity();
                    java.sql.Timestamp beginTimestamp =
                        calendarToTimestamp(rechtType.getBegindatum());
                    java.sql.Timestamp endTimestamp =
                        calendarToTimestamp(rechtType.getEinddatum());
                    rechtTypeEntity.setBegindatum(beginTimestamp);
                    rechtTypeEntity.setEinddatum(endTimestamp);
                    rechtTypeEntity.setNaam(rechtType.getNaam());
                    rechtTypeEntity.setRecht(rechtType.getRecht());

                    rechtTypeList.add(rechtTypeEntity);

                }
            }
            rechtEntity.setZone(recht.getZone());
            rechtEntity.setEmail(recht.getEmail());
            rechtEntity.setRechtTypeList(rechtTypeList);
            em.persist(rechtEntity);
            
            String akkoord = recht.getAkkoord();
            
            Long rechtId = rechtEntity.getId();


            if (rechtId != null && akkoord.equalsIgnoreCase("Y")) {
                Calendar calendar = Calendar.getInstance();
                java.util.Date now = calendar.getTime();
                java.sql.Timestamp currentTimestamp =
                    new java.sql.Timestamp(now.getTime());
                algVoorwrd.setDatumcheck(currentTimestamp);
                RechtEntity newRechtEntity = em.find(RechtEntity.class, rechtEntity.getId());
                algVoorwrd.setRecht(newRechtEntity);
                //em.persist(algVoorwrd);
                algemeneVoorwaardenDAOImpl.createAlgemeneVoorwaarden(algVoorwrd);
            }

        return rechtEntity.getId();
    }

    @WebMethod
    public Registratie[] ophalenRegstraties(@WebParam(name = "activeringscode")
        String activeringscode) throws ServiceException {
        RechtEntity rechtEntity;
        try {
            rechtEntity =
                    (RechtEntity)em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode",
                                                                                                 activeringscode).getResultList().get(0);
        } catch (Exception e) {
            throw new ServiceException("Activeringscode is niet geldig.");
        }
        Query query = em.createNamedQuery("Registratie.findValidByRecht");
        query.setParameter("p_recht", rechtEntity);
        List<RegistratieEntity> re = query.getResultList();
        int aantal = re.size();
        Registratie[] registratieLijst = new Registratie[aantal];
        for (int i = 0; i < aantal; i++) {
            RegistratieEntity registratieEntity = re.get(i);
            Registratie registratie = new Registratie();
            registratie.setId(registratieEntity.getId());
            registratie.setKenteken(registratieEntity.getKenteken());
            registratie.setActiveringscode(activeringscode);
            registratie.setBedrag(registratieEntity.getBedrag());
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(registratieEntity.getBegintijd().getTime());
            registratie.setBegintijd(calendar);
            if (registratieEntity.getEindtijd() != null) {
                Calendar calendar2 = Calendar.getInstance();
                calendar2.setTimeInMillis(registratieEntity.getEindtijd().getTime());
                registratie.setEindtijd(calendar2);
            }
            registratieLijst[i] = registratie;
        }
        return registratieLijst;
    }

    @WebMethod
    public Registratie[] ophalenRegstratiesHistorie(@WebParam(name =
                                                              "activeringscode")
        String activeringscode) throws ServiceException {
        RechtEntity rechtEntity;
        try {
            rechtEntity =
                    (RechtEntity)em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode",
                                                                                                 activeringscode).getResultList().get(0);
        } catch (Exception e) {
            throw new ServiceException("Activeringscode is niet geldig.");
        }
        Query query =
            em.createNamedQuery("Registratie.findValidByRechtHistorie");
        query.setParameter("p_recht", rechtEntity);
        List<RegistratieEntity> re = query.getResultList();
        int aantal = re.size();
        Registratie[] registratieLijst = new Registratie[aantal];
        for (int i = 0; i < aantal; i++) {
            RegistratieEntity registratieEntity = re.get(i);
            Registratie registratie = new Registratie();
            registratie.setKenteken(registratieEntity.getKenteken());
            if (registratieEntity.getBedrag() != null) {
                registratie.setBedrag(registratieEntity.getBedrag());
            }
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(registratieEntity.getBegintijd().getTime());
            registratie.setBegintijd(calendar);
            if (registratieEntity.getEindtijd() != null) {
                Calendar carlendar2 = Calendar.getInstance();
                carlendar2.setTimeInMillis(registratieEntity.getEindtijd().getTime());
                registratie.setEindtijd(carlendar2);
            }
            registratie.setActiveringscode(registratieEntity.getRecht().getActiveringscode());
            registratie.setId(registratieEntity.getId());
            registratieLijst[i] = registratie;
        }
        return registratieLijst;
    }

    @WebMethod
    public Long aanmeldenKenteken(@WebParam(name = "registratie")
        Registratie registratie) {
        RechtEntity rechtEntity =
            (RechtEntity)em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode",
                                                                                         registratie.getActiveringscode()).getResultList().get(0);
        RegistratieEntity registratieEntity = new RegistratieEntity();
        registratieEntity.setRecht(rechtEntity);
        registratieEntity.setKenteken(registratie.getKenteken());
        registratieEntity.setBedrag(new Double(0));
        if (registratie.getBegintijd() != null) {
            registratieEntity.setBegintijd(new Timestamp(registratie.getBegintijd().getTimeInMillis()));
        } else {
            registratieEntity.setBegintijd(new Timestamp(Calendar.getInstance().getTimeInMillis()));
        }
        if (registratie.getEindtijd() != null) {
            registratieEntity.setEindtijd(new Timestamp(registratie.getEindtijd().getTimeInMillis()));
        }
        em.persist(registratieEntity);
        return registratieEntity.getId();
    }

    @WebMethod
    public String afmeldenKenteken(@WebParam(name = "registratie")
        Registratie registratie) {
        //logger.severe("###ParkeerrechtenSessionEJBBean.afmeldenKenteken");
        if (registratie.getId() != null) {
            RegistratieEntity registratieEntity =
                (RegistratieEntity)em.createNamedQuery("Registratie.findById").setParameter("p_id",
                                                                                            registratie.getId()).getSingleResult();
            registratieEntity.setEindtijd(new Timestamp(Calendar.getInstance().getTimeInMillis()));
            registratieEntity.setBedrag(registratie.getBedrag());
            em.merge(registratieEntity);
        } else {
            RechtEntity rechtEntity =
                (RechtEntity)em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode",
                                                                                             registratie.getActiveringscode()).getResultList().get(0);
            Query query =
                em.createNamedQuery("Registratie.findActieveRegistratieByKenteken");
            query.setParameter("p_kenteken", registratie.getKenteken());
            query.setParameter("p_recht", rechtEntity);
            List<RegistratieEntity> registratieList = query.getResultList();
            for (RegistratieEntity registratieEntity : registratieList) {
                registratieEntity.setEindtijd(new Timestamp(Calendar.getInstance().getTimeInMillis()));
                em.merge(registratieEntity);
            }
        }
        return "success";
    }

    @WebMethod
    public String verwijderRegistratie(@WebParam(name = "registratie")
        Registratie registratie) {
        RegistratieEntity registratieEntity =
            (RegistratieEntity)em.createNamedQuery("Registratie.findById").setParameter("p_id",
                                                                                        registratie.getId()).getSingleResult();
        em.remove(registratieEntity);
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "success2";
    }

    @WebMethod
    public String updateRegistratieEindtijd(@WebParam(name = "registratie")
        Registratie registratie) {
        logger.info("###ParkeerrechtenSessionEJBBean.ophalenStatusKenteken");
        //RechtEntity rechtEntity = (RechtEntity)em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode", registratie.getActiveringscode()).getResultList().get(0);
        Query query = em.createNamedQuery("Registratie.findById");
        query.setParameter("p_id", registratie.getId());
        RegistratieEntity registratieEntity =
            (RegistratieEntity)query.getSingleResult();
        registratieEntity.setEindtijd(new Timestamp(registratie.getEindtijd().getTimeInMillis()));
        registratieEntity.setBedrag(registratie.getBedrag());
        em.merge(registratieEntity);
        return "success";
    }

    @WebMethod
    public String updateRegistratieBedrag(@WebParam(name = "registratie")
        Registratie registratie) {
        logger.info("###ParkeerrechtenSessionEJBBean.ophalenStatusKenteken");
        //RechtEntity rechtEntity = (RechtEntity)em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode", registratie.getActiveringscode()).getResultList().get(0);
        Query query = em.createNamedQuery("Registratie.findById");
        query.setParameter("p_id", registratie.getId());
        RegistratieEntity registratieEntity =
            (RegistratieEntity)query.getSingleResult();
        registratieEntity.setBedrag(registratie.getBedrag());
        em.merge(registratieEntity);
        return "success";
    }

    @WebMethod
    public boolean zoekGeregistreerdRegistratie(@WebParam(name = "registratie")
        Registratie registratie) {
        RechtEntity rechtEntity =
            (RechtEntity)em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode",
                                                                                         registratie.getActiveringscode()).getResultList().get(0);
        Query query =
            em.createNamedQuery("Registratie.findGeregistreerdeRegistraties");
        query.setParameter("p_recht", rechtEntity);
        query.setParameter("p_kenteken", registratie.getKenteken());
        query.setParameter("p_begintijd",
                           new Timestamp(registratie.getBegintijd().getTimeInMillis()));
        query.setParameter("p_eindtijd",
                           new Timestamp(registratie.getEindtijd().getTimeInMillis()));
        List<RegistratieEntity> registratieEntityList = query.getResultList();
        for (RegistratieEntity registratieEntity : registratieEntityList) {
            return true;
        }
        return false;
    }

    @WebMethod
    public Registratie ophalenActieveRegistratie(@WebParam(name =
                                                           "registratie")
        Registratie registratie) {
        logger.info("###ParkeerrechtenSessionEJBBean.ophalenStatusKenteken");
        Query query =
            em.createNamedQuery("Registratie.findActieveRegistratieById");
        query.setParameter("p_id", registratie.getId());
        try {
            RegistratieEntity registratieEntity =
                (RegistratieEntity)query.getSingleResult();
            registratie.setId(registratieEntity.getId());
            registratie.setActiveringscode(registratieEntity.getRecht().getActiveringscode());
            registratie.setKenteken(registratieEntity.getKenteken());
            registratie.setBedrag(registratieEntity.getBedrag());
            Calendar beginT = Calendar.getInstance();
            beginT.setTimeInMillis(registratieEntity.getBegintijd().getTime());
            registratie.setBegintijd(beginT);
            registratie.setZone(registratieEntity.getRecht().getZone());
            if (registratieEntity.getEindtijd() != null) {
                Calendar eindT = Calendar.getInstance();
                eindT.setTimeInMillis(registratieEntity.getEindtijd().getTime());
                registratie.setEindtijd(eindT);
            }
            return registratie;
        } catch (NoResultException e) {
            return new Registratie();
        }
    }

    @WebMethod
    @WebResult(name = "bestedingsruimte")
    public Bestedingsruimte ophalenBestedingsruimte(@WebParam(name =
                                                              "activeringscode")
        String activeringscode) throws ServiceException {
        List<RechtEntity> rechtEntityList =
            (List<RechtEntity>)em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode",
                                                                                               activeringscode).getResultList();
        Float limiet = new Float(0.00);
        double verbruik = 0;
        Bestedingsruimte bestedingsruimte = new Bestedingsruimte();
        if (rechtEntityList.size() == 1) {
            RechtEntity recht = rechtEntityList.get(0);
            List<RechtTypeEntity> rechtTypeLijst =
                (List<RechtTypeEntity>)recht.getRechtTypeList();
            for (int j = 0; j < rechtTypeLijst.size(); j++) {
                RechtTypeEntity rechtType =
                    (RechtTypeEntity)rechtTypeLijst.get(j);
                limiet = limiet + ophalenBestedingsLimit(rechtType.getNaam());

            }
            Query query =
                em.createNamedQuery("Registratie.findRegistratiesHuidigJaar");
            query.setParameter("p_recht", rechtEntityList.get(0));
            Calendar calendar = Calendar.getInstance();
            calendar.set(calendar.get(Calendar.YEAR), 0, 1, 0, 0, 0);
            query.setParameter("p_datum",
                               new Timestamp(calendar.getTimeInMillis()));
            Object object = query.getResultList().get(0);
            verbruik = 0;
            if (object != null) {
                verbruik = new Double(object.toString());
            }
        }
        double ruimte = limiet - verbruik;
        bestedingsruimte.setLimiet(limiet);
        bestedingsruimte.setRuimte(ruimte);
        bestedingsruimte.setVerbruik(verbruik);
        return bestedingsruimte;
    }

    @WebMethod
    public String wijzigenActiveringscode(@WebParam(name = "activeringscode")
        String activeringscode) {
        RechtEntity rechtEntity =
            (RechtEntity)em.createNamedQuery("Recht.findByActiveringscode").setParameter("p_activeringscode",
                                                                                         activeringscode).getResultList().get(0);
        rechtEntity.setActiveringscode(generateActiveringscode());
        em.merge(rechtEntity);
        return rechtEntity.getActiveringscode();
    }

    /**
     *Generate a unique random id for Activeringscode
     * @return
     */
    private String generateActiveringscode() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString().substring(1, 5);

    }

    @WebMethod
    public Float berekenParkeerkosten(@WebParam(name = "parkeerkosten")
        Parkeerkosten parkeerkosten) {
        Float f_parkingcosts = new Float(0.0);
        int i_parkingcosts = 0;
        int unitprice = 3;
        Calendar calendar;
        Calendar calendarEndtime;
        // Set the time block in minutes (TODO TODO TODO: get it from the Business Rule)
        int timeBlock = 15;
        // Set the starttime
        calendar = parkeerkosten.getBegintijd();
        // Set the endtime to compare with
        calendarEndtime = parkeerkosten.getEindtijd();
        // Compare the parkingtime with the endtime and add 15 minutes each time it's before the endtime
        while (calendar.compareTo(calendarEndtime) == -1) {
            // Add parkingcosts according to the Business Rule (TODO TODO TODO: get it from the Business Rule)
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int blockprice = 0;
            if (hour >= 9 && hour < 18) {
                blockprice = unitprice;
            }
            if (hour >= 18 && hour < 23) {
                blockprice = unitprice * 2;
            }
            i_parkingcosts += blockprice;
            // Add a timeBlock to the parkingtime
            calendar.add(Calendar.MINUTE, timeBlock);
        }
        f_parkingcosts = ((float)i_parkingcosts / 100);
        return f_parkingcosts;
    }

    @WebMethod
    public String sendMessageToSocket(@WebParam(name = "message")
        Message message) {
        //        logger.info("###ParkeerrechtenSessionEJBBean.sendMessageToSocket");
        //        WebSocketClient connect = null;
        //        try {
        //                //String url= "ws://slrp024.ssc.lan:8080/bezoekersparkeren/websocket";
        //            String url = "ws://slssc010.ssc.lan:3040/ebase/BezoekersparkerenWebsocket";
        //
        //            Gson g = new Gson();
        //            //Message message = new Message("1","Hello World","test");
        //            connect = new WebSocketClient(new URI(url));
        ////            connect.sendMessage(g.toJson(message));
        //
        //
        //        } catch (DeploymentException e) {
        //            e.printStackTrace();
        //        } catch (IOException e) {
        //            e.printStackTrace();
        //        } catch (URISyntaxException e) {
        //            e.printStackTrace();
        //        }

        return "success";
    }

    @WebMethod
    public boolean isVerbruikOverschrijden(@WebParam(name = "Verbruik")
        Verbruik verbruik) {

        //constant : this should be later chnaged by the business rule
        double limit = 25.00;

        double equation1 =
            Math.floor((verbruik.getVerbruik() + verbruik.getKosten()) /
                       limit);
        double equation2 = Math.floor((verbruik.getVerbruik()) / limit);
        System.out.println(equation1);
        System.out.println(equation2);

        if (equation1 != equation2) {
            return true;
        }

        return false;

    }

    private Double round(Double bedrag) {
        return Double.parseDouble(new DecimalFormat("##.####").format(bedrag));
    }

    private Timestamp calendarToTimestamp(Calendar calendar) {
        return new Timestamp(calendar.getTimeInMillis());
    }
    private Calendar timestampToCalendar(long millis){
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        return calendar;
    }
    public static void main(String[] arg) {
        ParkeerrechtenSessionEJBBean p = new ParkeerrechtenSessionEJBBean();
        Verbruik verbruik = new Verbruik();
        verbruik.setKosten(1.62);
        verbruik.setVerbruik(24.17);
        boolean test = p.isVerbruikOverschrijden(verbruik);
        System.out.println(test);
    }

    private Float ophalenBestedingsLimit(String rechtType) {
        if (rechtType.equalsIgnoreCase("BEZOEKER")) {
            return new Float(125);
        } else if (rechtType.equalsIgnoreCase("MANTELZORG")) {
            return new Float(25);
        } else {
            return new Float(0);
        }
    }
}

