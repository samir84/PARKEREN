package nl.haarlem.services.parkeerrechten;



import java.sql.Timestamp;

import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.List;
import java.util.ArrayList;

import java.util.Date;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.EJB;
import javax.ejb.Stateless;


import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlList;
import javax.xml.rpc.ServiceException;

import nl.haarlem.services.parkeerrechten.dao.AlgemeneVoorwaardenDAO;
import nl.haarlem.services.parkeerrechten.dao.RechtTypeDAO;
import nl.haarlem.services.parkeerrechten.model.Bestedingsruimte;
import nl.haarlem.services.parkeerrechten.model.Message;
import nl.haarlem.services.parkeerrechten.model.Parkeerkosten;
import nl.haarlem.services.parkeerrechten.model.Recht;
import nl.haarlem.services.parkeerrechten.model.Registratie;
import nl.haarlem.services.parkeerrechten.jpa.RechtEntity;
import nl.haarlem.services.parkeerrechten.jpa.RechtTypeEntity;
import nl.haarlem.services.parkeerrechten.jpa.RegistratieEntity;
import nl.haarlem.services.parkeerrechten.model.Verbruik;
import nl.haarlem.services.parkeerrechten.jpa.AlgemeneVoorwaardenEntity;
import nl.haarlem.services.parkeerrechten.exception.BezoekersparkerenException;
import nl.haarlem.services.parkeerrechten.jpa.InstellingenEntity;
import nl.haarlem.services.parkeerrechten.jpa.Parkeertijden;
import nl.haarlem.services.parkeerrechten.model.Instelling;
import nl.haarlem.services.parkeerrechten.service.InstellingService;
import nl.haarlem.services.parkeerrechten.service.ParkeertijdenService;
import nl.haarlem.services.parkeerrechten.service.RechtService;
import nl.haarlem.services.parkeerrechten.service.RegistratieService;
import nl.haarlem.services.parkeerrechten.util.AppHelper;
import nl.haarlem.services.parkeerrechten.util.DateTimeHelper;

import org.slf4j.LoggerFactory;


@Stateless(name = "ParkeerrechtenDB", mappedName = "ParkeerrechtenDB")
@WebService(name = "ParkeerrechtenService",
            portName = "ParkeerrechtenServicePort")
public class ParkeerrechtenSessionEJBBean implements ParkeerrechtenSessionEJB,
                                                     ParkeerrechtenSessionEJBLocal {

    private org.slf4j.Logger log =
        LoggerFactory.getLogger(ParkeerrechtenSessionEJBBean.class.getName());


    @PersistenceContext(unitName = "ParkeerrechtenDB")
    private EntityManager em;
    
    @EJB
    private RechtService rechtService;
    @EJB
    private AlgemeneVoorwaardenDAO algemeneVoorwaardenDAO;
    @EJB
    private RechtTypeDAO rechtTypeDAO;
    @EJB
    private RegistratieService registratieService;
    @EJB
    private InstellingService instellingService;
    
    @EJB
    private ParkeertijdenService parkeertijdenService;
    
    public ParkeerrechtenSessionEJBBean() {
    }
    
    
    
    @WebMethod
    public Instelling findInstellingByAanmeldcodeAndKey(@WebParam(name ="aanmeldcode")
        String aanmeldcode, @WebParam(name = "key") String key) throws BezoekersparkerenException {
        
        Instelling instelling = null;
        try {
             InstellingenEntity instellingEntity = instellingService.findInstellingByAanmeldcodeAndKey(aanmeldcode, key);
             instelling = new Instelling();
            instelling.setKey(instellingEntity.getKey());
            instelling.setValue(instellingEntity.getValue());
        }catch(Exception ex){
            ex.printStackTrace();
        }
        
        //MailInstelling.setKey("Email_Notification");
        
        return instelling;
    } 
    @WebMethod
    public String updateInstelling(@WebParam(name ="aanmeldcode")
        String aanmeldcode, @WebParam(name = "key") String key, @WebParam(name = "value") String value) throws BezoekersparkerenException {
        
        instellingService.updateInstelling(aanmeldcode, key, value);
        return "succes";
    }
    
    //
    @WebMethod
    @WebResult(name = "recht")
    public Recht ophalenBezoekersrechtVoorBSN(@WebParam(name = "bsn")
        String bsn) throws  BezoekersparkerenException {

        return rechtService.ophalenBezoekersrechtByBSN(bsn);
    }
    
    @WebMethod
    @WebResult(name = "recht")
    public Recht ophalenRechtByNummerAanduiding(@WebParam(name = "nummerAanduiding")
        String nummerAanduiding) throws  BezoekersparkerenException {
       
        return rechtService.ophalenRechtByNummerAanduiding(nummerAanduiding);
    }
    @WebMethod
    @WebResult(name = "recht")
    public Recht ophalenBezoekersrechtVoorAanmeldcode(@WebParam(name ="aanmeldcode")
        String aanmeldcode) throws BezoekersparkerenException {
        
        
        return rechtService.ophalenBezoekersrechtByAanmeldcode(aanmeldcode);
    }

    @WebMethod
    public Long registrerenBezoekersrecht(@WebParam(name = "recht")
        Recht recht) throws BezoekersparkerenException {
        
       return rechtService.registrerenBezoekersrecht(recht);

    }
    @WebMethod
    public String updateBezoekersRecht(@WebParam(name = "recht") Recht recht) throws  BezoekersparkerenException {
        
        return rechtService.updateRecht(recht);
    }
    @WebMethod
    //@WebResult(name="registratie", targetNamespace = "http://parkeerrechten.services.haarlem.nl/")
    public Registratie[] ophalenRegistraties(@WebParam(name = "aanmeldcode")
        String aanmeldcode) throws BezoekersparkerenException {
        log.info("ophalenRegistraties: findRegistratiesByAanmeldcode("+aanmeldcode+") at time: "+new Date());
        return registratieService.findRegistratiesByAanmeldcode(aanmeldcode);
        
    }

    @WebMethod
    //@WebResult(name="registratie", targetNamespace = "http://parkeerrechten.services.haarlem.nl/")
    public Registratie[] ophalenRegistratiesHistorie(@WebParam(name =
                                                              "aanmeldcode")
        String aanmeldcode) throws BezoekersparkerenException {
        
        return registratieService.ophalenRegstratiesHistorie(aanmeldcode);
    }

    @WebMethod
    public Long aanmeldenKenteken(@WebParam(name = "registratie") Registratie registratie) throws BezoekersparkerenException {

        return  registratieService.aanmeldenKenteken(registratie);
    }

    @WebMethod
    public String afmeldenKenteken(@WebParam(name = "registratie")
        Registratie registratie) throws BezoekersparkerenException{
        
        return  registratieService.afmeldenKenteken(registratie);
    }

    

    @WebMethod
    public String updateRegistratieEindtijd(@WebParam(name = "registratie")
        Registratie registratie) throws BezoekersparkerenException {
        
        return registratieService.updateRegistratieEindtijd(registratie);
    }


    @WebMethod
    public boolean zoekGeregistreerdRegistratie(@WebParam(name = "registratie")
        Registratie registratie) throws BezoekersparkerenException {
        
        return registratieService.zoekGeregistreerdRegistratie(registratie);
    }

    @WebMethod
    public Registratie ophalenActieveRegistratie(@WebParam(name =
                                                           "registratie")
        Registratie registratie) throws BezoekersparkerenException {

        return registratieService.ophalenActieveRegistratie(registratie);
    }

    @WebMethod
    public String opzeggenParkeerRecht(@WebParam(name = "aanmeldcode") String aanmeldcode) throws BezoekersparkerenException {
        
         return rechtService.opzeggenRecht(aanmeldcode);
    }
    
    @WebMethod
    @WebResult(name = "bestedingsruimte")
    public Bestedingsruimte ophalenBestedingsruimte(@WebParam(name =
                                                              "aanmeldcode")
        String aanmeldcode) throws BezoekersparkerenException {
        
        return registratieService.ophalenBestedingsruimte(aanmeldcode);
        
    }

    @WebMethod
    public String wijzigenAanmeldcode(@WebParam(name = "aanmeldcode")
        String aanmeldcode) throws BezoekersparkerenException {
       return rechtService.wijzigenAanmeldcode(aanmeldcode);
    }
    
    @WebMethod
    public boolean checkMailNotification(@WebParam(name = "aanmeldcode") String aanmeldcode)
                throws BezoekersparkerenException {
        
        return instellingService.findNotificationMailByAanmeldcode(aanmeldcode).getValue().equalsIgnoreCase("J") ? true : false;
    }
    @WebMethod
    public String updateMailNotification(@WebParam(name = "aanmeldcode") String aanmeldcode, @WebParam(name = "value") String value)
                throws BezoekersparkerenException {
        
        instellingService.updateMailNotification(aanmeldcode, value);
        return "succes";
    }
    

    @WebMethod
    public Float berekenParkeerkosten(@WebParam(name = "parkeerkosten")
        Parkeerkosten parkeerkosten) {
        
        Float f_parkingcosts = new Float(0.0);
        int i_parkingcosts = 0;
        int unitprice = 3;
        Calendar calendar;
        Calendar calendarEndtime;
        // Set the time block in minutes (TODO TODO TODO: get it from the Business Rule)
        int timeBlock = 15;
        // Set the starttime
        calendar = parkeerkosten.getBegintijd();
        // Set the endtime to compare with
        calendarEndtime = parkeerkosten.getEindtijd();
        boolean is2min = DateTimeHelper.getInstance().checkDifferenceBeginTimeEndTimeIs2min(calendar, calendarEndtime);
            if(is2min){
                return f_parkingcosts;
            }
        // Compare the parkingtime with the endtime and add 15 minutes each time it's before the endtime
        while (calendar.compareTo(calendarEndtime) == -1) {
            // Add parkingcosts according to the Business Rule (TODO TODO TODO: get it from the Business Rule)
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int blockprice = 0;
                if (hour >= 9 && hour < 18) {
                    blockprice = unitprice;
                }
                if (hour >= 18 && hour < 23) {
                    blockprice = unitprice * 2;
                }
                i_parkingcosts += blockprice;
                // Add a timeBlock to the parkingtime
                calendar.add(Calendar.MINUTE, timeBlock); 
            
        }
        f_parkingcosts = ((float)i_parkingcosts / 100);
        return f_parkingcosts;
    }
    

    @WebMethod
    public String sendMessageToSocket(@WebParam(name = "message")
        Message message) {
        //        logger.info("###ParkeerrechtenSessionEJBBean.sendMessageToSocket");
        //        WebSocketClient connect = null;
        //        try {
        //                //String url= "ws://slrp024.ssc.lan:8080/bezoekersparkeren/websocket";
        //            String url = "ws://slssc010.ssc.lan:3040/ebase/BezoekersparkerenWebsocket";
        //
        //            Gson g = new Gson();
        //            //Message message = new Message("1","Hello World","test");
        //            connect = new WebSocketClient(new URI(url));
        ////            connect.sendMessage(g.toJson(message));
        //
        //
        //        } catch (DeploymentException e) {
        //            e.printStackTrace();
        //        } catch (IOException e) {
        //            e.printStackTrace();
        //        } catch (URISyntaxException e) {
        //            e.printStackTrace();
        //        }

        return "success";
    }

    @WebMethod
    public boolean isVerbruikOverschrijden(@WebParam(name = "Verbruik")
        Verbruik verbruik) {

        //constant : this should be later chnaged by the business rule
        double limit = 25.00;

        double equation1 = Math.floor((verbruik.getVerbruik() + verbruik.getKosten()) /limit);
        double equation2 = Math.floor((verbruik.getVerbruik()) / limit);
       

        if (equation1 != equation2) {
            return true;
        }

        return false;

    }
    
    /**
     * this methode is for developing purpose
     * @param bsn
     */
    @WebMethod
    public boolean verwijderRecht(@WebParam (name="bsn") String bsn){
        
        return rechtService.verwijderRecht(bsn);
        
    }
    @WebMethod
    public Registratie ophalenRegistratieById(@WebParam(name = "id")
        Long id) throws BezoekersparkerenException {

        return registratieService.ophalenRegistratieById(id);
    }
    
   @WebMethod
   @WebResult(name = "parkeertijden")
    
   public List<Parkeertijden> ophalenParkeertijden(){
       
     return parkeertijdenService.findAll();
  }

    @WebMethod
   @WebResult(name = "parkeertijden")
    public List<Parkeertijden> ophalenParkeertijdenByParkeerzone(@WebParam (name="parkeerzone") String parkeerzone){
        
      return parkeertijdenService.findByParkeerzone(parkeerzone);
    }
    
    @WebMethod
    @WebResult(name = "parkeertijden")
    public List<Parkeertijden> ophalenParkeertijdenByDateEnParkeerzone(@WebParam (name="date") Date date, @WebParam (name="parkeerzone") String parkeerzone){
        return parkeertijdenService.ophalenParkeertijdenByDateEnParkeerzone(date,parkeerzone);
    }
    
    @WebMethod
    @WebResult(name = "parkeertijden")
    public List<Parkeertijden> ophalenParkeertijdenByDate(@WebParam (name="date") Date date){
        return parkeertijdenService.ophalenParkeertijdenByDate(date);
    }


    @WebMethod
    @WebResult(name = "bestedingsruimte")
    public Bestedingsruimte ophalenBestedingsruimte_TEST(@WebParam(name ="aanmeldcode")String aanmeldcode ,@WebParam (name="date") Date date) throws BezoekersparkerenException {
        
        return registratieService.ophalenBestedingsruimte_TEST(aanmeldcode,date);
        
    }

}

